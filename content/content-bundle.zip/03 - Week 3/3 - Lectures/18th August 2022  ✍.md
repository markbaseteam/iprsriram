---
Week: 3
LectureNumber: 6
Topics:
Date:  2022-08-18
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  18th August 2022 - Intellectual Property Law L(4)
Type:: #lecture
---


# **Lecture Notes** 📝 :  18th August 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  18-08-2022**
- Week: 3
- Lecture No.:  6
- **Semester**: #7thsemester 

```
Status:: #complete
Module:: 

---
### Artistic Work
<mark style="background: #00FFFE73;">Section 2(c)</mark> 

```ad-kanban
title: Types of Artistic work
icon: globe
- Painting
- Sculpture
- Drawing 
- Engraving 
- Photograph 
- Author/owner - Artist
```
- Copyright is **fixated**/exists/subsists in an **expression**

<br>

**CINEMATOGRAPHIC FILMS**
-  
	- Edison came up with a device to show **moving photographs**
	- Lumere brothers -> came up with ==**projector and images in one device**==
-  
	- Dadasaheb phalke *father of Indian Cinema* -> created ***Raja Harishchandra*** 
-  
	- France -> **law of the authors** -> the **producer does not have as much right 🔴**
	- The film is seen as a work of **joint ownership**
	- Teh ***producer, director screenwriter and the composer*** are given ==**equal rights**==
	- 

---
## PRINCIPLES OF COPYRIGHT 📌
````ad-Calendar
title:
```ad-kanban
title: Overview
icon: star
- Idea-expression Dichotomy
- Originality
- Merger
- Fixation
```


````

<br>


### Idea-expression Dichotomy
![[18th August 2022  ✍.png]]
- 
	- Shares similarities with [[#Merger]]

<br>


#### [[Idea Expression dichotomy]]
![[Idea Expression dichotomy]]
- Sometimes **ideas and expressions** are **indistinguishable** 🔴

<br>


**CASES**
1. [[Donaghue vs Allied Newspapers]]
2. [[SAS Institute vs World Programming Ltd.]]

![[⚖️ Baker v Selden (1879)]]


![[⚖️ Nichols v Universal (1930)]]
<br>




### Originality

![[24th August 2022  ✍#ORIGINALITY]]


<br>



### Merger
![[Doctrine of Merger 📌]]

<br>




### Fixation
![[24th August 2022  ✍#FIXATION]]