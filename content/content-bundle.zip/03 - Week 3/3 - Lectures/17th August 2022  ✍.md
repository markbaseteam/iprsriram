---
Week: 3
LectureNumber:  5
Topics:
Date:  2022-08-17
cssclass: max
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  17th August 2022 - Intellectual Property Law L(5)
Type:: #lecture

---


# **Lecture Notes** 📝 :  17th August 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  17-08-2022**
- Week: 3
- Lecture No.:  5
- **Semester**: #7thsemester 

```
Module:: 
Status:: #complete 



---
> ![[17th August COPYRIGHT LECTURE.excalidraw|2500]]



----
-  
	- If you are **rooting somethin in a universe that is copyright protected** through different movies 
		- eg:  *creating a Hulk who is non-binary* -> **despite  all these variations, it <u>does not change that fact that it is rooted in characters rooted in the cinematic universe</u>**
	- Statute of Monopolies -> error -> it **allowed the soverign to give sequestered rights to only certain people to create certain works**

<br>



**<u>What does copyright protect?</u>**
- It is a meand to protect works

**<u>What kind of works?</u>**
- **Original works**

**<u>Can Ideas be Copyrighted?</u>**
- <mark style="background: #FF0000A3;">**Nope**</mark>  
- There ==**has to be an expression**== #important 

**<u>Is registration of copyright a compulsion?</u>**
- No
- Nevertheless **registration is preferred**


----

![[Statute of Anne]]

<br>


- 
	- Bible was inaccessible to people; people **believed pretty much everything that the church said** 
	- The printing press mad ekowledge accessible -> **printing became easier** 
		- The printing press also **brought in a loophole** 🔴 -> it allowed for <mark style="background: #FF0000A3;">**unfettered replication of works**</mark>  so much so that the ***<u>author got lost</u>***
			- People realised that **this was not viable in the long term**
-  
	- The printing press also **made the publishers extremely rich** ->  there were only ==**some people who had the access to printing presses**==  
		- In this case, the **author also go affected**; they had to **beg the people operating the presses to earn their [[royalties]]**
		- the [[Statute of Anne]] ensured that <mark style="background: #00FF3E8C;">**it is the creator who will get the reward for thier works**</mark> 

<br>


---
## History in india
- In 1914 -> we got our <mark style="background: #00FFFE73;">first statute of copyright</mark> 
	- It was inspired by Act of 1911 in UK
- Post independence -> **<mark style="background: #00FFFE73;">Copyright Act of 1957</mark>** 

<br>



----
## Justifications for Copyright
1.  
	- There is a need ot accept the **cultureal basis of all of these works**
	- There is need ot **ackowledge the works of the author**
		- the author ==needs to be **provided their due**==
2.  
	- ==**Incentives**== and rewards are another justification
3.  
	- Free speech vs public ->  whether copyright is a vehicle to **protect the expression of the author** or **restricts the expressive autonomy of others**
4.  
	- <mark style="background: #FF00868C;">**Neoliberal economics**</mark>  
	- **Economic rights are recognised before moral rights**
	- **<u>aNGLO aMERICAN perspective</u>**
		1. **attribution** to the author #doubt 
		2. focuses on **integrity** 
	- **<u>Continental perspective</u>**
		- any other European country
		- in this case ==**<u>the author is the focal point; he dictates everything</u>**==
5.  
	- ==**Democratic Argument**==
		- *Tandav: mixed reactions from people; Padmaavat -> protests against it in in apprehension that the movie would cause dishonour to the community*
		- <mark style="background: #00FF3E8C;">Copyright -> is a **tool to exercise democratic rights** </mark> 
			- copyright in this case arguably **furthers democracy** 
6.  
	- Protects persons from [[Unjust enrichment]]
7.  
	- personal autonomy -> gives the author of th work **complete control over the work** -> no one should pass off someone else's work as their own




---

- [[WIPO Copyright Treaty]] and -> provides for ==protection of **softwares**==
- [[WIPO Peformances and Phonograms Treaty]] -> Recognises performers rights

<br>


![[Rome Convention]]


<br>

**HOW ARE COVERS PROTECTED?** [[question]]
- They are <u>essentially infringement</u>
- If you do not have a a statutory licence, **then legally you cannot make covers of songs**
- However, ==these covers **are a great marketing tool** and **help in bringing more fame to the song**==

<br>

**WHAT IS THE SUBJECT MATTER OF THE COPYRIGHT ACT?**
- tHAT WHICH IS PROTECTED BY COPYRIGHT -> THAT WHICH IS PRTECTED UNDER <mark style="background: #00FFFE73;">**section 13 of the copyright act**</mark>  ![[17th August 2022  ✍-1.png]]

<br>

**WHAT IS OPEN LIST AND CLOSED LIST?**
- ! OPEN LIST
	- the subject matter of  copyright may be added by a legslative intervention or judcial interpreation
- ! CLOSED  LIST
	- everyting hads to be specified in the legislation
	- **nothing that is not mentioned in the legislation can be mentioned as part of the subject matter**
		- ==India follows the **closed list**==

---
## <mark style="background: #00FFFE73;">**SECTION 13 - SUBSISTENCE IN WORKS**</mark> 
![[17th August 2022  ✍.png]]
- Copyright ==**protects the creators of these works**==

<br>

### Literary Works
**<mark style="background: #00FFFE73;">Section 2(O)</mark>** 
1. Titles are not copyrightable in itself ❌
2. Databses ✅
3. Judgements -> arrangement of judgements and databases that facilitate search of these judgements -> **copyrightable**
4. Sermons of religious preachers
5. Question papers
6. Dictionaries 
	- *question arose in an indian case whether dictionaries can be copyrighted; the court answered in affirmative 🟢* 
7. Computer programmes -> Case by case basis
8. **Author/Owner** -> person who **causes such work to be created** 
	- An author/owner are **<u>not necessarily the same</u>**

![[⚖️ University of London Press v University Tutotrial Press (1916)]]

---

### Dramatic WOrk 
**<mark style="background: #00FFFE73;">Section 2(H)</mark>** 

- Drama 
- Recitation
- Choreography
- Mime
- Scenic arrangement or acting form fixed in writing
- Originality is the threshold
- Authorship to the creator

----
### Music Works and Sound Recording

#### Musical Work s2(y)
1. Have ==**notatons**== -> are **used to protect musical works**
	- *carnatic music works do not have copyright protection*


#### Sound Recording s2(xx)
![[17th August 2022  ✍-2.png]]
1. Anything **produced in a studio**

>The Owner is the producer ( the label or any person who has a control on the work)


