---
Number: 1
Week: 3
MainTopic::
Topics:
- 📌 [[sweat of the brow doctrine]]
Status:: #complete
Tags: 
- reading 
- case 
- IPR
Type:: #case
Module: 
---

# **Case** ⚖️ : ***University of London Press v University Tutotrial Press (1916)***

```ad-Case
title: **Case Details**

- **Name of Case**: ***University of London Press v University Tutotrial Press (1916)***
- Citation: 
- Year:: 1916
- Bench Size:
- Subject: #IPR

```

---
## FACTS
- 
	- ==**University of London**== invited 2 profs -> Lodge and Jackson to make examination papers of elemtnary mathematics
	- University of London Press -> intended to publish these papers -> the **University did not appoint thes eprofs for th fulltime job; rather they <u>provided their "services to the University"</u>**
		- the profs wer **not obligated ot the uni** since thery were **not in direct employment of the Uni of London** 🔴
-  
	- Defendant (Press) -> published various question papers -> three of them similar to that of the Plaintiff's examination papers
	- As a result -> **University of London press commenced lgal action** adn the **question of copyright arose**
	- The key issue -> **<u>whether question papers can be considered as literary work enjoying copyright protection</u>**


---
## Issues?
1. Can qps be considered to be **literary work under copyright**?
2. Can Uni Tutorial Press **get away with the defence of educational purpose?**

---
## HELD
1.  
	- Question papers are copyright
	- Because the professor have **used their intelligence and creativity to ake these question papers**
2.  
	- The professors **own title** 🟢 and **not the ownership** 🔴; this is because  the Universily of london **<u>only transferred the right to publish the paper</u>**
	- The Press also **only holds the title to publish the paper** 
3.  
	- The Press **<u>cannot get away with the defence of educational purpose</u>**
	- Because the **university tutorial press made money out of it**
	- The Tutorial Press **<mark style="background: #FF0000A3;">did no ask fro permission from teh uni to publish the qps</mark> **
	- Defence of Educational purpose cannot be used because **this is a case of [[Unjust enrichment]]**
4.  
	- <mark style="background: #D2B3FFA6;">***"What is worth copying is worth protecting"***</mark> [^1] 
	- 

<br>


>  
> - ==**WOrk made for hire**== relatinship
> - ==**Comissioner - commissioned relationship**== the work was comissioned; **independent contractor relationship**



---

# My Notes
[[Drawing 2022-08-20 21.41.05.excalidraw|1500]]

> [!Case] Summary - [[⚖️ University of London Press v University Tutotrial Press (1916)]]
> 
> ## Facts
> -  
> 	- Senat of Univeristy of london -> passed resolution that *<u>**any copyright possesssed by the examiner in examination papers -> shall be vested in the university**</u>*
> 		- That the copyright will **not apply to drawings**
> 		- University will **raise no objection to the use of such examiner without payment** of the maerial of any paper set by him fo r**any purpose exept the republication of such paper as a whle**
> 	- Examiners were appointed -> Lodge and Jackson
> 
> <br>
> 
> 
> -  
> 	- Examiners were **not staff of the university**
> 	- Examiners were **not bound to give their services exclusively to the university**
> 	- Thus, they made papers for the University and later **entered into an agreement with the University of London Press**; the univerity agreed with the plaintiff company to **assign the copyright** and by deed **assigned it to teh plaintiff company (ULP)**
> 
> <br>
> 
> - <u> **AGREEMENT BETWEEN THE UNIVERSITY AND THE ==UNIVERSITY OF LONDON PRESS==**</u>
> 	- Agreement provided that after August 31st 1915,  the **univeristy should from time to time prepare and issue or cause to be prepared and issued any examination papers**
> 	- > The uniersity agreeed from time to time to **assign and make over to the ULP** all such copyright and rights of publication if any as the University might have in such papers fro the period of 6 years from the date of publication 
> 		- Purusant to this agreement, the university **assigned to the ULP** all the **copyright and rights of publication of the University** in a **set of papers** which also ***included the papers prepared by the Lodge and Jackson*** 
> 			- $ The ULP proceeded to **publish the papers** 
> 			- IN the same month, Defendant ==**University Tutorial Press**== ->issued a publication; these contained papers that were **not copied from the publication of the plaintiff ULP** but were **taken from teh copies of the examination papers supplied by students**
> 				- ! amongst these papers, <u>**16 of them were set by Profs Lodge and Jackson**</u>
> 
> <br>
> 
> - ULP commenced action against UTP for infringement of copyright and Profs Lodge and Jackson joined as co-plaintiffs
> 
> ---
> ## Issues?
> 1. Are these examination papers Subject of copyright?
> 
> 
> ---
> ## Held
> 1. **THERE MUST BE ==USE OF THE COPYRIGHT *DIRECT OR INDIRECT*==** **OF THE WORK OF TH EPLAINTIFF**
> 	- What is worth copying is *prima facie* worth protecting
> 2.  **WHETHER THE EXAMINATION PAPERS CAN BE DEEMED TO BE LITERARY WORK**
>	> 📘 Section 1(1) of Copyright Act of 1911 -> provides for copoyright in **every original literary dramatic musical and artistic work**; subject to certain conditions (which for the instant case are immaterial)
> 	- Section 35 shows what among other things includes copyright; it lists things such as *maps, charts plans, tables and compilation*
> 	- ~ Held: **"Literary works"** would cover work which is **expressed in print or writing** ***irrespective of the question whether the quality or style is high***
> 		- ~ Thus, ==papers set by examiners **are "literary works"**==m within the meaning of the Act
> 
> 1.  **WHETHER THE EXAMINATION PAPERS BEING "LITERARY WORK" CAN BE SAID TO BE ORIGINAL**
> 	- Original in this connection **does not mean** that the work must be **"expression of original or inventive thought"**
> 		- copyright act is **<u>not concerned with the originality of ideas</u>**; rather, it is concerned with teh <mark style="background: #00FF3E8C;">**expression of thought**</mark>; in the case of the literary work, the copyright act is concerned with the **thought in print or writing** 
> 	1. The Act does not require tha tthe work must be in an original or novel form; but tha tth **work must not be copied from another work** 
> 	2. ~ The papers which Lodge and Jackson prepared **originated from themselves** and **were thus original** within the menaing of the Act
> 	3. Even though Lodge and Jackson drew upon the stock of knowledge common to mathematicians, the work is still original; if the rule was that *an author for purposes of dcopyright must not draw on the stock of knowledge which is common to himself and others who are students of the same branch of learning, then <u>only those historians who discovered fresh historical facts could acquire copyright for their works</u>*
> 
>       >⚖️ Papers set by Lodge and Jackson are thus **original literary work** and **proper subject for copyright** under the Copyright Act
> 
> 1.  **IN WHOM DID THE COPYRIGHT VEST**
> 	- 📘 The Act provides that he **author of the work** is the first owner of copyright
> 		- the only exception to his -> lies in **cases where the <u>author was under a contract of service or apprenticeship</u>**
> 		- **DISTINGUISHING <u>CONTRACT FOR SERVICE</u> AND <u>CONTRACT OF SERVICE</u>**
> 			1. <u>CONTRACT FOR SERVICE</u>
> 				- Intellectual propeorty **would belong to the author**...***subject to any agreement entered into the contrary***
> 			2. <u>CONTRACT OF SERVICE</u>
> 				- Involves existence of a **master slave relationship** where the **person rendering services** is **obligated to obey the orders of the person who is demanding these services
> 				- ! In these cases, the **Intellectual property** belongs to the employer
> 			- **<u>APPLYING THESE CONCEPTS TO THE PRESENT CASE</u>**
> 				- The examiners **continued to be regularly employed by other instituions**
> 				- They were **free to perform the work assigned by the University** in their **own time** as long as it was complete before the final deadline
> 				- ~ Thus, the two defendants were engaged in a ==**contract FOR service**==
> 					- thus, the **examiners were the <u>first owners of the copyright</u>**
> 						- ! however, the **employment contract** stated that the **<u>two examiners were *obligated to assign their copyright to the University*</u>**  => Therfore, the ==**University was <u>equitably entitled to the contract</u>**==
> 							- $ Now, since the University **transferredd this equitable right over the copyright to the plaintiff company aka ==University of London Press==** => Thus ULP is now **<u>equitably entitled ot the copyright</u>**
> 								- ~ In order to sue for infringement, the **plaintiff company** must either *obtain a proper assignment of the copyright* or *join the examiners who are the legal owners of the copyright of the parties*
> 									- while it has not obtained the assignment,<mark style="background: #00FF3E8C;"> it has in the **joined Prof Lodge and Jackson** as **co-plaintiffs** in the course of action</mark> 
> 										- The plaintiffs **can** therefore **sue for infringement of the copyright in the papers prepared by Lodge and Jackson** ; however, owing to the absence of the other examiners, the action fails in respect of the copyright in the papers that were made by them
> 
> 1. **WHETHER UTP INFRINGED THE COPYRIGHT IN THE PAPERS PREPARED BY LODGE AND JACKSON**
> 	- Concept of [[Fair dealing]] implies that **any copyrighted work** can be **used w/o permission** **<u>as long as it is only for the purposes as stated in the Act</u>**
> 		- ! Mere republication of copyrighted work **would not be considered as fair dealing only because it was intended to be used for private study**
> 	- Present case -> D published papers published earlier by P; While issuing publication, D had included answers to two examination papers; however, **<u>no attempt to provide answers for the advanced papers were taken</u>** 🔴
> 	- Furthermore, D had **only published eleven lines based on the difficulty of the question** 🔴
> 	
>	 > Thus, the **UTP (D) <u>had appropriated the work of ULP</u>** and **its conduct *did not fall within the scope of [[Fair dealing]]* **
> 
> 


<br>


<br>

> [!info] Key Points
> 1.  
> 	- Copyright vests in literary works and it is **not dependant on the quality or style**
> 2.  
> 	- Copyright is not concerned with originality of ideas; rather, it is concerned with the **expression of thought** 
> 3.  
> 	- Copyright does not demand novelty; just that the  person **must not have copied from another work** 
> 4.  
> 	- Copyright **normally vests in the author** 🟢, **<u>unless there's a contract to the contrary</u>** 🔴
> 
> 







<br>


---












[^1]: **<mark style="background: #FF0000A3;">This maxim has been very much criticised</mark>** ; *the origin of creation is not given importance in this case*