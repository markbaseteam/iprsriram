---
Number: 3
Week: 3
MainTopic::
Topics:
Status:: #partiallycomplete
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---

# **Case** ⚖️ : ***Nichols v Universal (1930)***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Nichols v Universal (1930)***
- Citation: 
- Year: 
- Bench Size:
- Subject: #IPR

```

---
## Facts
- This and RG Anand are so similar
	- both concern **two plays (one concerns a play and a movie)**
- Question ==**difference between <u>concept and expression</u>**==
	- Dispute b/w Jewish father and Irish father

---
## Issue
1. Because of similarites, can one be said to be the copy of the other?

---
## HELD
1.  
	- If amin similarity is that problem b/w Irish father and Jewish father, then it is ==**not a violation**== 🔴[^1]
	- The **mere subsection of the plot** -> is **<u>not subject to copyright 🔴</u>**[^2]


---
# Quick Summary

## Facts
-  
	- Plaintiff P -> alleged that the **copyright in her play** concering 
		1. *a marriage between a Jewish man and an Irish women*
		2. *resulting difficulties b/w both families*
	
		was **infringed by defendant's movie** which ***also concerned*** *marriage of an Irishaman and Jewish women the differnces between the families*


> [!multi-column]
> 
> > [!note] First film
> > - Son -> courtin a young Irish Catholic girl already married her secretly before a protestant minister; he is **concerned to soften the blow for his father**
> > - he thus seeks to make a **favourable impression of his wife** and **conceals her faith and rac**
> > - He introduced her to his father at his home as a Jewess; conceal sth emarriage; girl follows the plan dad takes the bait; concludes that they must marry; he calls rabbi for the wedding acc to jrewish rites
> > - Girls father; intense in relgiious antagonism; arrives at the hous at the moment of marriage celebration ; he is too lat to prevent it ; both feathers infuriated -> grotesque antics ensue
> > - Years later; young couple **abjured by their fathers**; left to their own resources; they have twins a boy and girl; 
> > - Later, both grandparents go the the home to see their grandkids each laden with gifts; one for a boy th eother for a girl;
> > - After some **slapstick comedy** -> ==**they reconcile when they learn th truth that each dchild hs been given the name of a grandparent**==
> > - Play ends with fathers exchanging amenities
> 
> > [!note] Second Film
> > - 2 families jewish and irish; living side by side in NY; in perpetual state of enimity
> > 	- Jews have daughter; Irsh son; they **are in love and marry**
> > - Jew -> learns from his lawyer that he has fallen heir to a large fortune froma  great aunt; moves into a great house; 
> > 	- irish boy seeks out his jewish bride -> chased away by the angry father
> > 		- Jew abuses the irishman over phone -> both become angry
> > - Jewish daughter dislcoses marriage to her mother; upon his return from florida, father finds out about the marriage; is **enraged**
> > 	- Irish family comes to Jew's house; **Jewish dad disowns da daughter** -> Irish man takes her to his lodgings
> > - The lawyer was planning to marry the daughter; after seeing his plan foileed, he **tells the jew that his fortune really belongs to the Irishman who was also related to teh dead woman**; however he offers to conceal his knowledge if the jew shares the loot
> > 	- Jew is astonished; walks to his enemy's house; ==**surrenders the proeprty**== tells the truth
> > 	- they reconile; 
> > 	- >Jew pays attention to the grandchild but this is **a minor motive to the reconciliation**;
> > 
> 



---
## Held
> [!note] Key ruling
> As a general rule, the idea /expression dichotomy holds that ideas are never copyrightable, though the expression of those ideas may be subject to copyright protection. While a plot is more of an idea, the court recognizes that in some cases the play may nonetheless be copyrightable, though not in this case.

1.  **WHEN CHARACTERS CAN BE COPYRIGHTED?**
	- ! The **less developed the characters**, the **less they can be copyrighted** #important #important 
2.  
	- In this case the stories are different; 
		- one talks about **father who does not want to marry his child outside his faith** who opposed by **another who is just like him in this regared**
		- The **difference in race is merely incidental to the theme** 
		- They **sink their differences ==through grandparental pride and affection==**
	- In the otherer play -> **zealotry is wholly absent**
		- ! religion does not even appear
		- through parents are hostile to each other becasue they differ in race, ==**the marriage of their son with a jew does not piss of the family at all**== ; it **exacerbates the animosity of the jew **<u>because he is rich</u>** #important 
		- $ They are reconciled through the **generosity fo the jew** and the **honesty of the Irishman** 
			- ! in this case, the grandchild **has nothgint to do with this** 

1.  
	- In this case, D has **not taken from P more than prototypes have contained for many years**
2.  
	- The lovers in the plays are faintly indiciated
		- ~ it is perfectly within D's rights to include lovers in the play
	- ! The P's Jew is **unlike the Jew of the defendants** 
		- while's P's Jew is obsessive about relgiion; he is affectionate warmm and patricarchal
			- **these do not fit the description of the D's Jew** 
	- While both the Jewsih are grotesque, **thse common qualities make up only a small part fo tehir simple pcitures** and **no more than one might life if they chose**
	- ! The irish fathers are even more unlike, the plaiff's a mere symbol for religious and patriarchal pride; and the other bears none of these feature
3.  
	- The plaintiff's copyright ==**does not cover everythings that might be drawn from her play**==
		- some of her content **went to some extent into the public domain** #important 




> [!Note] Key takeaways
> 1. Scene by scene similarity = infringement




[^1]: Link this with the idea of tropes; 
[^2]: ![[⚖️ Nichols v Universal (1930).png]]

