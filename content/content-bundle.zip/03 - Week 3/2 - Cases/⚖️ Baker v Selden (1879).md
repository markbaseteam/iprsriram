---
Number: 2
Week: 3
MainTopic::
Topics:
Status:: #complete
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---

# **Case** ⚖️ : ***Baker v Selden (1879)***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Baker v Selden (1879)***
- Citation: 
- Year:: 1879
- Bench Size:
- Subject: #IPR

```

==**Jump to [[#quick summary]]**==

---
## Facts
- A person had wriiteen a books on accounting systems and had provided a format to caputre information/data
	- this was in the form of a ledger
- Another person came in; they went ahead an captured/copied a **lot of the method of capturing date**
- Plaintiff alleged that R had **replicated column**
- Initially ruled in favour of P




## Issues
1. Whether these are copyrightable at all
2. Can we consider this **worth copyrighting**?
3. What is the **extent of Copyright**
4. Whether D had **committed copyright infringmeent**



## Held
**Whether these are copyrightable at all**
- Yes
- table also comes within copyrihgtable paradigm
- P's interpretation is also copyrighted


<br>


**Can we consider this worth copyrighting?**
 - table also comes within copyrihgtable paradigm

<br>


**What is the extent of Copyright**



<br>


**WHETHER THE ACTIONS OF D ARE A VIOLATION**[^1] [^2] 
- It does not really show that the D had violated copyright
- There were **substantive differences between the ledgers created by D and P**
	- their **functionalitie were different**
- The ==**functionality is still up for grabs**== 
	- If you wanted to protect <u>functionality</u>, you **should have filed a patent**

----

# quick summary

> [!Case] Baker v Selden Summary
> ## Facts
> -  
> 	- Charles Seldern -> **testator of the complainant in this case**
> 		- 1859: took the required steps for **obtaining the copyright of a book** -> **==exhibited and explained a peculiar system of book-keeping==**
> 			- >The book descibed an **improved system of book-keeping** and it contained **20 pages of book-keeping forms**; it also contained **examples and an introduction**
> 	- Complainant filed suit for ==**alleged infringement of thse copyrights**==
> 		- Complainant C filed **suit against <mark style="background: #00FF3E8C;">Baker</mark>** who was the **defendant D** for an **<u>alleged infringement of copyrights</u>**
> 		- >Baker hdad **produced a book describing a similar system** akin to Selden's 
> 
> #### Contentions
> 1.  
> 	- C contended that D had **infringed the copyright** by **using account books with columnds and headings similar to those explained in the copyrighted work** 
> 
> ---
> ## Held
> 1.  **WHETHER THE TRUTHS OF SCIENCE OR THE METHODS CAN BE SUBJECT TO COPYRGHT?**
> 	- Where the **truths of science or the methods of an art** are the **common property of the whole world 🌍** => an author <mark style="background: #00FF3E8C;">has the **right to express such science or art in his own way**</mark> 
> 		- thus even though Baker *made use of account books arranged on substantially the same saystem as that in Seldon's book*, this **did not amount to violation of copyright** 🔴
> 1.  **DISTINCTION BETWEEN THE <u>BOOK AS SUCH</u> AND THE <u>ART WHICH IT INTENDED TO ILLUSTRATE</u>**
> 	- A work on the subject of bookkeeping though only **explanatory of well-known systems** -> ==**may be the subject of copyright**== ; however in this case, it is **claimed only as a book**
> 	- ! But there is **clear distinction b/w** the **book as such** and the **art which it is intended to illustrate**
> 		- *while a book on composition and use of medicines would be subject of copyright, **no one can contend** that the **copyright of such book would give exclusive right to the art or manufacturer described therein** *
> 	- ~ Copyright only give **exclusive right of printing and publishing the book**; it **<u>does not secure the right to the manufacture and the sale of the thing</u>**
> 2.  
> 	- A book **does not give teh author 🔴** the **right to exclude others from practicing what was prescribed in the book** 
> 	- >a book did not give an author the right to exclude others from practicing what was described in the book:
> 3.  
> 	- ! Copy right vs Patent Law
> 		1. <mark style="background: #00FF3E8C;">**Exclusive rights**  to **"useful art"**</mark> is conferred ==**only by patent**==
> 		2. The **<u>description itself</u>** -> **protectable by copyright**
> 	- >Selden in this case **had a copyright and not a patent** 
> 
> 
> > - In the present case -> Selden explained an described a system of book-keeping and illustrated his method by means of ruled lines and blanked coluns with proper headings on a page or on successive pages
> > 	- No one has the right to **print or publish his boook** or **any material part thereof**
> > - However, <mark style="background: #00FF3E8C;">**any person** may **practice adn use the art itself** which has been **described and illustrated in the book**</mark> 
> > - The use of the art -> **totally different fomr a publication of the book explaining it**
> 
> <br>
> 
> 
> > [!Case] Verdict
> > 1. Blank account books -> **not the subject of copyright** 
> > 2. Mere copyright of Selden's book **did not confer uon him exclusive right to make and use account books, ruled and arranged as described and illustrated by him in his book**
> 

[^1]: Copyright is not a sufficient protection for software; 
[^2]: Criticism: copyright **does not protect functionality** of the creation