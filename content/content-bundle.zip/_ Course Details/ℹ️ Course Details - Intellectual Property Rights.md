---
metatable: true
Cover:: https://wallpapercave.com/wp/wp4332843.jpg
tags: [ " #7thsemester #IPR #course  "]
aliases: 🏫 IPR, 🏫 Intellectual Property Law, 🏫 Intellectual Property Rights
Semester: 7
up:: [[Semester 7 👨‍🎓]]
embedded-title: false
cssclass: [noyaml fullwidth max, table-numbers, table-lines, table-small]
banner_icon: 🏫
---


# Course Details: Intellectual Property Rights ℹ️
- **Course Name:** ==**Intellectual Property Rights**== #IPR
- **Semester**: 7
- Course_Instructor::  [[Lakshmi Srinivasan]]
- <u>Office Hours: Monday/Friday 5 - 7 pm</u>
- Credits: :  4
- Course_Manual:: [[Course Manual - Intellectual Property Rights (IPR).pdf|Course Manual]]

[[All IPR Notes]]
<br>


```cardlink
url: https://academic.oup.com/jiplp?searchresult=1
title: "Journal of Intellectual Property Law & Practice | Oxford Academic"
description: 
favicon: //oup.silverchair-cdn.com/UI/app/img/v-637932522553813691/favicon-32x32.png
image: https://academic.oup.com/data/sitebuilderassetsoriginals/live/images/jiplp/jiplp_ogimage.png
```





---

## Assignments 📝
Tags: #complete #inprogress #pending #incomplete | #important 

```dataview
table without ID
	Marks,
	file.link as Assignment,
	Due as "Due Date",
	Status 
from #IPR and #assignment 
sort Due ASC
```


---
## Course Content
````ad-Reading
title: Modules
color: 255, 150, 0

```dataview
list
from #module AND #IPR 
sort Number ASC
```
````

<br>


> [!card]- Flashcards
> ```dataview
> list
> from #IPR and #flashcards 
> ```

> [!Concept]- Concepts
> 
> <br>
> 
> ```dataview
> table without ID
> 	file.link as Concept,
> 	Meaning as Explanation
> from #IPR and #concept 
> sort file.name ASC
>  
> ```
<br>


<br>


<br>

---
### READINGS AND CASES 

#### Readings

````ad-Reading
collapse: open

```dataviewjs
for (let group of dv.pages("#IPR and #reading and -#case").where(p => p.Week).groupBy(p =>  p.Week)) {
	dv.header(4, group.key);
	dv.table(["Reading", "Author", "Topics", "Status"],
		group.rows
			.sort(m => m.Number, 'asc')
			.map(k => [k.file.link, k.Author, k.Topics, k.Status]))
}
```
````

```button
name 📖 Add Reading
type command
action QuickAdd: 1 - Reading Intellectual Property Law

```
^button-20q3






<br>


<br>


<br>


#### Cases
````ad-Case
collapse: open


```dataviewjs
for (let group of dv.pages("#IPR  and #case").where(p => p.Week).groupBy(p =>  p.Week)) {
	dv.header(4, group.key);
	dv.table(["No.", "Reading", "Status"],
		group.rows
			.sort(m => m.Number, 'asc')
			.map(k => [k.Number, k.file.link, k.Status]))
			
}
```

````

```button
name ⚖️ Add Case
type command
action QuickAdd: 2- Case Intellectual Property Law

```
^button-n0r6



<br>


<br>


<br>

---
### LECTURES 
````ad-note
title: Lectures
collapse: open

```dataviewjs
for (let group of dv.pages("#IPR and #lecture").where(p => p.Week).groupBy(p =>  p.Week)) {
	dv.header(4, group.key);
	dv.table(["No.", "Lecture", "Topics", "Module", "Status"],
		group.rows
			.sort(m => m.LectureNumber, 'asc')
			.map(k => [k.LectureNumber, k.file.link, k.Topics, k.Module, k.Status]))
}
```

````


```button
name ✍ Add Lecture Note 
type command
action QuickAdd: 3 - Lecture Intellectual Property Law

```
^button-qx0u

<br>

---
## Misc.
1. [[CopyRight Introductory Note]]

---
![[Caselist IPR]]
