### Readings
#### Week 1

[[📖 Theoretical Justifications for Intellectual Property]]

[[📖 Theories of Intellectual Property]]



<br>

### Cases

<br>

### Lectures

[[3rd August 2022  ✍]]
[[4th August 2022  ✍]]