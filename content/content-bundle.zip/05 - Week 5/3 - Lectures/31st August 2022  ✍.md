---
Week: 5
LectureNumber:  9
Topics:
- 📌 [[moral rights (IPR)]]
Date:  2022-08-31
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  31st August 2022 - Intellectual Property Law L(9)
Type:: #lecture
---


# **Lecture Notes** 📝 :  31st August 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  31-08-2022**
- Week: 5
- Lecture No.:  9
- **Semester**: #7thsemester 
- [Link to Lecture]

```
Status:: #complete
Module:: 


> **Outgoing Links: `$= dv.current().file.outlinks`**

---
# Recap
- <u>Copyright exists when</u> 
	1. It shoudl **fit within the subject matter**
	2. Fixation
	3. **Originality**
	4. It is **not hit my [[Doctrine of Merger 📌]]**
-  The work in consideration -> should be a **copyrightable work**
	- they should be able to **get their due for what they created**


---
# Class Notes ✏️
## Economic RIghts vs Moral RIghts
-  
	1. [[moral rights (IPR)]]
	2. [[Economic Rights (Copyright)]]
-  
	- THere is an element of emotion involved when it comes to **copyrightable work**
		- the author has **infused thier personality** 

![[moral rights (IPR)]]


![[⚖️ Amarnath Sehgal v Union of India]]




![[⚖️ Mannu Bhandari vs Kala Vikas Pictures 1987]]

---
### Regarding Waiver
- The judge-made law and the **legislature** are ==**silent on the question of waiver**==






----
# Doubts




----
# Summary