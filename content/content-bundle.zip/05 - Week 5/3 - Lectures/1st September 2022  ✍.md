---
Week: 5
LectureNumber:  10
Topics:
- Economic Rights

Date:  2022-09-01
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  1st September 2022 - Intellectual Property Law L(10)
Type:: #lecture
---


# **Lecture Notes** 📝 :  1st September 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  01-09-2022**
- Week: 5
- Lecture No.:  10
- **Semester**: #7thsemester 
- [Link to Lecture]

```
Status:: #complete
Module:: 

---
## [[Economic Rights (Copyright)]]
### Conceppt
![[Economic Rights (Copyright)]]

<br>

-  
	- Copyright is a **bundle of rights** Consists of 
		1. moral 
		2. economic and
		3. neighbouring rights
	- No common law protection - no copyright **except as provided under the act** - <mark style="background: #00FFFE73;">section 16</mark> 
		>![[1st September 2022  ✍-11.png]]



<br>




----
### How each subject matter deals with economic rights?

> [!abstract] Note
> Section 14 deals with **Economic rights** 

#### Literary Music and Dramatic Works
> ![[1st September 2022  ✍-5.png]]
1. COnvered under <mark style="background: #00FFFE73;">**sction 14(a) of the Copyright act**</mark>  ![[1st September 2022  ✍.png]] ![[1st September 2022  ✍-1.png]]
	- reproduction of the work w/o the **author's consent** is **foribidden*
- ~ Francis Day vs Hunter V bron
	- test of reproduction
	- how do you decide if a **rprudciont of the work** has been done without author's consent?
		1. substantial similarity with the works of the author
		2. we should be able to **establishe connection** between the **copyright and subsequent work**
	- The threshold of finding similarity/differences etc is ==**much higher in literary, msucial and dramatic works**==
		- eg: there may be tones/melodies similari in a lot of songs; 
	- ! Blatant cases - subject to copyright 
- ~  Case: 
	- Gathering - few nurses in a particular wing; it is like **mimicking in front of some of your friends** 
	- Moeny was **not taken from the audience that was to perform** 


<br>


<br>


#### Computer programs
> ![[1st September 2022  ✍-6.png]]

- <mark style="background: #00FFFE73;">Sections 14(a) and (b)</mark> ![[1st September 2022  ✍-2.png]]
- Reproduciton
- ==**Issues of copies ot the public**==
- Right of **[[rental]]**
- Making an **adaptation or translation of computer programs**

<br>


<br>


#### Artistic Work
> ![[1st September 2022  ✍-7.png]]
1. <mark style="background: #00FFFE73;">Section 14(c)</mark>  ![[1st September 2022  ✍-3.png]] ![[1st September 2022  ✍-4.png]]
2. Reproduction 


<br>


<br>

#### Cinematographic Film
> ![[1st September 2022  ✍-8.png]]


<br>


<br>

#### Sound Recording
> ![[1st September 2022  ✍-9.png]]

<br>


<br>

#### Designs v Artistic Works
> ![[1st September 2022  ✍-10.png]]

---
### Maanvee's Notes

> [!note] Maanvee's Notes
> ECONOMIC RIGHTS:
> 
> India has th emonist throry of rights economic rights are as long as moral rights. 
> Economic rights are different for diff works. 
> 
> A. Communication in public
> 
> Keep in mind factors like- gathering (Audience), financials. Where gathering is right in front of you, like a concert or performance, it will be communication IN public. 
> 
> B. Communication to public:
> 
> OTT services, the public does not need to be on front of you. This is communication TO public. Regardless of time, place, hour, whatever, you are  getting to consume this media. Like the OTT platform that has teh roght to Eyes without a face or Psycho. or any movie for thta matter, since the performance of movies are not happening in front of you. wa
> 1. reproduction
>  repitition 
> 2. dissemination
> 3. exhibition
> 4. broadcasting
> 5. communicate through visual and sound recording
> 6. commuincate by broadcast  transmission
> 7. communication to the public (making available) like OTT. The author of a work ahs teh right to make their work available ti audience regardless of place and time.
> 
> ALL theories give a ustification tp having economic rights. e rights justify the author making money out of their work. 2 ways: direct and indirect. Direct-  direct decision of the author involved, when say it comes literary works or book, the transfer  of is of the nature of licence- it is sharing, the author is still very much in control of his rights, they have not been waived or sold. Rights legitimise the decision making of the author. Indirect way- work made for hire, where the music dir makes music for movies, though the label is the owner of the msuic dir's work.  A R Rahman will be payed by the label and the movie producers everytime the bg score or songs of Delhi 6 are played, even though technically A R Rahman is not the owner of the Delhi 6 soundtrack.
> 
> Aside- the 2012 amendement says that the right to royalty cannot be waived. A R Rahman will be payed by the label and the movie producers everytime the bg score or songs of Delhi 6 are played. 
> 
> LDMA
> copyright is bunch of negative rights- rights given in exclusion to others. no law other than copyright act to safeguard your copyrighted material- except judgement based on copyrights act. LDMA prootected under s14. Reproduction rights solely ;ie woth the authors along with all related choices. No work can be reproduced w/o author's consent. Reprosduction msut have substantial similairy to previous. A connection must be estab;ished between the original and reproduced work. The threshold of finding inspiration and similarility between works is very high in LDMA. Otherwise tropes, genre similairity etc will be illegalised. The court is more likely to rule that there was no reproduction. 
> 
> COMPUTER PROGRAMS:
> Literary works- right given to author, what is protected is code, but functionality
> 
> ARTISTIC WORK:
> 
> 14(c)
> Reproduction