---
Number: 2
Week: 5
MainTopic::
Topics:
Status:: #partiallycomplete 
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---
#important 

# **Case** ⚖️ : ***Amarnath Sehgal v Union of India***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Amarnath Sehgal v Union of India***
- Citation::
- Year:: 2005
- Bench Size::
- Subject: #IPR

```

---
## Facts
- 
	- Sehgal -> well knownn sculptor
	- 1957 -> govt of India commission S to do a scultpor
	- Sehgal did some fabulour work of Bronze murals
-   
	- Once created; it was put out on display; govt of India after some time **pulled down the work**; they **dumped it**
	- Sehgal - made reporesentaions to restore the mural
-  
	- In 1991 -> S received letter from Ministry of Urban Development in reard of reinstating his  mural; no effort was made after the said letter
	- No proper action taken place
-  
	- Case fild under <mark style="background: #00FFFE73;">Section 57 of the copyright act</mark> 

---
## Issues
1. Question of Limiation - whether barred by limitation?
2. Whether the plaintiff had any rights under section 57 of the copyright act?
3. Has P's rights under s57 been violated

---
1.  
	- Letter -> given in 1991 -> thus you cannot fault P on limitaiton
2.  
	- IT was work made fo r hire; attribution rights, divulgation rights, moral rights of integrity and rights of retraction are automatically vested on P
	- All rigths except the **divulgation right** should be **==referred as author's moral riights==** and the **same to be vested in the plaintiff**
3.  
	- Lots of people think that **mutilation must exist** for integrity to be violated; <u>this was an argument posed by the govt of India</u>
	- Court held that **mutilation is nothing but demolition of author's work** so as to **render it imperfect** and is therefore **deterimental to the reputation of the author**
	- Thus held that **dispal8ying the distorted version of the author's work** may lead to the **impression of the author** among the viewers