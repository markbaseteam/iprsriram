---
Number: 1
Week: 5
MainTopic::
Topics:

Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---

# **Case** ⚖️ : ***Mannu Bhandari vs Kala Vikas Pictures 1987***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Mannu Bhandari vs Kala Vikas Pictures 1987***
- Citation::
- Year:: 
- Bench Size::
- Subject: #IPR

```

Status::  #partiallycomplete

---
- TV Series came out in much more different way that bhandari had conceived of in his book
- Is there mutilitation?
- yes there is mutilation
- [[Section 57 of the Copyright Act -  Author’s special rights]] was a **statutory recognition of the IP of the author** and therefore, **it should be protected with special care** 
- Section 57overrides the terms of the contract of assignment of copyright 
	- ! therefore, the **contract of assignment must be consistent with [[Section 57 of the Copyright Act -  Author’s special rights]]**  ^usg6rxy