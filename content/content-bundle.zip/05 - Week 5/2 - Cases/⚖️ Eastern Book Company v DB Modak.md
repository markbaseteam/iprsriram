---
Number: 
Week: 5
MainTopic::
Topics:
Status:: #partiallycomplete
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---

# **Case** ⚖️ : ***Eastern Book Company v DB Modak***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Eastern Book Company v DB Modak***
- Citation::
- Year:: 2007
- Bench Size:: 2
- Subject: #IPR

```

---
## FACTS
-  
	- Petitioners -> parternship firm -> engaged in **printing an publishing various books in the field of law**
	- One subch publiction is SCC -> consists of **all reportable and non-reportable judgements, short judgements other docs**
	- For this purpose,they get copies of juedgementws from the office of the registrar of the SC
	 - Theese re edited by **adding various inputs to make the judgements user friendly** such as
		  1. cross references
		  2. standardization
		  3. formatiting of text
		  4. paragraph number
		  5. other inputs

-  
	- EBC filed suit against Defendants who came out with a software; they had **allegedly taken the appellants copy-edited version of the SC juedgements as it is** -> allegd copyright infringement
--- 
## ISSUES
1. What is the **standard of originality** in **copy edited judgements of the SC** which is a ***derivative work***; 
	1. what would be required in a derivative work to **treat it as the original work of the author**, thereby conferring on it a **protected right**
2. Whether the **entire verison of copyedited text of the judgements published in the appellants' law report SCC** woudl be **entitled for copyrgiht as an original literary work**, the copy-edited judgemtns having been claimed as a result of **inextricable and inseprable admixture of the copy-editing inputs and raw text**?
----
## HOLD
1. **COPYRIGHT FINDS ITS JUSTIFICATION IN FAIR PLAY**
	1. When a person **produces something** with his **skill and labour**, it **normally belongs to him** and the **other person would <u>not be permitted to make a profit out of th skil and labour of the original author</u>
2. **COPYRIGHT IS <mark style="background: #FF5582A6;">NOT CONCERNED WITH THE ORIGINAL IDEA</mark>** **BUT WITH TH E<mark style="background: #00FF3E8C;">EXPRESION OF THOUGHT</mark>**
	- iT HAS nothing to do with originality or literary merit
		- 
3. **THERE ARE 2 KINDS OF LITERARY WORKDS**
	1. **Primary or prior works**
		- These  are works that are **not based on existing subject matters**
	2. **Secondary or derivative workds**
		- These are works **<u>based on existing subject matter</u>**
4. **NATURE OF COPYRIGHT IN JUDGEMENT**
	- Judgements are government works as per [[section 2(k) of the copyright Act]]
	- Under [[section 17(d) of the copyright act]], the govt in absence of agreement ot the contrary shall be the **first owner of copyright in govt work** 
	- 
		- [[Section 52 of Copyright Act - Certain acts not to count as infringement]] -> [[Section 52(q)(iv) of the Copyright Act]] **exempts** the following from **infringement**
			1. publication of the courts of unless such reprorduction is prohibited 
			2. #incomplete  and not relevant for this case
		- As a rsult, the **judicial pronouncements** would be in **public domain** adnd it s**reproduction or publication ==would not infringe the copyright of th3e first owner==** which is the ogvt
			- ! Since this is the position, the **copy-edit judgment** would **not satisfy the coyright <u>merely by established amount of skill, labour and capital in the inputs of the judgements**</u> ; original and innovative thoughts are necessary to establish copyright in the author's work**
5. **WHAT IS REQURIED TO ACHIEVE COPYRIGHT WHERE THERE IS A COMMON SOURCE**
	- It is necessary that the <mark style="background: #00FF3E8C;">**labour** adn **skill** and **capital**</mark> invested should be:
		1.  **sufficient to communicate or impart to the judgement some <mark style="background: #FF00868C;">quality or character which the original judgement does not possess</mark>**, and 
		2. which **<mark style="background: #FF5582A6;">differentiates</mark> the ==original judgement== from the ==printed== one**
	- Put simply, ther **derivative work** produced by the author should be **original in the sense** that **by virtue of <mark style="background: #00FF3E8C;">selection, coordiantaiton or arrangement</mark>** of ==**preexisting data**==, a <mark style="background: #00FF3E8C;">work of **somewhat diffent character is produced**</mark> by the author #important 
		- In case of law reports, the author **must add some distinguishable features and flavour into the judgement** that was delivered by the court
		- ! **Trivail variations or inputs in th ejudgement** will <mark style="background: #FF0000A3;">**not satisy the test of copyright**</mark> 🔴 #important 

> [!Case] Verdict
> - 
> 	- Coming to the present case -> the appellants engaged in **a category of inputs** which requires <mark style="background: #00FF3E8C;">**application of skill and judgement**</mark>:
> 		1. by segreegating existing paras in the original text by **breaking them into separate paras**
> 		2. by adding **internal para numbering** within a judgement and proviiding **uniform para numbering to the multiple judgements** and
> 		3. indicating in the judgements the **judges who have dissented or concurred** by introducing phrases such as *"condurring,, partly concurring, partly dissenting, dissenting, supplementing, majority expressing no opinion"*, etc
> 	- These have to be viewd in a differnt light; 
> 		- this enterpiriise involves **reading fo th whole judgemnt**, **understanding questioned involved**, **finding out whether judges have disagreed or have partially agreed** on a **particular matter**
> 		- ~ ⚖️ Held: **these inputs <mark style="background: #00FF3E8C;">enjoy copyright</mark>**
> 

<br>

> [!Concept] Concept applied
> Court held that the **principle** laid down by the Canadian court in [[⚖️ CCH Canadian vs Law Society of Upper Canada - 2004]] would be th eprinciple **applicable to copyright judgements of the APex court**
> 
> ---
> 
> >We make it clear that the decision of ours would be confined to the judgments of the courts which are in the public domain as by virtue of [Section 52](https://indiankanoon.org/doc/1013176/) of the Act there is no copyright in the original text of the judgments.
> 
> <br>
> 

----
> ### `fas:QuoteLeft`Quotes from judgement
> 
> [Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007](https://indiankanoon.org/doc/1062099/) [[Obsidian-Highlights]]
> 
> -   By virtue of [Section 52(1)](https://indiankanoon.org/doc/257434/) of the Act, it is expressly provided that certain acts enumerated therein shall not constitute an infringement of copyright. Sub-clause (iv) of clause (q) of [Section 52(1)](https://indiankanoon.org/doc/257434/) excludes the reproduction or publication of any judgment or order of a Court, Tribunal or other judicial authority, unless the reproduction or publication of such judgment or order is prohibited by the Court, the Tribunal or other judicial authority from copyright.
> -   he judicial pronouncements of the Apex Court would be in the public domain and its reproduction or publication would not infringe the copyright. That being the position, the copy-edited judgments would not satisfy the copyright merely by establishing amount of skill, labour and capital put in the inputs of the copy-edited judgments and the original or innovative thoughts for the creativity are completely excluded
> -   Accordingly, original or innovative thoughts are necessary to establish copyright in the authors work
> -   principle where there is common source the person relying on it must prove that he actually went to the common source from where he borrowed the material, employing his own skill, labour and brain and he did not copy, would not apply to the judgments of the courts because there is no copyright in the judgments of the court, unless so made by the court itself.
> -   o secure a copyright for the judgments delivered by the court, it is necessary that the labour, skill and capital invested should be sufficient to communicate or impart to the judgment printed in SCC some quality or character which the original judgment does not possess and which differentiates the original judgment from the printed one
> -   The task of paragraph numbering and internal referencing requires skill and judgment in great measure.
> -   Setting of paragraphs by the appellants of their own in the judgment entailed the exercise of the brain work, reading and understanding of subject of disputes, different issues involved, statutory provisions applicable and interpretation of the same and then dividing them in different paragraphs so that chain of thoughts and process of statement of facts and the application of law relevant to the topic discussed is not disturbed, would require full understanding of the entire subject of the judgment
> -   Making paragraphs in a judgment could not be called a mechanical process. It requires careful consideration, discernment and choice and thus it can be called as a work of an author. Creation of paragraphs would obviously require extensive reading, careful study of subject and the exercise of judgment to make paragraph which has dealt with particular aspect of the case, and separating intermixing of a different subject.


> -   [Eastern Book Company & Ors vs D.B. Modak & Anr on 12 December, 2007](https://indiankanoon.org/doc/1062099/) [[Obsidian-Highlights]]

> -   Although for establishing a copyright, the creativity standard applies is not that something must be novel or non-obvious, but some amount of creativity in the work to claim a copyright is required.
> -   It does require a minimal degree of creativity. Arrangement of the facts or data or the case law is already included in the judgment of the court. Therefore, creativity of SCC would only be addition of certain facts or material already published, case law published in another law report and its own arrangement and presentation of the judgment of the court in its own style to make it more user- friendly.
> -   The selection and arrangement can be viewed as typical and at best result of the labour, skill and investment of capital lacking even minimal creativity. It does not as a whole display sufficient originality so as to amount to an original work of the author.
> -   o support copyright, there must be some substantive variation and not merely a trivial variation, not the variation of the type where limited ways/unique of expression available and an author selects one of them which can be said to be a garden variety
> -   Novelty or invention or innovative idea is not the requirement for protection of copyright but it does require minimal degree of creativity. In our view, the aforesaid inputs put by the appellants in the copy-edited judgments do not touch the standard of creativity required for the copyright.
> -   However, the inputs put in the original text by the appellants in (i) segregating the existing paragraphs in the original text by breaking them into separate paragraphs; (ii) adding internal paragraph numbering within a judgment after providing uniform paragraph numbering to the multiple judgments; and (iii) indicating in the judgment the Judges who have dissented or concurred by introducing the phrases like concurring, `partly concurring, `partly dissenting, `dissenting, `supplementing, `majority expressing no opinion, etc., have to be viewed in a different light. The task of paragraph numbering and internal referencing requires skill and judgment in great measure. The editor who inserts para numbering must know how legal argumentation and legal discourse is conducted and how a judgment of a court of law must read.
> -   Often legal arguments or conclusions are either clubbed into one paragraph in the original judgment or parts of the same argument are given in separate paragraphs. It requires judgment and the capacity for discernment for determining whether to carve out a separate paragraph from an existing paragraph in the original judgment or to club together separate paragraphs in the original judgment of the court. Setting of paragraphs by the appellants of their own in the judgment entailed the exercise of the brain work, reading and understanding of subject of disputes, different issues involved, statutory provisions applicable and interpretation of the same and then dividing them in different paragraphs so that chain of thoughts and process of statement of facts and the application of law relevant to the topic discussed is not disturbed, would require full understanding of the entire subject of the judgment.
> -   Making paragraphs in a judgment could not be called a mechanical process. It requires careful consideration, discernment and choice and thus it can be called as a work of an author.
> -   Creation of paragraphs would obviously require extensive reading, careful study of subject and the exercise of judgment to make paragraph which has dealt with particular aspect of the case, and separating intermixing of a different subject. Creation of paragraphs by separating them from the passage would require knowledge, sound judgment and legal skill. In our opinion, this exercise and creation thereof has a flavour of minimum amount of creativity.