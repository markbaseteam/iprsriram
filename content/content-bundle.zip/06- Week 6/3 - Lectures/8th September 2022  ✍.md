---
Week: 6
LectureNumber:  12
Topics:
- Compulsory Licensing
- Cover Versions
- Platform vs content on platform
- Neighbouring rights
- Broadcasting Reproduction Rights
- Registration of Copyright
- Infringement
- Defences against infringement
Date:  2022-09-08
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  8th September 2022 - Intellectual Property Law L(12)
Type:: #lecture
---


# **Lecture Notes** 📝 :  8th September 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  08-09-2022**
- Week: 6
- Lecture No.:  12
- **Semester**: #7thsemester 
- [Link to Lecture]

```
Status:: #inprogress   complete [[#Defences]]
Module:: 

---
[TOC]

---
## Compulsory Licensing
![[Licensing Notes (IPR)]]
- Authorial works are different from cinematographic works
- Licenses -> in this case, the autho **does not have a dormant role**; 
	- in compulsory licenses, the works are **witheld from the public**; this applies to **unpublished Indian works** 
	- >A compulsory license is a term generally applied to a statutory license to do an act covered by an exclusive right without the prior authorization of the right owner. Compulsory licensing **allows for the use of protected (in this case, copyrighted material) without the prior permission of the owner of the right**.
- In the case of **oprphan works**k, you **do not know who the author is**
	- govt willing intervenor decides **who has the right to publish**
- Licenses can be terminated -> depending on the terms of the contract

<br>

-  
	- In assignment, the **author is dormant** 
		- the **assignee** takes care of things such as **infringement**
	- In the case of License, the author is **more in control** 

---
## Cover Versions
- These constitute copyright infringement
	- if you do not have a <mark style="background: #00FFFE73;">Statutorial license</mark>, then you **are committing infringement**
> - [[Section 31C of the Copyright Act]] deals with statutory licenses that may be obtained for making cover version of a sound recording in respect of a literary, dramatic or musical work.  ![[8th September 2022  ✍-2.png]]

### Platform vs content on platform
- THe platform is **generally not liable** ***unless*** there is a **court order** 

---
## Neighbouring rights
- Unique to ==**copyright**== owing to the **subject-matter**
	- Tehcnology has allowed us to **access these works** at any time/place
- THere is need to **acknowledge contributions fo other persons**
- Neighbouring rights protects 
	1. performers (actors/singers)
	2.   

![[Neighbouring Rights Notes (IPR)]]

---
## Broadcasting Reproduction Rights
> <mark style="background: #00FFFE73;">Section 2(dd)</mark> ![[8th September 2022  ✍.png]]

- First broadcast -> the author has tirhgt to decie **to whom to give braodcasting rights to**
- however, ***subsequently***, the broadcaster **decides when** to braodcast the right

---
- Case: ![[⚖️ Football Association Premier League vs British Sky]]
- Case:  ![[⚖️ Neha Bhasin vs Anand Ra Anand]] 🌕


---
## Registration of Copyright
- Registrar appointed by the Central govt under section 10  ![[8th September 2022  ✍-1.png]]

---
## Infringement
1. Whether the ownership in question is valid
2. What are the constitutent elements of the work
3. Whether these elements are present in the impugned work

<br>

- ! **TEST**
	1. Substantial Similarity Test
	2. Viewer Test

<br>

![[⚖️ Roger vs Koons]] 🟧

<br>


![[⚖️ C Cunniah v Balraj]] ✅


<br>


![[⚖️ Star India v Leo Burnett]] 🟧

<br>

### Defences
1. [[14th September 2022  ✍#Fair Use and Fair Dealing|Fair Use and Fair Dealing]]
2. [[De minimis Defence]] : **Defence against Infringement** - When there is **==very little copying==** coupled with **==no demonstratable harm==** 
3. [[First sale-exhaustion of rights]]
