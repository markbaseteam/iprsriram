---
Week: 6
LectureNumber:  11
Topics:
- Neighbouring rights
Date:  2022-09-07
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  7th September 2022 - Intellectual Property Law L(1)
Type:: #lecture
---


# **Lecture Notes** 📝 :  7th September 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  07-09-2022**
- Week: 6
- Lecture No.:  11
- **Semester**: #7thsemester 
- [Link to Lecture]

```
Status:: #inprogress  what are the problems with the 2012 amendments
Module:: 
[[board(2)]]

<br>

```toc
```

---
## CINEMATOGRAPH FILM
- **<mark style="background: #00FFFE73;">Section 14(d)</mark>**
	>![[7th September 2022  ✍-2.png]]![[7th September 2022  ✍.png]]![[7th September 2022  ✍-1.png]] 

- Cinematographic are **not authorial works** strictu sensu 🔴
- Potential financial injury
	- if you were to do an act, ***would it cause an injury or monetary injury*** to the **author** concerned
- Communication to public is always decided on a <mark style="background: #D2B3FFA6;">**case-by-case basis**</mark>

---
## Designs v Artistic Works
> ###### <mark style="background: #00FFFE73;">Section 15</mark> 
> ![[7th September 2022  ✍-3.png]]

- **WHY ARE INDUSTRIAL DESIGNS NOT PROTECTED IN A DIFFERENT FASHION COMPARED TO ARTISTIC WORKS?** ^wudfxox
	- Designs have the element of ==**functionality**== #important 


> **<mark style="background: #00FFFE73;">Designs act of 2000</mark>**
> - 
> 	- Copyrights protect works for 60 [[PMA]]
> 	- However, in the case of Designs, the protection isfor ==**10 years**==
> - 
> 	- In designs, there is a ==bformality==
> 	- however, in the case of **copyright**, the re is **no formality** 🟢
> 

> Colour schemes will be **protected under [[10th August 2022  ✍#2 Trademarks|Trademarks]]**

---
## Copyright Amendment Act, 2012
> - Video Javed Akthar
> - Cinematographic and Sounds and recoredings -> when the **legislation is silent**, then the ==**industry takes its course**==


---
## Work Made for Hire 
![[work made for hire]]

- These turn out to be [[25th August 2022  ✍#2 Contract for service]]
![[25th August 2022  ✍#1 Contract of Service]]

---

## Transfer of IP
- Where creator **transfers rights** to another person 
	- another person is given permisision to **exercise reights fo person who has created the work** 
- ! Thus, assignment and transfer are **different from that of [[work made for hire]]**
	- in [[work made for hire]] -> author knows ththi work is given to someone else #important 
	- In the former two, he first **creates the work by himself** and **<u>then the right is transferred</u>**  #important 
- The contract **has to be in writing**
---
### Assignment of Copyright

> ##### <mark style="background: #00FFFE73;">**SECTION 18**</mark>
> ![[7th September 2022  ✍-4.png]] ![[7th September 2022  ✍-5.png]]


---

- ~ Case
	- Salim suleiman; had an assignement for future works; meaning works that have not come into existence yet
		- something like a contingency contract
	- They wre ocmmissioned by Dharma for create music for Kurbaan; they created usic
	- As per work made for higehr, **dharma is the owner**
	- Noramllyk, D would have been owner under [[work made for hire]]
	- THus D went on and braodcasted the songs
	- ! However, they **faced a lawsuit**
	- WHy?
		- Becasue they hasd assignement of futuer works
		- ! clash between work made for higher and futeur works
		- ~ PRS is society to whom the rights were assigned; thern there was dharma who had the **sbusequent right for work made for hire** 
			- Since PRS came first, their rights will firs tbe asssigned to PRS; it included rights for future works
				- ~ thus, D **did not have claim over the works of Salim Suleiman** 

---
## Problems with the 2012 Amendments
### Section 17
> ![[7th September 2022  ✍-6.png]]
- read with section 13 -> Only confers **right to broadcast** and does not contend with the **structural problems that plague the industry**

<br>



### Section 18 
> ![[7th September 2022  ✍-7.png]]

- But, **how do you meansure th aworht of the author's contribution** to the **whole film**?
	- they will end up *getting peanuts.*
	- ! **ultimately, it is the <u>production company that takes away th elions share of the royalty</u> as it is to be <u>shared on an equal bases</u>** 

<br>

### The Industry in General
![[7th September 2022  ✍-8.png]]