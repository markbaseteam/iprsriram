---
Number: 
Week: 6
MainTopic::
Topics:
Status:: #incomplete 
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---

# **Case** ⚖️ : ***Star India v Leo Burnett***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Star India v Leo Burnett***
- Citation::
- Year:: 
- Bench Size::
- Subject: #IPR

```
- [x] Read [[⚖️ Star India v Leo Burnett]] ⏫ 📅 2022-10-08 ✅ 2022-10-11
---
## Facts
-  
	- Star India -> owner fo the copyright in a serial's theme and sartistic work which appeared on TV acc to Claue 6 of the agreement b/w Star India and Balaji Telefilms
-  
	- Producers and Marketers of Tide -> came up with teh advertsiement for Proctoer and Gamble
		- it showed a scene ==**resembling climax of the TV show and <u>dispalyed the artisitc work appearing on TV with the works"kyunki bahu bhi kabhi saas banegi"</u>**==
			- Star alleged that people will that that it license or produced the advertisement

---
## ISSUES
1. Have the defendants **by making th3e commercial film**  **<u>violated/infringed the plaintiff's copyright</u>** in the serial ***Kyun ki saas bhi kahi bahu thi***?
2. Have the plaintiffs' proved the defendants have **infringed the plaintiff's artistic work at exhibit C to the Plaint** 
3. Have the plaintiffs proved that the **defendants are guilty of [[Passing off (Tort)]] thier <u>reputaiton and good will int eh TV serial</u>** by **misrepresenting the connection between the Ps and Ds** thereby **causing damage to the Ps** and thereby **defeating the Ps character/merchandising rights?**


---
## Held
1.  
	- THe work in question is a **cinematographic film** under the Copyright Act
	- No prudent person will confuse the show with the 30sec advertisement
		- the court reached this conclusion after **analysing the similarities and dissimilarities b/w the show and the ad** 
2.  
	- There was **no scope for misrepresentation** as **the ad was aired on <u>channels different from where the show was aired</u>**; 
		- => thus, there was **no effect of the ad on the show** and the **likelihood of damage was too remote**
3.  
	- With regaards to [[Passing off (Tort)]] -> ther was **no common field of activity**
4.  
	- The **"State of mind of the public"** was necessary to see the goodwill of the characters in the TV soap
	- There was **no material on record to show** tha tthe **people will associate the ad with the show**

> [!Case] Key Takeaways
> 1.  Anything which is not a substantial copy of a film shall **not be liable tfor infirngmeent**
> 2.  **For it to constitute infringement,** the film has to **constitute an exact copy**
> 3.  **oRIGINALITY** requires **skill labour and judgement** in its creation