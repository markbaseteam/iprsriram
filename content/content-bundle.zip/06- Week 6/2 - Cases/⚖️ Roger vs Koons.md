---
Number: 
Week: 6
MainTopic::
Topics:
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---

# **Case** ⚖️ : ***Roger vs Koons***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Roger vs Koons***
- Citation::
- Year:: 
- Bench Size::
- Subject: #IPR

```

Status:: #partiallycomplete 

---
## Facts
![800|inlR](https://upload.wikimedia.org/wikipedia/en/thumb/0/04/Rogers_v._Koons.jpg/310px-Rogers_v._Koons.jpg)
- Art Rogers, a professional photographer, took a black-and-white photo of a man and a woman with their arms full of puppies. The photograph was simply entitled, Puppies, and was used on greeting cards and other generic merchandise.

- Jeff Koons, an internationally known artist, found the picture on a postcard and wanted to make a sculpture based on the photograph for an art show on the theme of banality of everyday items. After removing the copyright label from the postcard, he gave it to his assistants with instructions on how to model the sculpture. He asked that as much detail be copied as possible,[2] though the puppies were to be made blue, their noses exaggerated, and flowers to be added to the hair of the man and woman.

- The sculpture, entitled, String of Puppies, became a success. Koons sold three of them for a total of $367,000.

- Upon discovering that his picture had been copied, Rogers sued Koons and the Sonnabend Gallery for copyright infringement. Koons admitted to having copied the image intentionally, but attempted to claim fair use by parody. 

---
## Held
1.  **WHETHER SUBSTANTIAL SIMILARITY EXISTS?** 🟩
	- Yes  
	- The similarity was ==**so close**== that the ==**<u>average lawy person would recognize the copying</u>**==

1. **ON THE ISSUE OF FAIR USE?**
	- The court **rejected the parody argument**
		- this is because Koons **<u>could have constructed his paraody fo the gneral type of art</u>** ***without copying Rogers' specific work***
	- Koon here was **<u>not commenting on Rogers' work specifcally</u>** => thus his copying of that work **did not fall under the fair use exception** 🔴
	- > Koons' sculpture does not fall within any statutory examples. There was a faint suggestion in his argument that the sculpture, together with the other works in the "Banality Show, were intended to comment satirically upon contemporary values. But I construe the words "criticism" and "comment" as used in § 107 to ==**refer to such usage specifically addressed to the copyrighted work.**== **Koons' sculpture does not criticize or comment upon Rogers' photograph. It simply appropriates it.**