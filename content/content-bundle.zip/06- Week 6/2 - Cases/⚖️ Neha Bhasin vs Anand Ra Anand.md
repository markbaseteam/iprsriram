---
Number: 
Week: 6
MainTopic::
Topics:

Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---
- [x] Complete [[⚖️ Neha Bhasin vs Anand Ra Anand]] ⏫ 📅 2022-10-06 ✅ 2022-10-07

Status:: #partiallycomplete
# **Case** ⚖️ : ***Neha Bhasin vs Anand Ra Anand***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Neha Bhasin vs Anand Ra Anand***
- Citation::
- Year:: 
- Bench Size::
- Subject: #IPR

```

> Exploitation without the performer’s consent is an infringement of the performer’s right.
---
## Facts
- Plaintiff Neha basin -> alleged that her voice had been stolen and **falsely attributed** and **held out to be that of D2 aka Poonam Khubani**
	- P claimed that her voice had been used by te Ds for the three version fo the song S
	- alleged D in connivance with the Music Director had *shown herself to be the lead singer in credits* for the **three versions in the inlay card of the CD** and tht P had been shown as **backup vocalist** in **all thre versions of the song**; however, **==it was the voice of the plaintiff that was heard==**

---
## Held
1. ! If the **performance is recorded** and **thereafter exploited without the permission of the performer**, then the **performer's right is infringed**
2.  **<u>On violation of P's rights</u>** 
	- Every performance has to be live in the first instance, whether it is before an audience or ina studio
	- ~ Key rulling:: If the **performance is recorded** and **thereafter exploited <u>without the permission of the performer</u>**, then the **performer's right is infringed**
	- 
		- P's relationship with Ds -> **quasi contract**; governed by **Section 70(1)** of COntract Act
		- P lawfully did something for Ds; her **singing has been recoreded**; she **did not intend to do the act gratuitously**
		- Since there was no formal contract b/w them, the Ds **had the option to <u>not use her recordings at all</u>**; however, here since they have **opted to use the P's recoredings**, a ==**quasi contract comes into existence**== and thus <mark style="background: #00FFFE73;">**satisfies the requirements of Section 70**</mark>

- **<u>On the relief of Injunction</u>**
	-   Plaintiff has been wronged by not being recognised as lead singer; and
	-   **The Plaintiff has also been wronged as she has been demoted to a backup singer. This is likely to cause grave harm to Plaintiff’s reputation. Her aspirations to rise as a female vocalist would receive a big jolt if in the market she is perceived merely as a backup singer and not as a lead singer**.

---
> [!Case] Key Ruling
> - ~ Key rulling:: If the **performance is recorded** and **thereafter <mark style="background: #FF0000A3;">exploited <u>without the permission of the performer</u>**,</mark> ==> <mark style="background: #FF5582A6;">then the **performer's right is infringed**</mark>