---
Number: 
Week: 6
MainTopic::
Topics:

Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---
- [x] Read [[⚖️ Football Association Premier League vs British Sky]]  <progress value="8" max="10"></progress> ⏫ 📅 2022-10-06 ✅ 2022-10-06
# **Case** ⚖️ : ***Football Association Premier League vs British Sky***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Football Association Premier League vs British Sky***
- Citation::[2013] EWHC 2058 (Ch)
- Year:: 2013
- Bench Size::
- Subject: #IPR

```
Status:: #partiallycomplete

---
## Facts
-  
	- FAPL -> governing body of the football competition called Barclays Premier League aka BPL
		- It  is authorised by its member clubs to *license braodcasters throughout the wrold to <u>provide coverage of PL matches</u>*
	- ! FAPL -> owns **copyright** in **<u>recordngs of televesion footage</u>** of all PL matches and in artistic works that appeared in the footage
-  
	- Defendants D -> 6 main **retail Internet Service Providers (ISPs)**
		- FAPL brought a claim **seeking injuction against Ds**  purasuant to [[section 97A fo the Copyright, Designs, and Patents act of 1988]] which implements Article 8(3) of the Suropean Parliament and Council Direction of 2001 on the **harmonisation of certain aspects of copyright and related right sin the infomration society** requiring the Ds <mark style="background: #FF4E00A6;">to **take measures to block or at least impede access by cusomers8** to a website iknown  as ***FirstRow Sports***</mark>

---
## Rule
- [[section 97A fo the Copyright, Designs, and Patents act of 1988]]: Section 97A CDPA provides that the High Court shall “<mark style="background: #00FFFE73;">have power to grant an injunction against a service provider</mark>, where that service provider has **==actual knowledge of another person==** using their service to infringe copyright“.

---
## Held
1.  **IT IS NOT NECESSARY TO SHOW THAT THE PUBLIC TO WHICH THE RE-TRANSISSION WAS COMMUNICATED WAS <u>DIFFERENT FROM THE PUBLIC TO WHICH THE ORIGINAL TRANSMISSION WAS ADDRESSED</u>; THE <u>FACT THAT IT WAS A SEPARATE COMMUNICATION TO THE PUBLIC IS ENOUGH</u>**
	- Under Section 97A, the HC is empowered to **grant an injunction** against a **service provider** where the **service provider has <u>actual knowledge of anothe rperson using their service to infringe copyright</u>**
	- Where a telision broadcast was **retransmitted iva internet**, <mark style="background: #FF5582A6;">there is **no need** to show that the **"public to which the re-transmission was communicated was any different from teh public to which the original transmission was addressed"**</mark> ; <mark style="background: #00FF3E8C;">the fact that **it was a separte communication to the public** by a different technical means sufficed</mark>
2. **ANY RE-TRANSMISSION OF A TERRESTRIAL TV BROADCAST VIA INTERNET WOULD CONSTITUTE COMMUNICATION**
	- Any ==re-transission of a **terrestrail tv braodcast** via the internet would **constitute a communication**== #important 
		- THis is because it **involved a specfic technical means different from that of the original communication**, and an **intervention which is differnt from that of the braodcasting organisation concerend** 
	- This applies to **transmission of satellite and cable tv braodcasts via the internet**
3.  **GROUNDS FOR THE COURT TO MAKE JURISDICTION SOUGHT BY FAPL (4 GROUNDS)**
	- In order for the court to have jurisdiction to make the orders sought by FAPL, four matters had to be established. 
		1. First, that the **defendants were service providers.** 
		2. Secondly, that <mark style="background: #FF4E00A6;">users and/or the operators of FirstRow</mark> **had infringed FAPL's copyrights.** 
		3. ! Thirdly, that **users and/or the operators of FirstRow** **<mark style="background: #FF0000A3;">had used the defendants' services to do that. </mark>**
		4. Fourthly, that the **<mark style="background: #00FF3E8C;">defendants had actual knowledge of that.</mark>**
1. **FIRSTROW HAD COMMITTED COPYRIGHT INFRINGEMENT**
	- In this cse, <mark style="background: #FF5582A6;">Defendantss</mark> **were <mark style="background: #00FFFE73;">service providers</mark>** within meaning of reg 2 of the Regulations and hence are **withing the meaning of Section 97A fo the act**
	- ! FirstRow -> had **==communicated FAPL's works to the public in UK==**; thereby **infinging FAPL's copyright in those works**