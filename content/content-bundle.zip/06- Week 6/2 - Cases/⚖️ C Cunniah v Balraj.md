---
Number: 
Week: 6
MainTopic::
Topics:
Status:: #complete
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---

# **Case** ⚖️ : ***C Cunniah v Balraj***

```ad-Case
title: **Case Details**

- **Name of Case**: ***C Cunniah v Balraj***
- Citation::
- Year:: 
- Bench Size::
- Subject: #IPR

```

---
## Facts
-  
	- In 1931 - TM SUbramaniam (TMS) drew a picutre of a Deity B and gave it the title of <mark style="background: #00FF3E8C;">Mayurapriya</mark> (MP)
	- IN 1938, he assigned the copyright in this picture to the appellant firm
	- 1940 onwards -> appellant firm were making and selling printed copies of this picture to the public
		- this picture was registered under the Trade Marks Act 1940 by the Apellant firm
-  
	- Around 1952 -> A came to the knowledge that R was **pringing ans selling copies of a ==close and colourable imitation of A's picture==** under the style of **<mark style="background: #00FF3E8C;">Bala Murugan</mark>** 
	- A contended that BM is a **colourable imitaation of the picture** MP

### Contentions of respondents

>  *"...stressed upon the points of dissimilarity "to contend that the respondents picture was an independent production. For instance, he pointed out to us that the colour scheme of the respondents' picture was different from that of the appellants' picture. Next, he said that the appellants picture was on a large scale, while the respondents picture was on a small scale. As further instances, he pointed out that **the peacock in the respondents' picture faces left, while the same bird in the appellants' picture faces right.** Again, in the appellants' picture "Bala Subrahmanya' is shown as having one hand round the neck of the peacock, while in the respondents' picture his right hand is shown in the raised posture blessing the world."*

> *The background of the picture was also said to be different, because, in "Mayura Priya" there is a fort like building in the background, while in "Bala Murugan" a representation of the Palani temple appears in the background. The **rest of the background in both the pictures is identical, consisting of hills, meadows and wild flowers**. In our view, nothing turns upon the names of the publishers in the two pictures being different or the names of the pictures themselves being different. **Coming to the figure of Bala Murugan, he is said to be slighter in build and his looks are said to he more adolescent,** whereas the figure in "Mayura Priya" is that of a brown-eyed boy stouter in build with chubby cheeks.*

---
## Issues?
1. Was the represeentation of a **common subject** like a **painting of a deity =="Bala Subrahmanya"==** made from **conventional ideas to his appearance in human form** -> originagl? 

---
## HELD
1. **WHAT IS A COPY**
	- dEFINED AS THAT WHICH **COMES SO NEARER TO THE ORIGINAL** SO AS TO **suggest itself** as an ==**original**== to ==**the mind of every person seeing it**==
	- *" the degree of resemblance between the two pictures, which is to be judged by the eye, must be such that the person looking at the respondents' picture must get the suggestion that it is the appellants' picture."*
	- ! ONe picture can be said to be a **copy of another picture** ***==only if a <u>substantial part of the former</u> finds place in the reproduction==*** #important 
		- >*"In finding out what is substantial part of the appellant's picture, the most prominent part, In our opinion, would be the features of the deity represented as a boy. These features are most prominently displayed in the lineaments of the face, which alone can be said to be the characteristics constituting the personality of the boy."*
2. **SINCE BALASUBRAHMANYA (DIETY) IS A SUBJECT WHICH IS COMMON TO EVERYONE, WHETHER HIS PICTORIAL INFRINGEMENT CAN BE COPYRIGHTED?**
	- Yes; 
		- if a picture is drawn by an artist made up of *conventional ideas as to his posture, form, ornaments he wears, the vahan he users etc*, the the picture is **still the result of skill and labour of ths artis**
			- => this ==**entitled him to claim copyright in the prodct of his labour**==


<br>



> [!note] In a nutshell
> - t is well established that, in order to obtain copyright production for literary, domestic, musical and artistic works, the subject dealt with need not be original, nor the ideas expressed be something novel. T
> 	- Thus, though pictorial representation of Lord Balasubrahmanya in a human form is a subject which is common to everyone, still, if a picture of Lord Balasubrahmanya drawn by an artist made up of conventional ideas as to his posture, his form, the ornaments he wears, the vahanam he uses and other matters, the picture produced is still copyrightable if it is not copied from somewhere else.