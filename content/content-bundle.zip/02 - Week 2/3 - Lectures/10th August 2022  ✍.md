---
Week: 2
LectureNumber:  3
Topics:
Date:  2022-08-10
Tags: 
- lecture 
- IPR 
- 7thsemester
cssclass: noyaml
alias: ✍️  10th August 2022 - Intellectual Property Law L(3)
Type:: #lecture

up:: [[ℹ️ Course Details - Intellectual Property Rights|🏫 IPR]]
---


# **Lecture Notes** 📝 :  10th August 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  10-08-2022**
- Week: 2
- Lecture No.:  3
- **Semester**: #7thsemester 
```
[Module:: ]
Status:: #complete 

---
-  
	- There are times hwen **both author’s rights and the good of the society will overlap**
		- There amy also be times when they are o the **opposite sides of the spectrum**
	- The entire study of IPL → encompassed in these interactions
-  
	- Copyright is not only just **economic centnric** but also **”soul centric”**

<br>

![[4th August 2022  ✍#Criticisms of IP]]

<br>


---

-  
	- While getting comfortable with IP, there wer a lot of changes
	- **Traditional Knowledge** → important in India → it is one way of understanding the importance of IPR

---
## History of Intellectual Property 📌

-  
	- The seals from the **harrapan civilisation** → used by the civilisation to **engage i trade relations with other civilisation at the time**
		1. How do we recognise that this product comes ffrom teh Harrappan civlisation?
		2. How do you recognise that one civilisation sent soemthing to another civlisation?
		- Using **seals of certificaiton**?
	- `fas:Trademark` → means “in the process of getting a trademark”, 

<br>

-  
	- In England → <mark style="background: #00FFFE73;">**Statute of monopolies**</mark>  was passed; 
		- **only certain people** could make certain things;eg *person A can only create cigarettes*, only *person B can create playing cards*
	- However, this system was deemed **ridiculous**; a need was efelt for a **proper coherent regime for intellectual poreprty** esp for **literary and artistic works** 

---
## IP in India 🇮🇳
-  
	- There wre several colonial legislations
		- There was a copyright act and the Trademarks Act


<br>

### Forms of IP
#### 1. Patents
- Protects **novel inventions**; → something that has **no been seen beofre**
- It is a <mark style="background: #00FF3E8C;">**strong protection**</mark>  but it is <mark style="background: #FF5582A6;">**very difficult to obtain**</mark> 


#### 2. Trademarks
- Logos of companies → these symbols **holds an ==impression on the consumers==** → this is what is protected

#### 3. Copyright
- Books, movies, etc


----

### Other Forms of IP
#### Geographical INdications
> ![[TK AND GI.excalidraw.png]]
> Geographical Indications are a **subset of [[#Traditional Knowledge]]**

<br>


#### Designs
- Eg: laptop designs, phone dsigns, shape of the cococola and aquafina bottles

<br>



#### Trade Secrets
- ***Any food chain will have their trade secrets;*** 

<br>


#### Traditional Knowledge
- *Turmeric Neem* cases

<br>



#### Personality Rights
- Rihanna and *“talkshop”*?
	- TS was a **famous retail store**; it had **Rihanna modelling for them**
	- Then the contract ended, however, **<u>they did not stop displaying her suit</u>**
		- **<mark style="background: #FF5582A6;"> She sued</mark>** 
	- Right to **personality**; “people have the right to kow where their **persona** is being used”

<br>


#### Semi-Conductors 
- Layout of an integrated circuit is protected


<br>


#### Plant Varieties
- Protects **farmers’ rights**, ***==Genetically modified crops==***
	- With regard to GMOs, the farmer wiill hav eto show that he can **consistently replicate it**

<br>


---
## Current Framwork 🚧
### TRIPS
1. Agreement on Trade Realated Aspects of Intellectua Property → TRIPS
	- barring [[#Trade Secrets]], [[#Traditional Knowledge]], and [[#Personality Rights]], TRIPS deals with all forms of IP; it is an ==**overarching treaty**==
		- countries face issues in adopting this? eg: India and patents
- TRIPS is administered by WTO → <mark style="background: #FF4E00A6;">**sanctions can be levied**</mark> 

<br>


2. Minimum Standard regime → Established by TRIPS
	- TRIPS → **establishes a checklist** that should be <u>accomodated under copyright</u>
		- 50 [[PMA]] → means that the author’s work will be protected **50 years after the author’s lifetime**

<br>

3. Most Favoured Nation and National Treatment


<br>

4. The DOHA Declaration on Public Health 


---
### WTO 
- Ensures that a Company is not removed froma Country
	- eg: three companies -. Filla, adidas, nike → germany wants to kick out Filla



---
#### [[Most Favoured Nation]] 
![[Most Favoured Nation]]





---

#### [[Principle of Territoriality]]
![[Principle of Territoriality]]


<br>

- WIPRO → dedicated organisation → it has na **organ call the bureau** → the application made by the patent applicant will be sent to this bureau and they will send it to the countries checklisted by the applicant so that these countries can **scrutinize it in accordance with their standards**

---

