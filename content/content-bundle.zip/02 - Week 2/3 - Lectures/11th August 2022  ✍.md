---
Week: 2
LectureNumber:  4
Topics:
- Berne Convention
- Paris Convention
- ==**Law on Copyright Introduction**==
Date:  2022-08-11
Tags: 
- lecture 
- IPR 
- 7thsemester
- complete
alias: ✍️  11th August 2022 - Intellectual Property Law L(4)
Type:: #lecture
cssclass: noyaml
up:: ℹ️ Course Details - Intellectual Property Rights|🏫 IPR
---


# **Lecture Notes** 📝 :  11th August 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  11-08-2022**
- Week: 2
- Lecture No.:  4
- **Semester**: #7thsemester 
```

Module:: 
Status:: #complete 


---
## Current Framework (Ctd)
### Berne Convention
- It pertains to protection of  ==**only literary and artistic works**==

> In France, you **cannot waive or assign your [[moral rights (IPR)]]** it **remains with your for perpetuty** 

> 🇮🇳 India became part of the convention in 1928 

- Berne Convention - is an effort of **France and Germany**
	- US was a part of the discussions of eBerne Convention, bedcasue fo an article providing for **moral rights**, the US **backed out** (<mark style="background: #00FFFE73;">**Article 6 bis(?)**</mark> )
	- >US became a part of the convention in 1989 🇺🇸



<br>

1. It allows ==**free uses**== → *eg: you can cite other authors*


<br>

#### Three Basic Principles of Berne Convention
##### [[National Treatment]]
![[National Treatment]]


##### Automatic Protection
- The protection must **NOT be conditional upon compliance with any formality**
	- the scrutiny is thus lesser and **standard of originality** is lesser than what was there in **Patents**

##### Indpendence of Protection
- Protection si ==**independent of the presence of protection in the country of origin of the work**==

<br>



---

### Paris Convention - Industrial Property
- Part of  <mark style="background: #00FFFE73;">Initial International Instruments of IP, 1883</mark> 
- Patents, Industrial Designs, Utility Models, service marks, trade names and geographical indications
- India → joined in 1997
- US → 1887

> It is **Administered by WIPO** 

<br>

---
### Universal Copyright Conventions

- Signed in Geneva Switzerland - 1952
- Key Reason - USA Russia, large parts of Asia nd South america missing from teh Berne convention

- They created a system to formalie that regime for non-Berne members 
- Initiated by the USA after World War II
- Became obsolete after all these countries joined Berne










-------

> [!summary] Note
> - If you **create more than 50 copies** for a work of art, **<u>it ceases to have a copyright</u>** 
> - Instagram → **songs on reels** → lasts for a short duration (1min/15sec) => thus **<u>no copyright violation</u>**
> 

---
# [[Law on Copyrights]]


## Introduction
- Stranger Things: Gave homage to certain movies → masterclass on how to avoid copyright
- Sherlock in the TV show is very different from Arthur Conan Doyle’s Sherlock → nevertheless, ther are **very striking commonalities** → in this case, → there is **<u>no copyright violation</u>**

<br>

- **Right to integrity** → preserving the **integrity** of the original work is important

<br>

> [!question] Can ideas be copyrighted?
> Nope