---
Number: 
Week: 8
MainTopic::
Topics:

Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case

---
- [x] Complete [[⚖️ Abercrombie & Fitch Co. v. Hunting World, Inc 537 F.2d 4 (2d Cir. 1976)]] <progress value="8" max="10"></progress> ⏫ 📅 2022-10-06 ✅ 2022-10-07
# **Case** ⚖️ : ***Abercrombie & Fitch Co. v. Hunting World, Inc 537 F.2d 4 (2d Cir. 1976)***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Abercrombie & Fitch Co. v. Hunting World, Inc 537 F.2d 4 (2d Cir. 1976)***
- Citation::
- Year:: 1976
- Bench Size::
- Subject: #IPR

```
Module:: 
Status:: #partiallycomplete 

---
## FACTS
-  
	- A&F -> advertised and promoted products idenitified with its mark **==*Safari*==** 
		- It had engaged in retail marketting of sporting apprael including hats and shoes; some identified by us of ***Safari*** alone or by expressions such as ***Minisafari*** and ***Safariland***
-  
	- They filed an action against **Hunting WOrld**
### Contentions By A&F
1. That continuation of HW(Huntingworld's) acts would **confuse an deceive the public** and **impair the <mark style="background: #FF5582A6;">"distinct and unique quality of AF's trademark"</mark>**
	- Ds had engaged in retail marketing of sporting apparel -> use of *Safari* alone or *minisafari* and *Safari land*
### Contentions by HW
1. That the word *"safari"* is an <mark style="background: #00FF3E8C;">**ordianry, common, descriptive, geographic, and generic word**</mark> which commonl connotes *journey/expedition* *especially for hunting or exploring in East africa* and to the *hunters, guides, men animals and equipment forming such an expedition* 
	- that it is **<mark style="background: #FF0000A3;">not subject to exclusive appropriation as a trademar</mark>**
---
## Procedural History
- District Court for the SOuthern District of New Yorkk dismissed the complaint and **cancelled all P's trademark registrations for safri**
---
## ISSUES:
1. Whether the district Court had **erred in its observations**

---
## HOLDING
1. **4 DIFFERENT CATEGORIES OF TERMS IDENTIFIED WITH RESPECT TO TRADEMARK PROTECTION**
	- In ascending order of **elegibility to trademark status and degree of protection recorded**, these are
		1. <mark style="background: #FF0000A3;">**Generic**</mark>
		2. <mark style="background: #FF4E00A6;">**Descriptive**</mark>
		3. <mark style="background: #FFF3A3A6;">**Suggestive**</mark>
		4. <mark style="background: #00FF3E8C;">**arbitrary or fanciful**</mark>
		- These lines of demarcation are however **not always bright**
	- >![[⚖️ Abercrombie & Fitch Co. v. Hunting World, Inc 537 F.2d 4 (2d Cir. 1976).png]]
2. **WHAT IS A GENERIC TERM**
	- It is a term that has **come to be ==understood==** as **referring to the ==genus== of which the ==product is the *species*==**
3. **ELIGIBILITY FOR TRADEMARK PROTECTION AND SECONDARY MEANING**
	- While the Lanham Act makes an **important exception** wrt those ***merely*** **<mark style="background: #FF00868C;">descriptive</mark> terms** which have acquired ==secondary meaning==, **<mark style="background: #FF0000A3;">no such protection is offered TO ***GENERIC MARKS***</mark>**
		- even proof of secondary meaning by virtue of which some merely descriptive marks may be registered **cannot transform a generic mterm into a subject for trademark**
	- ! **Regardless of the MONEY AND EFFORT employed by the user of the GENERIC TERM, <mark style="background: #FF0000A3;">it cannot deprive competing manufacturersof the product of the <u>right to call an article by its name</u></mark>**
4. **WHERE SUGGESTIVE OR FANCIFUL TERM HAS BECOME GENERIC -> IT WILL BE DENIED TM PROTECTION SAVE FOR THOSE MARKETS WHERE THE <u>TERM STILL HAS NOT BECOME GENERIC AND A ==SECONDARY MEANING HAS BEEN SHOWN TO CONTINUE==</u>**
	- Thus a term may be **generic in one market** and yet **suggestive or fanciful in another**
5. **TERM THAT IS DESCRIPTIVE BUT NOT GENERIC -> STANDS ON BETTER GROUND THAT GENERIC**
	- Their registration is nevertheless barred under the TM Act #doubt #recheck 
6.  **WHEN IS A MARK SUGGESTIVE? HOW IS IT DIFFERENT FROM DESCRIPTIVE MARKS?**
	- If it ==**requires imagination thought and perception**== to ==**reach a cnolusion as to the <u>nature of goods</u>**==
		- A term is descriptive if it **forthwith conveys an <u>immediate idea of the ingredients, qualities, or characterisitcs of the goods</u>**

1. **ELIGIBILITY FOR TRADEMARK PROTECTION - EVIDENCE OF <u>SECONDARY MEANING (SUGGESTIVE MARKS</u>**
	1. Category of ==**Suggestive Marks**==  came about to be because there was **need to protect those marks which are <u>neither exactly descriptive nor  truly fanciful on the other</u>**
		- ! The validity of the mark**ends where suggestion ends and description begins**  
	2. If a term is ==**suggestive**==, it  is <mark style="background: #00FF3E8C;">**entitled to protection <u>without proof of secondary meaining</u>**</mark>
2. **ELIGIBILITY OF PROTECTION FOR <u>FANCIFUL OR ARBITRARY TERMS</u>**
	- These enjoy **all the rights accorded to <u>suggestive terms as marks</u>** *without need of **debating whether the term is merely descriptive** and with **ease of establishing infringement** *
1. ~~**COURTS SHOULD FOCUS ON THE USE OF WORDS AND NOT ON THEIR NATURE/MANING IN *ABSTRACT* **~~

---
> [!case] Verdict 
> - Although P had used the mark **"safari"** on **articles of clothing**, D ==HAD ESTABLISHED ITS RIGHTS TO USE SIMILAR DERIVATIOns of the term== in **selling its own line of sporting apparel**
> - Use of Safari as a generic or descirptive term, **Even as a valid trademark** -> the P **could not stop D from using it**

----
# 🗃️ Flashcards
[[Flashcards from ⚖️ Abercrombie & Fitch Co. v. Hunting World, Inc 537 F.2d 4 (2d Cir. 1976)]]
