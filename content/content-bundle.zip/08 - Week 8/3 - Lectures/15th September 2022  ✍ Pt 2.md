---
cssclass: matrix
Week: 7
LectureNumber:  14
Topics:
Date:  2022-09-15
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  15th September 2022 - Intellectual Property Law L(14)
Type:: #lecture
---


# **Lecture Notes** 📝 :  15th September 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  15-09-2022**
- Week: 7
- Lecture No.:  14
- **Semester**: #7thsemester 
- [Link to Lecture]

```
Status:: #partiallycomplete
Module:: [[Trademarks]]

---
# [[Trademarks]]
>- Essentially **statutory** and **territorial**
>- Nevertheless, there are **mechanisms** to protect trademarks **<u>across jurisdictions</u>** 
## Introduction
![[📖 Theoretical Justifications for Intellectual Property#^6d80c2]]

---
## Usage
- Lot of quality of trademark -> comes from **usage**; eg -> shape of **Coca Cola botle**  
	- Great example of a trademark done right

<br>

---
## Context
-  
	- 3 images of POLO
		- Car
		- Seet
		- Shirt
-  
	- Trademark -> thus dependant upon context and **gets restricted depending upon many things apartment from *industry* ** 


----
# Misc
## Passing Off
![[Passing off (Tort)]]