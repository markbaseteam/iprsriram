---
Week: 8
LectureNumber:  15
Topics:
Date:  2022-09-21
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  21nd September 2022 - Intellectual Property Law L(15)
Type:: #lecture
---
#missed 

# **Lecture Notes** 📝 :  21nd September 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  21-09-2022**
- Week: 8
- Lecture No.:  15
- **Semester**: #7thsemester 

```
Status:: #complete
Module:: 

<br>

```toc
```



---
# Recap 
-  
	- [[⚖️ DU Photocopy Case]]
	- [[⚖️ Author's Guild vs Google Books]]
	- [[14th September 2022  ✍#Fair Use and Fair Dealing|Fair Use and Fair Dealing]]
-  
	- Trademark -> Unique identification
	- **Usage** is the most important **ingredient** with respect to ==**trademark**==
		- a person **who is using the trademark** has to **continue using the trademark**


---
# NOTES 📝
## Intro
-  
	- [[Passing off (Tort)]] 
-  
	- What matters is **what impression you have on the consumer** and **what proof you are able to show as to how your consumers do/don't recognise you**
-  
	- In the UK trademarks act, in the **initial defintion of UK trademarks act in 1994** and the **INdian Trademarks Act of 1999**
		1. -> focus on ==**graphical representation**== 🔴
		2. capability of being ==**distinguishing one from another**==
- **IS IT IMPORTANT FOR A TRADEMARK TO HAVE GRAPHICAL REPRESENTATION?**
	- 
- **IS GR *THE* FACTOR/*ONLY IMPORTANT THING* WHEN IT COMES TO TRADEMARK?**
	- GR is important; these are called, [[conventional marks]]

---
-  
	- Consistency alone does not make trademark

---
## Soundmarks
- **==JINGES==**: When the sound is played in the bg of the logo appearing on the screen, the sound also **builds a scertain kind of association in the mind of the consumer**
	- this allows the company to **contend that this is a [[soundmark]]**
- ! Silence in the INdian act wrt sound mark; however, the **firs sound mark in Inda had been regisetered by Yahoo in 2008**
	- $ Now, the **Trademark RUles 2017 provides for ==procedure to register sound marks==** 
---
## Smell Mark/Olfactory Marks
- ! Sequin criteria?
	1. smell has to be **==clear==**  and precise[^1]
	2. it has to be ==**precise**==
	3. it has to be ==**self contained**== ->*meaning tha tth eperson who smells the thing* ***has to be <u>reminded of the company that is claiming the smell mark</u>***
	4. **==Durable==**  #important 

-  
	- ==**Durability**== is an important criteria #important 


<br>


> [!Concept] 
> - It is better to protect smells as **[[tradesecrets]]** rather than [[olfactory marks]]

<br>


---
## Uk
- UK does consider **graphical design** as the be all and end all anymore
	- All that it says is that 
		1. it needs to be represented as the trademark, and
		2. it needs to be represented in the register in manner such that it enables the authorities to identify a clear and precise subject matter
- There is a common law protection accorded to trademarks by means of [[Passing off (Tort)]]
### Amended UK Definition - Trademarks Act 1994
> ![[21nd September 2022  ✍.png]]

---
## History of Trademark
![[21nd September 2022  ✍-1.png|600]]


---
## Purpose of Trademark
1. Give an **Indication to the purchaser**
2. Satisfactory **assurance of the quality** of that mark
3. **Property** of the manufacturer
4. Establishing a connection between the goods and the source
5. Public Interest: to **avoid consumer from being deceived and misled** into buying **bogus products**
---
## Justifications and Criticisms
- [[Frank Schechter]] -> one of the proponents of [[Dilution Theory]] and the adovcate for **greater protectoin*
	1. Acc to [[Frank Schechter|Schechter]], the **only rational basis for protection** of tradmearks should be the <mark style="background: #00FF3E8C;">preservation of the **uniqueness of the trademark**</mark>
- ! However:
	- Criticism of TM is that it is a **monopoly** which is **inefficient8* 
		- even though it is **not a complete monopoly over goods**, it still **creates exclusive rights for a person using that mark**
		- It has **social and economic costs** to **other traders** and ot the market in general
	- There may be **restrictions to free speech as well** => if greater protection is givem, then there will be **more power on the TM owner to ==control th euses of that mark, <u>even if it is non-commercial</u>==**
- ! Other concerns for **overboard protection:**
	1. It **gets in the way** of **free competition
	2. It **encourages companies to ==invest heavily in branding==** 🔴

---
## International Systems and Standareds
- 
	- PARIS CONVENTION -> limitation -> it **could not create and internaitonal mechanism for registration**

### Role of Madrid agreement and Protocol
- [[Madrid Agreement (1891)]] and [[Madrid Protocol (1989)]] -> **provide these procudures through the [[WIPO Bureau]]**, which then **passes the application ot the ==National trademark offices==**
-  
	- Setting of ==**International Standards**== is mainly through the **TRIPS regime**

### Role of WIPo
1. International Registration and awareness bulding

### Role of WTO
- Setting International Standards
- Administered by TRIP

---
## Duration of Protection for trademarks
- For 10 years -> [[Section 25 of the Trademarks Act]]
- It is renewable **indefinitely**
![[Section 25 of the Trademarks Act]]

---
## 🇮🇳 Indian System of trademark Protection
![[21nd September 2022  ✍-2.png]]

<br>


> #### **Types of Marks**
> ![[Pasted image 20221008163445.png]]




----
# 💡 Concepts
1. [[olfactory marks]]

[^1]: This means that **you should be able to differntiate it from other smells**