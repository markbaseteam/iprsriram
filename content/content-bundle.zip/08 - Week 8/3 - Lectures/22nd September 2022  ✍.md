---
Week: 8
LectureNumber:  16
Topics:
Date:  2022-09-22
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  22nd September 2022 - Intellectual Property Law L(16)
Type:: #lecture
---


# **Lecture Notes** 📝 :  22nd September 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  22-09-2022**
- Week: 8
- Lecture No.:  16
- **Semester**: #7thsemester 
- [Link to Lecture]

```

Status:: #inprogress 
Module:: 

<br>

```toc
```

---
# 📝 NOTES
## Trademarks
> [!info] Steps to filing obtaining trademark
> ![[Steps to obtaining Trademark.excalidraw|1000]]




- Schechter -> makes a strong case for the **protection of trademarks** 
- The uniqueness of TM is that it **lies in the memory of th econsumers**
- Trademarks ar e**not without drawbacks**; however, <mark style="background: #00FF3E8C;">**these drawbacks are filled in by courts**</mark>
---
- The Madrid Agreement and the Madrid Protocol -> protects through the **WIPRO Bureau** -> then the **applicaiton passes too the National Trademark office**
- C (citzen) -> wfiled an application -> Patents Trademark office --->  *the PTO goes to the WPO Bureau* ---> The Bureau forwards it to X 
---
- Unregistered trademarks **cannot be used by two companies at once**

---
## Substantive Aspects
![[Substantive Apsects - Trademark|1000]]


---
## Grounds for refusal 
### Absolute grounds for refusal
> ![[22nd September 2022  ✍.png]]


- This is provides under [[Section 9 of the Trademarks Act]]
- Under this section the grounds for refusal are as follows:
	1. TMs that are **<mark style="background: #FF0000A3;">devoid of any <u>distinctive character</u></mark>**, meaning that they **not capable** 🔴 of **distinguishing** the **<u>goods/services of one person *from* those of another person</u>** (provision: [[Section 9 of the Trademarks Act]] **clause (a)**)
	2. TMs that consist  
	3. TMs that **consist exclusively** of **marks or indiciations** which have ==**become customary**== in
		 1. the ***<u>current language</u>*** or 
		 2. in the *bonafide* and **established practices** of the trade
---
![[⚖️ Abercrombie & Fitch Co. v. Hunting World, Inc 537 F.2d 4 (2d Cir. 1976)]]



----

# 📄 MISC. POINTS 







---
# 🗃️ FLASHCARDS
[[What is the lifespan of trademarks]]