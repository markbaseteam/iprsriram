---
Week: 13
LectureNumber:  25
Topics:
Date:  2022-10-27
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  27th October 2022 - Intellectual Property Law L(25)
Type:: #lecture
---


# **Lecture Notes** 📝 :  27th October 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  27-10-2022**
- Week: 13
- Lecture No.:  25
- **Semester**: #7thsemester 
- [Link to Lecture]

```
Status:: #incomplete 
Module::

---
