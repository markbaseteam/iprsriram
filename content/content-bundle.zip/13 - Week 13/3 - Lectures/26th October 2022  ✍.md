---
Week: 13
LectureNumber:  24
Topics:
Date:  2022-10-25
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  26th October 2022 - Intellectual Property Law L(24)
Type:: #lecture
---


# **Lecture Notes** 📝 :  26th October 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  26-10-2022**
- Week: 13
- Lecture No.:  24
- **Semester**: #7thsemester 
- [Link to Lecture]

```
Status:: #incomplete 
Module::

---
