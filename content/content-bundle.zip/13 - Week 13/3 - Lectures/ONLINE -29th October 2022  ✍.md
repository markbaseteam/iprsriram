---
Week: 13
LectureNumber:  26
Topics:
Date:  2022-10-29
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  29th October 2022 - Intellectual Property Law L(26)
Type:: #lecture
---


# **Lecture Notes** 📝 :  29th October 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  29-10-2022**
- Week: 13
- Lecture No.:  26
- **Semester**: #7thsemester 
- [Link to Lecture]

```
Status:: #incomplete 
Module::

---
