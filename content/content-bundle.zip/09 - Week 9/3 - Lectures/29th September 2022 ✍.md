---
Week: 9
LectureNumber:  18
Topics:
Date:  2022-09-29
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  29th September 2022 - Intellectual Property Law L(18)
Type:: #lecture
---
- [x] Complete Lecture [[2 - 7th Semester 📍/1 - Intellectual Property Rights 👨🏻‍🎓/09 - Week 9/3 - Lectures/29th September 2022 ✍|✍️  29th September 2022 - Intellectual Property Law L(18)]] 🔼 📅 2022-10-07 ✅ 2022-10-09

# **Lecture Notes** 📝 :  29th September 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  29-09-2022**
- Week: 9
- Lecture No.:  18
- **Semester**: #7thsemester 
- [Link to Lecture]

```
Status:: #partiallycomplete
Module:: 

---
# 📝 NOTES
## Doctrine of Confusion
- Starting point -> basic test of trademark infringement
- Likelihood of association with the proprietor of the original product - [[Section 11(1) of Trademarks Act]]
	- Where the public **confuses the sign** and the **mark of association** 
	- Where the public **makes a connection between the ==proprietor of the sign==** and ==**those of th emark**== and **<u>confuses them</u>**
	- Where the public **considers the sign to be siilar to the mark** and **perception fo the sign ==calls to mind the memorable mark==**, although the **two are not confused** 

> ![[Section 11(1) of Trademarks Act]]

---
![[⚖️ 🇺🇸 Polaroid Corporation vs Polaroid Electronics (1961)]]

---
![[⚖️ Amritdhara Pharmacy v Satyadeo Gupta ]]

---




----

# 📄 MISC. POINTS 







---
# 💡 CONCEPTS
1. [[Doctrine of Confusion]]





----
# 🗃️ FLASHCARDS
[[Flashcards for 29th September 2022 ✍ - IPR]]