---
Week: 9
LectureNumber:  17
Topics:
Date:  2022-09-28
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  28th September 2022 - Intellectual Property Law L(17)
Type:: #lecture
up:: [[]]
cssclass: 
---

#missed 
# **Lecture Notes** 📝 **:  28th September 2022**

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- Date:  28-09-2022
- Week: 9
- Lecture No.:  17
- **Semester**: #7thsemester 
- [Link to Lecture]

```
Status:: #inprogress
Module:: 
[[Record-009.aac]]

<br>

```toc
```

---
# 📝 NOTES
## ABSOLUTE GROUNDS FOR REFUSAL 📌
### Distinctiveness for Descriptive

- [[Section 9 of the Trademarks Act]] -> talks about **absolute grounds** meaning marks displaying certain grounds **cannot be displayed as a trademark**
	- It is a **YES AND NO QUESTION HERE**
- [[Section 11 of the Trademarks Act]] Talks about **==relative grounds==** 
	- Relativity will be given importance in this context
	- !  The relative grounds for refusal are <mark style="background: #FF5582A6;">applicable only when there already exists a trade mark,</mark> i==**n comparison to which**== the **<mark style="background: #FF0000A3;">new trade mark is not registrable</mark>**. #important 
---
- ! Section 9(1)(a) talks about **lack of distinctiveness** 
	1. [[⚖️ Abercrombie & Fitch Co. v. Hunting World, Inc 537 F.2d 4 (2d Cir. 1976)|Abercrombie]] Categorisation
		1. GENERIC
		2. DESCRIPTIVE
		3. SUGGESTIVE
		4. ARBITRARY
		5. COINED
	- > This section is the **bigger category** ; and Section 9(b) aka ==**Descriptive works**== is a **smaller category** 
- [[Section 9 of the Trademarks Act]] (1) **CLAUSE b** talks about ==**descriptive works**==
	- Descriptive works tell you
		- what the product is about
		- what the industry is about
		- Anything that gives an idea of what they are marketting
	- ! **WHAT IS THE DANGER OF IT?**
		1. Exclusivity is lost
		2. We **<u>won't be able to protect the trademark</u>**
			- >eg; Cafe Madras; food chain; it becomes a *descriptive term*
			- >eg; India Today
				- Judiciary said that when it comes to any **trademark** that is a ==**combination of descriptive work**==
				- India Today -> exclusivity stems from the <mark style="background: #00FF3E8C;">**combination**</mark> #important 
					- India today is a **unique juxtaposition of  words**

---
### Functionality - (Functional Mark - Section 9(3))
> [!Concept] 
> - [[Functionality Doctrine]] helps to **prevent TM law** from **==inhibiting legitimate competition==** by <mark style="background: #FF0000A3;">**monopolizing** a **useful product feature**</mark>
> 	- This is **left to the domain of patent law**

- Devices; 
- Eg:
	1. Royal Enfield (Harely something) wanted to register a sound as a **sound mark**
		- Their sound sounded like and **exhaust**
		- ! THis was rejected because it was **<u>functional to the bike</u>**
			- this is because certain exhausts may sound similar
	2. Kotak -> sounds like something that **sounds like a camera shutter** 
		- this is an *invented word*
			- This has however **become generic**
- Market competition is a concern
	- there are other brands similar to *ROyal Enfield* which **also have similar exhaust sounds**
- eg:
	- Company brought out press pads?
	- THis company -> brought it in the combination of **green and gold**
		- another company wanted to  bring it in a similar fashion
			- Qualitex ? (the company) filed for ==**infringement**==
				- The 2nd company contended that the colours were **functional**
				- Qualitex however contended that **<u>the colours associated here are *not directly funcitonal*; rather, ==this is how unique they are==</u>**

<br>

> [!note] 
> Colourmarks can be protected as long as they **can prove that the TM is <u>not part of its functionality</u>** 

---
![[⚖️ Qualitex Co. vs Jacobson Productws (1995)]]

---
> ## Secondary Meaning
> ![[28th September 2022  ✍.png|inlR|200]]
> - Terms can be ==**used in a completely different contexts**== and **stand the test of time** thereby obtainging a <mark style="background: #00FF3E8C;">**Secondary Meaning**</mark>
> 	- This diversion in memory -> ==increases **Potential for distinctiveness**==
> 



---
### Deceptive Similarity - Section 9(2)(a)
> ![[28th September 2022  ✍-2.png]]


- **Any <mark style="background: #FF0000A3;">counterfeits</mark>**  constitutes deceptive similarity

> [!Concept] 
> - the effect: people identify a trademark with a source aka the creator; when [[deceptive similarity]] happens, aka they ==**cut the queue**==, this **<u>confuses the buyer</u>** 
> 	- this **benefits the subsequent trader**



- Fundamental issue with [[deceptive similarity]] is that it <mark style="background: #FF0000A3;">deceives the people</mark> 
	- It **disrupts the public memory** 
---
> [!note] 
> - When it comes to the **==Pharma/Health Industry==**, the **threshold is much higher** and so are the stakes; 
>	- Eg: *antibiotic - azithromycin for cough and cold; suppose somebod brings out a product with a particular* ->  

---
![[⚖️ Cadila Healthcare LTd v. Cadila Pharmaceuticals (2001)]]


---
### OTHER GROUNDS
![[28th September 2022  ✍-1.png]]


---
## RELATIVE GROUNDS FOR REFUSAL 📌
> ![[Section 11 of the Trademarks Act]]

---
- Under [[Section 11 of the Trademarks Act]] an ==**earlier mark**== can be a **ground for refusl** on ground of 
	1. **identitity of marks** and ==**similarity of goods**==
	2. The **==similarity of marks==** 
	3. Well known trademarks
	4. Marks protected through [[Passing off (Tort)]] or **copyright**

---
### Likelihood of Confusion
![[Likelihood of Confusion]]

---
#### Likelihood of Association - A subset
![[Likelihood of Association]]

<br>

1. ![[⚖️ 🇺🇸 Polaroid Corporation vs Polaroid Electronics (1961)]]
2. ![[⚖️ Amritdhara Pharmacy v Satyadeo Gupta]]
3. ![[⚖️ F Hoffman La Roche v Geoffrey Manners]]

<br>

---
### Well Known Trademarks
![[28th September 2022  ✍-3.png#circle|inlR|200]]
-  
	- These are **easier to protect in common law**
	- Article 6bis of the Paris convention -> has a **provision for bad faith** read with Art 10bis which has a **provision against unfair competition**
-  
	- WIP has a **soft law for the protection of these marks** --- a **Joint Recommendation** for thse marks

![[28th September 2022  ✍-4.png|inlR|100]]
- 
	- India maintains a database of Well-known marks
-  
	-  Rolex SA v Alex Jewelry Pvt. Ltd. 
		- The Court found that the segment of the public which uses the watches of the category or price range as Rolex, if they come across jewellery or artificial jewellery also bearing the same mark is likely to believe that the said jewellery has a connection to Rolex.
---
#### Cases 
1. ![[⚖️ NR Dongre and Ors. vs Whirlpool Corporation and Anr.]]
2. ![[⚖️ Toyota Jidosha Kabushiki Kaisha vs MS Prius Auto Industries Ltd. (2017)]]
---
## Doctrine of Honest Concurrent User - Section 12
![[Kores India Ltd vs Khodayj Eshwarsa and Son]]

---
![[Hindustan Pencils Pvt Ltd vs MS Universal Trading Company]]


----

# 📄 MISC. POINTS 




---
# 💡 Concepts
1. [[Likelihood of Confusion]]
	1. [[Likelihood of Association]] - a subset
2. [[Well Known Trademarks]] 
3. [[Doctrine of Honest Concurrent User]] 


---
# 🗃️ FLASHCARDS
- [[Flashcards for 28th September 2022  ✍ IPR]]