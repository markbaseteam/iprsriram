---
Number: 
Week: 9
MainTopic::
Topics:
Status:: #partiallycomplete
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---

# **Case** ⚖️ : ***Toyota Jidosha Kabushiki Kaisha vs MS Prius Auto Industries Ltd. (2017)***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Toyota Jidosha Kabushiki Kaisha vs MS Prius Auto Industries Ltd. (2017)***
- Citation::
- Year:: 
- Bench Size::
- Subject: #IPR

```

---
## Facts
-  
	- Toyota ->owned well-known trademarks of the following
		1. Toyota
		2. Innova
		3. Prius
	- First two marks were **registered trademarks**
-  
	- P claimed TM in Prius
	- ! It **had not registered trademark**; but ***Prius did in 2002***
	- Toyata <mark style="background: #FF0000A3;">**contested this registration by the Defendatns aka Ds**</mark>
		- calimed that Ds had <mark style="background: #FF0000A3;">****wrongly and dishonestly registered the TM in India**</mark>
---
## Issues: 
1. Whether Prius could be **granted protection in India** with its **reputation abroad**?

---
## Held
1.  
	- Court held that **Plaintiff had not supplied enoug proof regarding ==its "reputation" in th eIndian Market==**
	1. THough **<mark style="background: #00FF3E8C;">trans border reputation</mark>** is **a part of Indian law since [[⚖️ NR Dongre and Ors. vs Whirlpool Corporation and Anr.]]**, it <mark style="background: #FF4E00A6;">**had to be proved**</mark>  ***within the territory of India***#important 
	2. **<mark style="background: #FF4E00A6;">Territoriality principle is to govern the matter</mark>**  : thus, there must be **adequate evidence** to show that the plaintiff had <mark style="background: #00FF3E8C;">acquired **a substantial goodwill** for tis **car**</mark> under the brand nam of "Prius" <mark style="background: #00FF3E8C;">in the **Indian Market also**</mark>
		- ! THus, ==**REPUTAITON IN THE LOCAL MILIEU MUST BE PROVED AS WELL**== #important #important #important 