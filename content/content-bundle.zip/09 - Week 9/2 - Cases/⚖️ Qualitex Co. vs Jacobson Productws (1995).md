---
Number: 1
Week: 9
MainTopic::
Topics:
Status:: #pending
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---

# **Case** ⚖️ : ***Qualitext Co. vs Jacobson Productws (1995)***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Qualitext Co. vs Jacobson Productws (1995)***
- Citation::
- Year:: 
- Bench Size::
- Subject: #IPR

```

---
## Facts
- 
	- Plaintiff -> for many had colloured the **dry cleaning press pads** of its making with a ==**special shade of green-gold**==
	- D -> a rival -> began to use a **similar shade on its own press pads**
		-  Considering this, P **registered its ==colour as trademark==** and filed a traedemark infringment case aginst D
		- 9th circuit held that a TM **could not be obtained for a colour colone**
---
## iSSUE
1. Whether a colour could be **registered as a trademark**?

---
## Held
1. **CAN COLOUR BE REGISTERED AS A TRADEMARK?**
	- **<mark style="background: #00FF3E8C;">Yes</mark>**
2. **CAN INDIVIDUAL COLOURS BE TRADEMARKED?**
	- the court <mark style="background: #FF4E00A6;">**cautioned against this**</mark> as they **require a secondary meaning** and are **not distinctive**
	- [x] What doesthis mean ⏫ 📅 2022-10-09 ✅ 2022-10-11