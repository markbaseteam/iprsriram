---
Number: 
Week: 9
MainTopic::
Topics:
Status:: #partiallycomplete
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---

# **Case** ⚖️ : ***F Hoffman La Roche v Geoffrey Manners***

```ad-Case
title: **Case Details**

- **Name of Case**: ***F Hoffman La Roche v Geoffrey Manners***
- Citation::
- Year:: 
- Bench Size::
- Subject: #IPR

```

---
## FACTS
-  
	- Plaintiff -> company manufacturing phara products
	- applied for registration of mark ==**Protovit**== for **<u>multivitamin tablets and liquids</u>**
-  
	- Lter -> R applied for reigstriaotn of ==**Dropovit**==
-  
	- P sued for infringements -> claimed that it is ==**likely to deceive or cause confusion**==
---
## Issues 
- Likelihood of ==**confusion**== and ==**descriptive nature**== of the mark

---
## Held
1.  
	- In order that a trade mark may be found deceptively similar to another it is **<mark style="background: #FF0000A3;">not necessary that it	 'should  be intended  to deceive or intended to cause confusion.</mark>**
2.  
	- The marks have to be <mark style="background: #00FF3E8C;">**compared s wholes**</mark>
	- You cannot take **one porition of th eword** and then say that **because that protion of the word differs from the correspoiding portion, ther eis <u>no sufficient similairty to cause confusion</u>** 
	- ! The ==**true test**== is whether the *totality of the trademark is such that it is **<u>likely to cause deception or confusion or mistake in the minds of th eperson accustommed to the existing TM</u>** *

<br>

> [!case] Verdict
> ![[⚖️ F Hoffman La Roche v Geoffrey Manners.png]]