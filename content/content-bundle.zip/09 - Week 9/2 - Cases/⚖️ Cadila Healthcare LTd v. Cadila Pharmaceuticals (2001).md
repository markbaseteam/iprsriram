---
Number: 
Week: 9
MainTopic::
Topics:
Status:: #partiallycomplete
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---
==**[[Passing off (Tort)]] case**==
# **Case** ⚖️ : ***Cadila Healthcare LTd v. Cadila Pharmaceuticals (2001)***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Cadila Healthcare LTd v. Cadila Pharmaceuticals (2001)***
- Citation::
- Year:: 
- Bench Size::
- Subject: #IPR

```

---
## FACTS
- This is a [[Passing off (Tort)]] case
	- A and R were both **Pharmaceutical companies** who had **taken over the business of the Cadilla group** after **restructuring under the companies Act**
- Bothe companies -> **granted the right to use the term "Cadilla"**
	- **A** <-- initially **manufactured a drug** to treat *cerebral malaria* with the <mark style="background: #FF4E00A6;">mark **"Falcigo"**</mark> and was granted **Permission by the Drugs Controller of India in 1996** to **sell th eproducts across India**
	- In 1997: D <-- given permission for **selling drugs for cerebral malaria** called <mark style="background: #FF00868C;">**Falcitab**</mark>
---
## Issues
- Whether there is **confusion** and **[[Passing off (Tort)]]** in this case?

---
## HELD
> [!danger] 
> - In the Indian context, **less literacy** and **absence of common** 
> - Furthermore, there is **no common language**
> - ! The above factors have to be taken into account

1.  **COURT PROPOUNDED [[TEST OF REASONABLE AND ORDINARY PERSON]]**
	- SC took into consideration various aspects such as ***legigbility fo doctors' prescription, accidental conusion due to [[deceptive similarity]], and the nned for caution in cases of drugs which are used to treat the same disease***, *however, comprise of different composition*
	- Court held that the [[TEST OF REASONABLE AND ORDINARY PERSON]] -> was held to be a <mark style="background: #FF00868C;">**person of imperfect recollection and average intelligence**</mark>
	- Court held that **even if both drugs are only sold in hospitals and clinics with prescriptions**, there could be a ==**cause of confusion <u>even amongst professionals dispensing th emedicines</u>**==
	- ~ The cour thus held that **there was a likelihood of [[Passing off (Tort)]] and it was ==was a case of [[deceptive similarity]]==** 

---
![[Cadilla factors for ascertaining Deceptive Similarity]]

---
