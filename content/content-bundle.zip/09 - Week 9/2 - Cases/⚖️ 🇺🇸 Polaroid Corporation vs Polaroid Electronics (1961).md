---
Number: 
Week: 9
MainTopic::
Topics:
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---

# **Case** ⚖️ : ***🇺🇸 Polaroid Corporation vs Polaroid Electronics (1961) ***

```ad-Case
title: **Case Details**

- **Name of Case**: ***🇺🇸 Polaroid Corporation vs Polaroid Electronics (1961) ***
- Citation::
- Year:: 1961
- Bench Size::
- Subject: #IPR

```
Status:: #partiallycomplete 

---
## Facts
-  
	- Polaroid Coporation - Delaware based corp - owner of trademark ==***Polaroid***==
		- holder of 22 US registrations
	- Brought action in the Eastern District of NY
-  
	- Defendant D -> denied allegations of the complaint; sought declaratory jugdement **establishing D's right o use Polaroid in the businesss in which D was engaged**
-  
	- ~ THe lower court **dismissed both claims**
		- COnluded tha tneithe rp nor D had made an adequate showing wrt confusion
		- Both had been guilty of [[laches]]
---
## Held
### Polaroid v Polaroid Factors
1. **STRENGTH OF USE OF THE SENIOR USER'S MARK**
	- the ==**stronger**== or ==**more distinctive**== the **senior user's mark**, the <mark style="background: #00FF3E8C;">**more likely the confusion**</mark>
2. **SIMILARITY OF THE MARKS**
	- tHE **MORE ==SIMILARITY BETWEEN THE MARKS==**, the <mark style="background: #FF5582A6;">**more likelier it is** to **cause confusion**</mark>
3. **SIMILARITY OF THE PRODUCTS AND SRVICES** 
	- The ==**more related**== the marks of the **senior and junior user's goods or services**, the <mark style="background: #FF5582A6;">**more likely** the confusion</mark>
4. **LIKELIHOOD THAT THE SENIOR USER WILL BRIDGE GAP**
	- If it is probable that the **senior user will ==expand into the junior user's product area==**, the **<mark style="background: #FF5582A6;">more likely the confusion</mark>** 
5. **JUNIOR USER'S INTENT IN ADOPTING TH EMARK**
	- If the Junior user **adopted the mark in <mark style="background: #FF0000A3;">bad faith</mark>**, the <mark style="background: #FF5582A6;">**confusion is more likely**</mark>
6. **EVIDENCE OF ACTUAL CONFUSION**
	- ==**Proof**== of **consumer confusion** is **not required**
	- However, where the <mark style="background: #00FF3E8C;">trademark **owner** can show that the <u>average reasonably prudent consumer is confused</u></mark>, it would make a <mark style="background: #FF4E00A6;">**powerful argument in favour of infringement**</mark>
7. **SOPHISTICATION OF BUYERS**
	- The **less sophisticated the buyers**, the <mark style="background: #FF0000A3;">**more likely** the **confusion**</mark>
8. **QUALITY OF JUNIOR USERS OR PRODUCTS**
	- The **lesser the quality of the junior user's products**, there is <mark style="background: #FF5582A6;">**more harm** that is likely from <mark style="background: #FF0000A3;">**consumer confusion**</mark></mark>

<br>

> [!Case] VERDICT
> ![[⚖️ 🇺🇸 Polaroid Corporation vs Polaroid Electronics (1961).png]]