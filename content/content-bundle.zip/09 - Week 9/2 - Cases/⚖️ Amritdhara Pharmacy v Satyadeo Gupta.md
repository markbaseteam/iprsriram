---
Number: 
Week: 9
MainTopic::
Topics:

Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---
- [x] Complete [[⚖️ Amritdhara Pharmacy v Satyadeo Gupta]] 🔼 📅 2022-10-07 ✅ 2022-10-07
# **Case** ⚖️ : ***Amritdhara Pharmacy v Satyadeo ***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Amritdhara Pharmacy v Satyadeo ***
- Citation::AIR 1963 SC 449
- Year:: 1963
- Bench Size::
- Subject: #IPR

```

Status:: #complete

---
## FACTS
-  
	- SG had applied for registation of TM **"Lakshmandhara"** for medicinal preparations stated to be in use since 1923
	- Amritdhara A opposed it on ground that their product **Amritdhara** was similar
	- Registatrar **denied registration to "Lakshmandhara"**
---
## HELD
1.  **"LAKSHMANDHARA" NOT TO BE GIVEN TRADEMARK AS IT INFRINGES UPON "AMRITDHARA** 🔴
	- Amritdhar adn Lakshmandhar were **similar**
	- ! Test:: Comparison of marks has to be <mark style="background: #00FF3E8C;">approached from the **<u>point of view of a consumer fo average intelligence and imperfect recollection</u>**</mark>** 
		- In this case, *Lakshmandhara* is **refused registration as trademark** because it <mark style="background: #FF0000A3;">would cause confusion in the minds of public</mark> as it is [[deceptive similarity|deceptively similar]] to a ==**registered TM**== in *"Amritdhara"*
		- **While** a **critical compairosn of the two names <mark style="background: #FFF3A3A6;">might disclose some points of difference</mark>**, however, an `1` <mark style="background: #FF00868C;">unwary purchaser</mark> of `2` <mark style="background: #FF4E00A6;">average intelligence</mark> and `3` <mark style="background: #FF00868C;">imperfect **recollection**</mark> <mark style="background: #D2B3FFA6;">**would be deceived by the OVERALL SIMILARITY OF THE TWO NAMES**</mark> having regard to the **nature of the medicine he was looking for** with a somewhat **vague recollection that he had purchased a *similar medicine* on a previous occasion with a *similar name***
	- ! The trademark is the **whole thing** and the **<u>whole word has to be considered</u>**
---
> [!case] Key Takeaways
> 1. The test for deceptive similarity is the **point of view** of consumer of **average intelligence** and **imperfect recollection**
> 2. The trademarkis the **whole thing** and the **whole word has to be considered**
> 3. There is **on criteria** given in the act for determining what is "likely to deceive or cause confusion" 
> 	- ~ Thus, **Every case** must depend on its **own particular facts** 
> 	- Thus the **value  of the authorities** lies **<u>not so much in the actual decision</u>** as much as in th e**<u><mark style="background: #00FF3E8C;">tests applied for determining what is likely to deceive or cause confusion</mark></u>**