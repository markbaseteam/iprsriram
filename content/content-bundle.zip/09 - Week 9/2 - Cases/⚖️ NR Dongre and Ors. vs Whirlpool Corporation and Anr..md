---
Number: 
Week: 9
MainTopic::
Topics:

Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---

# **Case** ⚖️ : ***NR Dongre and Ors. vs Whirlpool Corporation and Anr.***

```ad-Case
title: **Case Details**

- **Name of Case**: ***NR Dongre and Ors. vs Whirlpool Corporation and Anr.***
- Citation:: 1996 PTC (16) 583 (SC)
- Year:: 1996
- Bench Size::
- Subject: #IPR

```
Status:: #incomplete

---
## FACTS
- The Whirlpool Corporation (Whirlpool Corp.), an American entity and TVS Whirlpool, an Indian company filed a suit against N.R Dongre and others (Defendants) in India at the Delhi High Court. The Appellant-Defendants were using the name "Whirlpool" (mark) in India for manufacturing and selling washing machines. Whirlpool Corp. claimed that they were the prior users of the mark and there was a trans-border reputation indicating that any goods marketed with the use of the mark gave an impression of it being marketed by Whirlpool Corp.

  

- During the initiation of the suit, Whirlpool Corp. had failed to renew its trademark registration in India. However, N.R. Dongre & Others, during this period, had obtained the registration of the mark "Whirlpool" in India. But, Whirlpool Corp. constantly advertised their goods in India and thus opposed the registration of the mark by the defendants. But the Assistant Registrar dismissed the opposition and granted the registration to N.R. Dongre and others.

  

- The suit for passing off was formerly filed by Whirlpool Corp. at the Delhi High Court before the Single Judge. This went on an appeal to the Division Bench of the Delhi High Court. Both the benches granted a temporary injunction against the use of the mark "Whirlpool" by N.R. Dongre and others. Hence, they approached the Supreme Court.

---
## Issues 
1. Whether ==**trans-border reputation**== of the corporation can **maintain a [[Passing off (Tort)]] suit in India?**

---
## Held
1. **<mark style="background: #00FF3E8C;">Decided in favour of Whirlpool corp</mark>**
2. Issue of registraoin is **immaterial in cases of [[Passing off (Tort)]]** 
3. Respondent could not justify using the TM innocently; because the P had **widely used the trademark prior to the R's Use** 
4. that the trademark 'Whirlpool' ==had become well-known and had acquired reputation and goodwill in India.== Finally, the Division Bench stated that **<mark style="background: #00FF3E8C;">a product and its trademark may exceed its geographical boundary not only through importation but also through advertisements.</mark>**