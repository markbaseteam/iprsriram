---
Week: 1
LectureNumber:  1
Topics:
Date:  2022-08-03
Status:: #complete 
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: 
- ✍️  3rd August 2022 - Intellectual Property Law L(1)
- ✍️  3rd August 2022 - IPR L(1)
Type:: #lecture
Module: 
up:: [[ℹ️ Course Details - Intellectual Property Rights|🏫 Intellectual Property Law]]
---


# **Lecture Notes** 📝 :  3rd August 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  03-08-2022**
- Week: 1
- Lecture No.:  1
- **Semester**: #7thsemester

```

---
## Instructions
- Come to class w/in 10 minutes
- Do readings before the class
- Officers Hours: Monday/Friday 5 - 7
---
## Assessments
1. [[3 Pop-up Written Quizzes in Class]] - 5 Marks each = 15 Marks
2. [[IPR Mid-Term]] - 25 Marks
	- Mid-Term Date - October 3rd
3. [[Group Presentation (IPR)]] - 10 Marks.


---
## Introduction
> ![[IP spectrum.excalidraw.png]]

-  
	- For intellectual proeprty, there is a way of **letting people know this is our proerty**; this is called ==**infringement**==
		- infringement is the **act** of **encroaching someone elses intellectual property** is **infringement**
	- There is thus a **limited monopoly** on the said property**
		- the **period for which** a person can sue for infringement → this is the **==limited monopoly==**

<br>

-  
	- Intellectual proeprty and Land property → similar in some ways; int terms of **demarcation**; int terms of **enforceing the right that you have in the property**; there are different **ways of implementing the ownership**
	- **<mark style="background: #FF0000A3;">Differences</mark>** 

---
## Why Should IP Exist
1. Utilitarianism
2. Labor Theory
3. Personality Theory
4. Social Planning Theory