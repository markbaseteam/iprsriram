---
Week: 1
LectureNumber:  2
Topics:
- Utilitarian Theory
- Labour Theory
- Personality Theory 
Date:  2022-08-04
Status:: #complete 
Tags: 
- lecture 
- IPR 
- 7thsemester
- complete
alias: ✍️  4th August 2022 - Intellectual Property Law L(2)
Type:: #lecture
Module: 
up:: [[ℹ️ Course Details - Intellectual Property Rights|🏫 IPR]]
cssclass: noyaml
---
`$=dv.current().Status`

# **Lecture Notes** 📝 :  4th August 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  04-08-2022**
- Week: 1
- Lecture No.:  2
- **Semester**: #7thsemester 

```


```toc
```


---
# Recap 🔁
- Ideas that are absolutely eureka are rare
- Novelty is a very ipmortant factor whe it comes to **patents**
- Even if the idea IS NOT new, it can ==**still be deserving of IP protection**==



---
# Today’s Notes 📝



## THEORETICAL APPROACHES TO IP
### Utilitarianism
- General good of society; **favourable outcome for society in general**

> - The author **<u>feels incentivised to create the work</u>**
> 	- when he sells the wor, in exchange he gets **money/recognition/etc**

- Utilitariamism says that **granting limited irhgts of ownership** is a must;  #important 
	- We should **not give ceaseless incentives**; we must avoid that **[[tragedy of commons]]**
	- <mark style="background: #FF4E00A6;">**limited rights of ownership**</mark>  helps to <mark style="background: #FF5582A6;">**prevent  the**</mark>  [[tragedy of commons]]





<br>


#### Criticism
1. It **does no promote but ==actually hinders innovation==** 🔴
	- eg: *there is a system of middlemen as we have today*; 
		- the ***author and the owner are different*** ; eg: *producer (who owns the rights) and writer*
	- eg: ***[[royalties]]*** → in India, these are **not paid in time** and they are **also not paid adequately**; it takes a lot of  time for the money given to the label **trickles down to the creator** ← this is because of the various agreements signed between the producer and the artist; 



<br>

---
### Personality Theory  (Kant and Hegel)

![inlR|200](http://t1.gstatic.com/licensed-image?q=tbn:ANd9GcTmEkIAU3V9pzy8bhIPNskUYsmUnMy-IbYj4qVicPc0na9OtqCVyDKp4-KXwKBFaOfx)

- Hegel says that **whatever work you crate is ==part of your personality==**
- Basis of protecting a person’s comes from the fact that ==**their work is an infusion of their personality**==

#### Criticism
1. it is not necessary the at the person puts all his/her personality in every work
2. what about **work of science**?
3. <mark style="background: #FF0000A3;">**copying also involves infusion of personality**</mark> 


<br>

---
### Labour theory (Locke)
![inlR](data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJAA4QMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAACAAEDBAUGB//EADYQAAEEAQMCBQIEBQMFAAAAAAEAAgMRBBIhMQVBEyJRYYEycRQjkbEGQlLB0WKh8CQlM1Px/8QAGAEAAwEBAAAAAAAAAAAAAAAAAAEDAgT/xAAeEQEBAAIDAQEBAQAAAAAAAAAAAQIRAyExEkFRYf/aAAwDAQACEQMRAD8A8pTFPsiibqckcm00Eehl+qkT0ksqzoxSpOQkkDJcBIpUgGBS5SDd1IGo2NIwN1rdL6eH/myjb+n1UPT8dk0/n4buQtqWURM0WG02yT/KPX/Cjycn5FsMP2nkc2NgF6e3wofFaXA7bd1GGl7fEktkR4bfmKsYmMch2wDYx6DcqN1JuqzdCHOkB02DfZSxRCMAAF7vUBbmN0+NsY0tAHvyrkGLGw2WAj7KN5pFJx1zZaWb0f0Qgh+1rso8SM3cbT7EKnndIgmaXNbpcO7Vmc0tO8bl3wFwAj0n53QeGBtsD3BUuRE+CYxy3t/MEMmqQgPIscEjf9V0J2aABvWmm+izeq4TPCM0TNJbzSvSOfE0kAbd7sBBmyNfgSHgkcLWO5YzlJY5kgdkgERFcpjvwutyBKSMBKhaYBVp6ooilsUgZJKkkEr0SQArcbA1o9VFjBpu79lYKdEhkkkllokxSSQDhLukEQHdBlXCMJhuj07Ws01jEkMTwQB7+60g4ZWQ0FuxG9/89P3WZDG5x23WxjQ+GxpJ8xIAUM9LYbQTSmTMEdU1v7f/AG/0XQ9Mia2Ox+i5zY5zzdDayey1MXrnT8dxjkm2HcNJUuXG2dK4WT10rDwPQWrmNpN91mdMy4s5mTkY/miDBRP+5QZP8Q4XTnBk2s33a21xXHK3UjolmtuiMTtIIAv7qCYNaTZ2I3Wfifxb0iVhqR4PHmYQrbsrFyscS48rXg9h+yzcMpe4PqXxz/XYxTXitjXws3KNwsqtTRS1eqNL4pCN6orG3rSdyuzj8Ry9V5ZPywKG53UcsMckTmiwHc+yaSjY32cFI0+RWTrAzMYwP0n6exUAW51QMfhEkbg7LCaNl04Xcc+c1Rdk1J27p1tgCYIkxQRk6ZJAGwADYcIidkwS7oB0khykUCGT0l3RAJGGqRC01pIaG1WI2h1D3VVp3ViJ2+3ZYy8ON3HhbHGwBos7790UoJfq7DhRwZHiQhrxbQO3KDMyBFCPCs+gI4XP+rzxXxnxSTTaiOa3T/8AbKfEH/m99rCy8LUXyjv39lsNwseAnMMLvHIu3mxdcgLeUmNLG3KOk/gVggwJi+gyyADwQqPVo2PzHvePJfp3Wr04CLouFGw2541P/QKfL6W6XF/LvUTqLT6+xXD96ztdfz05KfqmFg5f4aTBebaDdDe+Fp4LtOR/0jHaHndgG4ViPpoMzfxEQ1N+kmPcfYrZx8VsTW+XS0cA8la5OTHTExy/UX4d3hnxRVily7neDI6J4sja/ldNnZFiuwXMSvD5ZHu7uu/RHCOSaiDJ8uoHdzDV+qiZbgCBVDdKWQ6iD/NwpA7SwFdP4irdTbcFD+bf7UsRtLbzZA3Gs77ErCadyr8XiHJ6IbJFMTumJVUzEoghPZOgj0kmSQBBORYTWm45QRweyKlHdIg7ZBwQRBCEQSrRFoQUSeOEfdFXolswtY49irDGkdk0amWLdtSJcaZ8TvKSO1DutCc6MV0hAaNO59v8rMbsQRyrrZ2Ph8N+x9atSynakUejRtdPI2UVqGwPZaeRE2OJzGu1E8KhDGY5zIPt91PNOGTRvrZu+6WW7luKcfjtYIzHiYrIzu2MfavdW/FYxh8RxFC6C513XJspkGLhNaS7YAj91ZiwuoNlvMyWuY7ljW1VLhyw/rpmToWubHHrDw5pGygysnby7Kk9r8adxsOhk8zf9J9FFNLqJtv+6nMe1OlDqMxcx57rM8LxMbU52xKt5zvI4rmJ+qyiJ0AAHI1Lu4sLZ05eTOTup55WS5TQwkhu1rQjhAY27Oyyejxlz/Eefha4fdgnflVymukcbtndXYWtBb9JoFYq2+rPAxnAnd3CxQrcfiHL6dMl2S7KiZJd0wSKegJJCkjQGklSSRGThMnHKDg0QQIwlWhom7FC1G3lZaiUeikCAHe1I2isVqJKpEwWmtMHEFZbSjlRzx+JtyBuQkHUQU0OQDM/TvZpKS+xuZLOBNHCQ3SdQ8zS0b7Lad1rKlbb4DxWwWTgvbG8+KzU0G6C28PIDG1JBpad2kN4UOSf4tjYmgzZJYBHNG5jq4dsoppL2u622QTSAnUTv2Kz8jJDb08qcx3TuXWg5s35b65aCVyYaJJSSujzWPiwXvd9bt6PosLFbqdQXbw9Ry8nd00sIFkQACMziBr3S/A9UcQDI+eOVkdQn8WXS021vdKT6oyvzEWXkvyZNRNAcD2UKSSvJrpzW7p0ySdMjJJFJMEkkkgDtIqNxSabQBpwkAnSM4TgobSBSOJWkqRvKia5SNKzW07VKFG3hECsVuJQipC3Zpc4gNHJKz8vqVWyDj+pKY2i5TFYy8mPHaQ51vrZoVDBnLXk72N/uqMji424kn3VnBP5rR2OxVfjWKM5LcnXYL4n081RAK3m5MZjsluwpcbitkaQ1rwB/q4Wi/HzWtDyG6Twb2PyuPPjlvbuw5OlnOyWl2iEWb+kd1Li9OLD42T5n1sw8BR4WKYR4jn6pjwewV98oMeqthwPRYy66xOd91QmjGVkOiq2+G418Fc708EBxP1Dal1HRvzc58o4a3TX7rneoCHC6hkMhf8AlazpI3ruR+qvxXu4pZ/0UtyWdxsVkSDTIQVdbmE6w+tIO1d1RlcXyFzuSrYTSOeWyICEJ+ySoiQSStDaAdJIpkwe0kySAGyiB2TJBASByRKBFaDPaQTBEAkcG1SsNKIFSgDZKtxM110ikmjiZcjtI9VXmnjgadW7uwCy5ppJzb3fAWZjsss9LWZmmc6W7M7D1VQlDyU5VZNI3LZBHG7S4G6SaNkmDn2TDdx5iAxxNx/t7rsulyt/D0C0gjtwQuA6dMC7w3nYrpcHWxjY/ELL+iTn4K4+bF18eW4334uLK4mF+l1WdIqlk5zjjtni1hzhwf8An3ViHMdiPfFl44uQ34vrtX9lRcWz9UALqY+Tk8EcqGOPa200OSzpmNGXt1SPbqLAd/lc51FvjB8lDUXXsF0LsKV7n5GU0281Gz+5Wbn4waJnN4Yd/bZW47JU8+45fg2eVM14c3cqOZul5tAQQuvTjTJBRtf2PCMEIM6ZLlK6QC4RWhu06AdJMkgGTJymtANaJqFOCgJAUQUV7oi8BtlFPaUva0eY0oZcuv8Ax8qs9xedym7JyM3InOdI63EknuU7xRAHoiibZN9haarNlBGaN07tuUTBvsp8mO4WuDeALS2fz0hhFuATkaZXN9UWK3U9SZTPM14+UbPXSOO2voc9l0XS894aY5AHtH1MI/Zc9dtDgPMD2VuN+seIAWvHb1WM5K3x2x3GHm42XjxwODXEbUeVi5Uf/TlzZWmQtDnRi7Zf+FVx3GZjJYzTm81yFPFFJ4tkkk8e4XP8adH106GNskjcfxgWuZGGOHuO6pNjbPkZkMgGlwq/hSdAzXTB+PluJlhstvmv7qTGY5uVI97aDi4k+gtS8ta9cH1KB0U72uFOBohQsAfGfULof4qxCyVs3IIpxHqudjOl4Pal28eW8XLnjrJBunDipZ206x3UVKidlg2voortQG0TSjQTBFwo2lSFBmtJKkkgElMOU4CdAMUgkU6AY87fKhlddjspXu0t+6gKcZtIJb1smUkTC54H6p2sz1M1uiK+7goQdlcnALduAFTqlnamU0sYbNTnFyuFmsAKriODSQeCrrTXssZK4SaU4WGORw7DgqctD2UU769FHqoo9LSr5oZKPHqr8L2vbsDfsq+W3U0EdlXjlcwiitexnfzWrBM7FnEjb0nkeq6SJ7J8Zk0FHSdQHv6Ll2u8WMHa67K90PN/B5f4eRw8GXav6T2KjnjuK43TZ6nE2KCLqmINEoIJruDtS1ogJMckUC8B+3YkKpB4b/FwZqdBJu3+6PpjxC5+E92p0ZppPJb2/wAfC57vS0VuqMZlYUrCKI2PsVwkjS1zhdkLvcy2ZE7P/YzV8ris1uid/wCivw1HmiJxD2alCVLEPKWn4UTmkPo9l0bRCW3sgHcFSjlA/wCpOM0g6lK19j3UKcbG0EmspKPxUkHt/9k=)
- Sweat of the brow doctrine
- a person who **puts in his/her labour** ==**must gets the fruits of it**==
- When an individual **labours on an unowned object** ⛏️, her ==labour becomes **infused in the oebject**==; thus, for the most part, <mark style="background: #00FF3E8C;">the **labout and object cannot be separated**</mark> 

#### Criticism
1. Laobour is <mark style="background: #FF5582A6;">**not a guarantee for innovation or originality**</mark> 
2. **Can property rights invest in a product of labour**? 
3. <mark style="background: #FF5582A6;">**Copying is also labour**</mark> 

<br>

---
### Social Planning Theory


---
## Criticisms of IP
1. Information is **not property**
2. Information is **non-rivalrous**
3. Information **wnats to be free**
4. Free speech - the ==**ultimate challenger of IP**==
5. Social Nature of information and its circulation

---
## Misc
- When it comes to **food receipes 🍒**, → the **functionality is not protected**; but the text or the code is protected
