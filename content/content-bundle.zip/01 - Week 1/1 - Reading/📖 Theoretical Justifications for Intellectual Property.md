---
Number: 2

reading_type: Essay
Week: 1
Module: 
Topics:
Status:: #complete 
tags: [ "#reading #complete  #IPR " ]
Type:: #reading
---

# **READING NOTES** 📚




> [!Reading] Details 
>  
> - **Reading Name**: ***Theoretical Justifications for Intellectual Property***
> - Semester: #7thsemester 
> - Subject:  #IPR 
> - Author:: [[Vishwas Deviah]]


---
## Introduction
- Theories discussed in this chapter
	1. [[John Stuart Mill]]‘s **utilitarian theory**
	2. [[John Locke]]‘s **labour theory**, and
	3. [[George Willhelm Friedrich Hegel]]‘s **personality theory**

---
## Utilitarian Theory
-  **WHAT IS THE UTILITARIAN THEORY?**
	- Greatest happiness among a vast majority of the population; **ensuring absence of pain**
	- If the **aggregate happiness** is ***lesser than*** the **aggregate of all pain** that is produced by the act, then the act is ***not to be pursued*** 🟥

<br>


-  **HOW DOES IPR INCENTVISE INNOVATION?**
	- IPR → provides and **incentive system** on the belief that → ==providing **protection to the innovation or any new creation** would **encourage people** to **openly disclose their innovation**== **without the fear 🔴** that others would **appropriate their creativity**  → thus <mark style="background: #00FF3E8C;">the society would **beneift** as the **creation or innovation is more openly disclosed**</mark> 
	- As per utilitarian theory, **awarding property rights to innovators and producers of creative work** is a mere ==**means to an end**==


<br>

- **WHY ARE TRADEMARKS PROTECTED?**
	1. Because it communicates to the customer **the source of origin of the goods** and the to an extent the **quality of the goods**
		- If trademarks were not protected, then it would **enable another producer to pass of his goods as that of others** → thereby weeding out counterfeit goods
	2. This also **reduces the search cost** for customerswho other wise have to **invest more time to identify goods that they bought previously** and with those they **associate quality** 
	
	> All in all, the **prtoecting marks** would therby <mark style="background: #00FF3E8C;">**maximize the well-being of all people in the society and reduce harm**</mark>  ^6d80c2

<br>

- **HOW CAN COPYRIGHT BE JUSTIFIED FROM THE UTILITARIAN FRAMEWORK?**
	- On the basis that this would **incentivise authors to be engaged in creative works** 🟢 as there would be **no fear of someone appropriating their work**
		- thus, a **monopoly** for a **short duration** would **<u>encourage more people to disseminate their work</u>** … this would ==**enable the public to read, enjoy and appreaciate creative works**==

<br>

- **WHAT ARE THE CRITICISMS OF UTILITARIAN JUSTIFICATIONS?** 
	1. tHAT IT HAS **NOT BEEN ABLE TO BALANCE** ==private== and ==pulbic interests==
	2. That **private intellectual property <u>restricts the use of ideas</u>**
	3. That granting **property rights** to **intangible ideas** <mark style="background: #FF5582A6;">**impedes the flow of knowledge**</mark>  ad also <mark style="background: #FF5582A6;">**prevents or delays downstream innovation**</mark> 
	4. IPR does not allow free flow of ideas
		- eg: if there was a **twenty year restriction** as is present today say o the **invention of the wheel**, → this would have **prevented the emergence of seminal inventions that immediately followed the invention of the wheel**
	5. Tahat IPR **ina way impedes innovations** based on original patents
		- By thus **creating a monopoly situation** by providing **patent protection for 20 years** → it ==**eliminates compettitors in the market and creates a monopoly situation that prevents others from entering the industry**== #important 


---


## Labour theory (Locke)


> [!NOTE] What is the Labour theory?
> - That a person ==**deserves the fruits of his labour**==
> - This would mean that an **IPR** would belong to the **person who created it** because it **involves his labour and all the benefits derive** from such labour which would be the **fruits of his olabour**

<br>


### Locke’s theory
- **WHAT WAS LOCK’S CONCEPTION OF ALL THINGS IN NATURE?**
	- He believed that it was **provided by god** and that it is available to ==**all people**== as it is ==**held** in **common for the benefit of all**==
	- So, **no individual can have prior claim over substances** that are available in nature as **it si meant for the enjoyment of the entire humanity**

<br>


- **WHEN CAN AN INDIVIDUAL THEN CLAIM SOMETHING TO BE HIS PROPERTY?**
	- whEN HE ==**exerts his labour over resources**== because he has ==**added value through his labour**==
- **HOW DID LOCK REACH THIS CONCLUSION?**
	- He said that each individual has **prior property rights in his body**
	- Labour exerted by an individual is his own peroprety as he is the owner of his body
		- Therfore, it is **impossible to separate labour and its product**
- **WHAT IS THE CAVEAT GIVEN BY LOCK WITH REGARD TO HIS JUSTIFICATION FOR PROPERTY RIGHTS?**
	- That proeprty rights can be allowed ==**only if it does not deny the others of resources existing in nature**==
		- thus a person can **exert proeprty rights over resources** after **exerting labour** **<u>onlu if there are enough resources</u>** available in nature 
	- ! Thus, an individual who has exerted his labour over the scarce resource **cannot claim property rights in it**

    
	>Thus [[John Locke]] would have objected to the monopolizatio of **natural phenomenon or natural resources**

<br>


#### Criticisms of Locke’s Theory
1.  
	- Lock had said that **“natural resources do not have any value until an individual exerts his labour on it”**
	- Lock suggested that 99% of the value is **created when labour is mixed with a naturally existing substance** to **create and object**
	- ==Howver, this is **not plausible** when **labour is misxed with naturally existing substance that does not result in transformation of the substance**==
		- *eg: discover of Neem extract having insecticide properties by WR Grace*
2.  
	- ! Labour theory **fails to take into account value added to a product by contributions made by others in the evolution of the product**
	- eg:
		-  although ultiple people hav econtributed to the evolution of a technology, **labour theory** may account for th e**avlue added only by the most recent contributor**
		- prior to **James Watt’s** invention → ther were many others involved in **improving the technology**
			- however prior to Watt’s invention, there were **many other who contributed in the volutio of the steam engine** but **only Watt was able to get the full market value for improvement on the steam egine**

<br>


>![[📖 Theoretical Justifications for Intellectual Property.png]]


---
## Hegel’s Personality Theory
> [!question] What is the "Personality Theory"?
> 
> - That any work or invention **would belong to its author or inventor** becuase it is the ==**manifestation of the creator’s or inventor’s perosnality**==
> 
> 
> ---
> - **WHAT IS PERSONALITY?**
> 	- Accc to [[George Willhelm Friedrich Hegel|Hegel]], it is the ==**will’s struggle to actualize itself**==
> 	- Thus, personality is the **relection of an individual’s will**


<br>

-  **WHAT IS PROPERTY ACCORDING TO HEGEL?**
	- Property Acc to [[George Willhelm Friedrich Hegel|Hegel]] becomes an **expression of the will**
	- Thus acc to Hegel, **==society accepts the <u>external manifestation of an individual’s personality</u> as property==**
	- tHUS when a person **expreses himself through his work**, ti is ==**nothgin but an <u>external manifestation of his personality</u>**==
- **CAN EXTERNAL MANIFESTATION SEEN AS PROPERTY BE ALIENATED AT ANY POINT IN TIME?**
	- nO because it is a reflection of the self

<br>



#### Criticism
1.  
	- A person who **wrties a book** by **copying the works of others** or a **painter who imitates another painter’s work** woudl have done so by ==**expressing his personality regardless of the fact that he is borrowing from someone else**==


---





