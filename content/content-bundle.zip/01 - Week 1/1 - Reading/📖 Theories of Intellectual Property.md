---
Number: 1
Author:: [[William Fisher]]
reading_type: Essay
Week: 1
Module: 
Topics:
Status:: #complete 
tags: [ "#reading #complete #IPR " ]
Type:: #reading
up:: [[ℹ️ Course Details - Intellectual Property Rights|🏫 Intellectual Property Law]]
---
`$=dv.current().Status`
# **READING NOTES** 📚

```ad-Reading
title: **Details**

- **Reading Name**: ***Theories of Intellectual Property ***
- Semester: #7thsemester 
- Subject:  #IPR 
- Author - `$=dv.current().Author`
```

```toc
```


---
## Introduction
### Functions of various kinds of IP Laws
#### Law of copyight 
- protects various ==**original forms of expression**== including ***movies, novels, musical compositions*** and ***computer software programs***
#### Patent Law
- Protects ==**inventions**== and ==some kind of **discoveries**== 
#### Trademark law
- protects ==**words and symbols**== that are used for **identification of consumer goods and services**

#### Trade-secret law
- Protects **==commercially valuable information==** such as *soft drink formulas, confidential marketing strategies, etc*
	- these are things that companies **conceal from their competitors**

#### “Right of Publicity”
- protects ==**celebrities’**== ==interests in their **images and identities**==

---
## Preliminary Survey
### Various approaches in theoretical writing around IP
#### 1. Utilitarian
> - **What does it seek to do?**
> 	- It seeks to balance the following 
> 		1. **exclusive rights** for the purpose of ==**stimulating the creation of inventions and works of art**==
> 		2. the partial offsetting **tendency of such rights** to <u>curtail the **widespread enjoyment** of these creations</u>

- **What is the danger created the fact that intellectual products are easily replicated, and that their enjoyment by one person does not prevent their enjoyment by another person?**
	- That the **creators of the product** will be **<u>unable to recoup their “costs of expression”</u>**
		- → what this means is that the creators of the product have to **devote time and effort to writing and composing** and also incur **costs of negotiating with publishers or record companies**; 
	- The creators stand the risk of **<mark style="background: #FF5582A6;">being underdcut by copyists</mark>  who <u>bear low “costs of producing”</u>** which is essentially the **costs of manufacaturing and distributing books or CDs**
- **What will be the result of the awareness of this danger?**
	- that creators will be ==**deterred from making socially valuable intellectual products in the first instance**== 🟥
	- **<mark style="background: #00FF3E8C;">How can this economically inefficent outcome be avoided?</mark> **
		- by granting creators the **excluive right to make copies of their creations**
		- this will then have the effect of **empoweing creators** of those **works which the customers find valuable (by which it is meant those goods for which acc to teh customers, there are no equally attractive alternatives)** 
	- Acc to ***Landes and Posner*** → the alternative way sin which creators might be empowered are for various reasons **more wsteful of resources**

<br>

- **How does this argument translate into trademark law?**
	- Trademarks ← economic benefits:
		1. reduction of **customer’s ==search costs==**
			- Customers can **rely upon their prior experiences with various brands**
		2. it **creates ==incentive== for business** to ==**create consistently high-quality goods and sevices**==
			- this is because **they know** that their competittors **cannot trick customers** by **imitating their distincting marks**; this means that the competitors cannot **<u>use the same trademarks and thereby exploit the customer goodwill</u>**
		3. Trademarks also **improve the quality of language** 🟢
			- these woreds **economize on communication costs** and also **<u>make conversation more pleasurable</u>**

<br>


<br>


<br>



#### 2. That a person who labours upon resources that are unowned or held in common has a “NATURAL PROPERTY RIGHT” to the fruits of his efforts
-  
	- [[John Locke]]‘s “proviso” → *that a person may **legitimately acquire proerty rights** b **mixing his labour with resources held “in common”**, only if **after the acquisition**, there is **good enough left in common for others** *
		- [[Robert Nozick]] argued that by the correct interpretation of this proviso is that the ==**acquisition** of the property is **legitimate** ***if an only* if <u>other persons do not suffer net harm therefrom</u>**==
			- He argued that **“net harm”** includes injuries such as **being left poorer than they would have been under a regime that did not permit the acquisition of property through labour”**; however, this ==**did not include diminution of their opportunties to acquire property rights in unowned resourced by being the first to labour upon them**==
		- When argued allong these lines, acc ot Nozick, the **assignment of a patent right to an inventor** <mark style="background: #00FF3E8C;">does not violate the Lockean proviso</mark> ; 
			- this is because **though other persons’ access to teh invention is ofc limited by the issuance of the patent 🔴**, ==**<u>the invention would not ahve existed at all without the efforts of the inventor</u>**== 🟥
			- >Thus, **consumers are helped and not hurt by the grant of the patent**

<br>

- **What would fidelity to the Lockean proviso entail?** 
	1. Person who **subsequently ==invented the same device== ==independently==** must be **permitted to make and sell it** 🟢
		- otherwise, the **assignment of the patent to the first inventor** would **leave them worse off**
	2. The patents <mark style="background: #FF5582A6;">**should not last** longer than on average, the time **it would have taken someone else to invent the same device**</mark>, ***had the knowledge of the invention not disabled them from inventing it independently***


<br>


<br>


<br>

#### 3. Private property Rights are crucial to the satisfaction of some fundamental human needs
-  
	- From this, it follows that **policymakers** should endeavour to **crate and allocate entitlements to resources** in the manner that ==**best enables people to fulfil these needs**==
		- from this standpoint → IP rights → justified on the ground that **they ==shield artifacts (through which authors and artis have expressed their wills) from being modified or appropritated==** on the ground that the protection offered by these rights **are conducive to <mark style="background: #00FF3E8C;">creative intellecual activity</mark>** which is seen as **important to human flourishing** 

<br>

- **What is the argument of Justice Hughes?**
	- HIs argument derives from Hegel’s *Philosophy of Right*
		1. we should be **more willing** to accord **legal protection** to fruits of ==**highly expressive intellectual activites**== such as ***writing of novels*** than to **<u>less expressive activies such as genetic research</u>**
		2. A person’s **persona** or **public image** deserves protection; this is becauseit is an important ==**“receptacole for personality”**== and it deserves protection ***despoite the fact that it ordinarily does not emerge from labour***
		3. While authors and should be **permitted to earn <u>rspect, honour, admiration, money</u>** from the public by **selling/giving away copies of their work**, they **<mark style="background: #FF0000A3;">cannot be permitted to surrender their right to <u>prevent others from mutilitating or misattributing their works</u></mark> **


<br>


<br>


<br>

#### 4. Property rights in general and IPR in particular can and should be shaped in order to hel foster the achievement of a just and dattractive culture
-  
	- [[Niel Netanel]] → emphasises importance of a **robust participatory and pluralist society**
		- in this society → **all person would enjoy both some degree of financial independence** and **considerable responsisbility in shaping their local social and economical environments**
		- this civil society is vital to **perpetuation of democratic instituions**
			- However, this can emerge <mark style="background: #00FF3E8C;">only if nourished by the govt</mark> 
				- Copyright law fosters this in 2 ways
					1. **Production function**
						- provides incentive for creative expression on wide array of **poltical social and aesthetic issues** → this **bolseters the discursive foundations for democratic culture and civic association**
					2. **Structural function**
						- it supports a **sector** of **crative and communicative acitivity** that is relatively **free from reliance on state subsity, elite patronage, and cultural hierarchy** #doubt 
		- However [[Niel Netanel]] argued that **copyright term should by shortened** thereby ==**increasing the size of the “public domain”** that is **available for creative manipulation**==
			- for this reaon, the **copyright owner’s authority to control prep of derivative works** should also be **<u>reduced for the same reason</u>**




