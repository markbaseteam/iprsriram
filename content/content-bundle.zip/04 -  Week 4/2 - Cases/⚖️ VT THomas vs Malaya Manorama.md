---
Number: 7
Week: 4
MainTopic::
Topics:
Status:: #complete
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---

# **Case** ⚖️ : ***VT THomas vs Malaya Manorama***

```ad-Case
title: **Case Details**

- **Name of Case**: ***VT THomas vs Malaya Manorama***
- Citation::
- Year:: 
- Bench Size::
- Subject: #IPR

```

---
- Authors were contributing a stories
	- they then **changed their employment
		- in this new magazine, **they started drawing similar comics**
- ~ HELD: You were in employement with Malayalla Manorama; **you will have to take their permission before using their characters** 

---
# My Notes 

> [!Case] [[⚖️ VT THomas vs Malaya Manorama]] - Summary
> 
> ## Facts
> -  
> 	- Boban and molly and companion characters -> cartoon characters **presented by VT Thomas** in the pages of Malayala Manorama
> 	- He was treated as a journalist and assigned the main function to **draw Boban and Molly in the Weekly** 
> 	- He retired from this occupation on 30th June 1987
> -  
> 	- Thomas **<u>joined a Rival publication called Kala Kaumudi</u>**
> 
> 
> ----
> ## Relevant Provision
> ![[⚖️ VT THomas vs Malaya Manorama.png]]
> 
> ---
> ## Held
> 1.  **WHO OWNS THE COPYRIGHT WRT ERSTWHILE WORKS MADE BY THOMAS WHILE IN EMPLOYMENT UNDER MALAYALA MANORAMA?**
> 	- ~ VT Thomas or any other publisher **would not have the right** to **publish the series of cartoons** that were **drawn by Thomas an <u>published by Manorama during that period</u>**
> 	- Ordinarily and generally -> the **author would be in possession of the copyright in artistic works** 
> 		- reading section 17(a) and (c), the **employer has a <u>statutorily recognised copyright in productions wher the author has created the work under a [[25th August 2022  ✍#1 Contract of Service|Contract of Service]]</u>
> 2.  **IN WHOM DOES THE COPYRIGHT OVER THE CHARACTERS OF BOBAN AND MOLLY VEST?**
> 	- ~ As regards **future production of VT THomas**, there is **no inhibition arising out of <mark style="background: #00FFFE73;">Section 17(c)</mark> that would **prevent him from using the same characters** in his **future works
> 		- *Artistic works that are made by an author as employee <u>while in course of employement</u> -> <u>pass on to the employer</u> in the cases provided under section 17(c);* ***however,*** *==<u>upon termination of employment</u>==*, ***this comes to an end*** 🔴
> 
> 
> 
> 
> ---
> > ## Important Defintion
> > 1. **Contract of Service::** A contract of service is an agreement that is entered into by the company with an individual for availing his/her services.
> > 	- The individual here is the employee of the company and is entitled to the benefits that the employees of the company receive or are entitled to from time to time during the course of their employment.
> > 	- **Control**: The ==**company enjoys control over the work created by the employee**== and the employee is bound to obey the orders of his employer.