---
Number: 1
Week: 4
MainTopic::
Topics: 
Ratio: 
- Substantial similarity is the test to be employed when seeking to find out if there has been copyright infringement
Status:: #complete
Tags: 
- reading 
- case 

- IPR
Type:: #case
Module: 
---

# **Case** ⚖️ : ***RG Anand v Delux Films (1978)***

```ad-Case
title: **Case Details**

- **Name of Case**: ***RG Anand v Delux Films (1978)***
- Citation:: 1978 SC 1613 
- Year:: 1978 
- Bench Size:
- Subject: #IPR

```

> **CONCEPTS DISCUSSED**
> - [[Substantiality Test]]
> - [[colourable imitation]]

<br>


- #### **Jump to [[#Quick Summary of ruling]]**

<br>


---
## Facts
- Appallent RGA is a playwright -> wrote a play/movie called raja hindustani
	- portrayed a love sotry
	- the play became a hit
- Then RG Anand talked to the producer; they wre **brainstorming as to how to make this into a movie**
	- producer from Delux films is uninterested
- Later however, Delux films comes with a **similar plot of lovers, conept is the same;** film called *New Delhi*
	- RGA sees this movie as having stemmed form his discussions with producer

>RGA sued deluxe films for **copyright infringement** 


---
## Issue
1. Whether this is **really infringment**?
---
## HELD
### **similarity b/w concepts**
> - When we compare two works, the first thing we need to look at is ==**substantial similarity**==
> 	- they reinforced the idea that ==**there is no copyright in**==
> 		1. themes
> 		2. tropes
> 		3. ideas
> 		4. **concept**
> 		5. **themes**
> 		6. **plots**

#### HOW TO DETERMINE IF THERE IS SUBSTANTIALLY SIMILARITY (in case of a dichotomy
- iF the viwere feels that **there is great degree of similarity** b/w the **instant work and the previous work** [^1]
- the consumers will have to feel that there is copyright infringement involved here

>No prudent person would say that the films are similar enough to entail **copyright infringement** 

[^1]: This shows the **inherent subjectivity of copyright**


<br>

<br>


### **what is the threshold?**
- Creatitvity has **high threshold**
- Doctrine of [[colourable imitation]] 


<br>

----
# Post-script
### Contention of Defendants
> ![[⚖️ RG Anand v Delux Films (1978).png]]


---
# Quick Summary of ruling
> [!note] 
> 1. No infringement of copyright. Ideas are not protectable as part of copyright protection.
> 1. The theme of the work can be identical, but its execution must be different to constitute originality.  
> 1. No colourable imitation of the play’s script.
> 1. If an ordinary man can point out that there is a replication of someone else’s work, it would amount to a breach of copyright.  



> [!note]
> 
> 1. **UNDERLYING EMOTION REFLECTED BY THE PRINCIPAL CHARACTERS AND ITS COPYRIGHTABILITY?**
> 	1. Generally, this alons is not sufficient to avail copyright protection
> 	2. However, if the **<u>same emotions</u>** are **==portratyed by a <u>sequence of events persented in like manner expression and form</u>==**, then **infringement would be proved**
> 2. **WHAT FALLS WITHIN THE SUBJECT OF COPYRIGHT**
> 	- Copyright protects
> 		1. $ the **original expression of thought** or information in **concrete form** #important and
> 		2. NOT the **original expression or thought** **itself**
> 		3. ! THere can be <mark style="background: #FF0000A3;">**no copyright** in an uidea, subject matter, theemses, plots , or historical or legendary facts</mark>
> 3. **WHEN DOES INFRINGEMENT HAPPEN?**
> 	- Only when there is **use direct or indirect** of the P's work
> 4. > ![[⚖️ RG Anand v Delux Films (1978)-1.png]]
> 5. **DOES COPYRIGHT VEST IN THE <u>MANNER AN POSTURES OF THE ACTORS USED BY THEM IN PERFORMING A PLAY?</u>**
> 	- NO
> 6.  **WHETHER INTENTION TO PLAGIARIZE IS NOT ESSENTIAL TO ESTABLISH LIABILITY FOR INFRINGEMENT OF A COPYRIGHT OR FOR PLAGIARISM OF LITERARY PROPERTY?**
> 	- NO; one **can be held liable for infringement which is ==unintentional== or that which is ==done unconsciously==**
> 
> 1. >![[⚖️ RG Anand v Delux Films (1978)-2.png]]
> 2. **WHEN DOES [[colourable imitation]] ARISE?** #important 
> 	- When the ==**aggregate of the similarities**== between `1` the **==copyrighted work==** and the ==**copy**== => lead to the <mark style="background: #00FF3E8C;">**cumulative effect**</mark> that 
> 		1. the ==defendant had **imitated the original**== 
> 		2. and the **similarities** b/w the two works are <mark style="background: #FF0000A3;">**not coincidental**</mark>
> 		 
> 		Then there will be **reasonable inference** of [[colourable imitation]] or of ==**appropriation of the labour of the owner of the copyright by the defendant**== 
> 
> 1. **ENUNCIATION OF THE [[SPECTATOR READER TEST]]** ^5c1677
> 	- The surest and safest test to **determine whether or not there has been a violation of copyright** is to see if the reader/spectator/view 
> 		1. after having **read or seen both the works** is 
> 		2. **clearly of the ==opinion==** and gets the ==**unmistakeable impression**== 
> 		3. that the <mark style="background: #00FF3E8C;">**Subsequent work appears to be a copy of the original**</mark>
> 
> 1. **WHAT HAPPENS IF  THE ==THEME IS THE SAME== BUT IS ==PRESENTED AND TREATED DIFFERENTLY== SO THAT THE SUBSEQUENT WORK BECOMES A COMPLETELY NEW WORK?**
> 	- In that case, **no question of copyright violation arises**
> 	
> 2. **WHERE HOWEVER APART FROM <u>SIMILARITIES APPEARING IN THE 2 WORKS</u>. THERE ARE ALSO <u>BROAD DISSIMILARITIES WHICH ==NEGATIVE THE INTENTION TO COY THE ORIGINAL==</u>**
> 	- Then **no copyright infringement**
> 1. **WHY IS IT DIFFICULT TO PROVE VIOLATION FO THE COPYRIGHT OF STAGE PLAY BY A FILM PRODUCER?**
> 	- BEcaue unlike a stage play , a **film has a much broader perspective, wider field, and a bigger background** where the ==defendants canbe **introducing a variety of incidents give a colour and complextion different from the manner in which the copyrighted work has expressed the idea**==
> 	- ! However, if the veiwer after seeing the film **gets a totatlity of impression that the film is by and large a <u>copy of th eoringal play</u>**, then <mark style="background: #00FF3E8C;">violation of copyright may be said to be proved</mark>
> 
> <br>
> 
> 
> > [!abstract] Applying aforementioned principles to the case
> > 1. 
> > 	- @ Play focussed upon **marriage between person belonging to different states**; this was the ==**only aspect of provincialism that was discussed**==
> > 	- & However, the moview concerned **parochialism of the landlords**; this aspect is **<u>missing from the plat</u>**
> > 		- Furthremore, the mview deals with provicialism with regard to 
> > 			1. **marriage** 
> > 			2. **evils of a caste ridden society**, 
> > 			3. the **evils of dowry**
> > 		- **<u>The latter two ==do not appear in the play==</u>** #important 
> > 2.  
> > 	- In the play, **both the parents of the couple knew each other**
> > 	- In the movie on the other hand, **that is not the case** 
> > 3.  
> > 	- IN the play there was a **suicidal pact between the lovers**
> > 	- However, in the movie, ther is **only a suicide note left by one lover** 
> > 
> > <br>
> > 
> > > [!Case] Verdict
> > > 1. That the **dissimilarities** between the play and the move **<u>==far outweigh the effect of the similarites==</u>**
> > > 2. ~ There is **no cogent evidence** that the Defendant committed [[colourable imitation]]
> 
> 
> 
