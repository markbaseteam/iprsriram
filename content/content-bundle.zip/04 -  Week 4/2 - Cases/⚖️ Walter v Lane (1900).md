---
Number: 2
Week: 4
MainTopic::
Topics:

Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
Ratio: 
- Effort makes the work original 
- The House of Lords held that a **person who made notes of a speech delivered in public**, transcribed them, and p**ublished in a newspaper a verbatim report of the speech** was the author of the report within the meaning of the Copyright Act 1842. Thus, ==**he was entitled to the copyright of the report**==, and he could assign that copyright.
---

# **Case** ⚖️ : ***Walter v Lane (1900)***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Walter v Lane (1900)***
- Citation::
- Year:: 1900
- Bench Size::
- Subject: #IPR

```

> The House of Lords held that a **person who made notes of a speech delivered in public**, transcribed them, and p**ublished in a newspaper a verbatim report of the speech** was the author of the report within the meaning of the Copyright Act 1842. Thus, ==**he was entitled to the copyright of the report**==, and he could assign that copyright.

Status:: #partiallycomplete 

---
## Fact
-  
	- Aristrocrat gave a speech; transcribed the speech; put it into the newspaper
		- the newspaper was *The Times*
	- The respondent R published a book containing **speeches given by the aristocrat** inlcuding the aforementioned speeches, which were **taken substantially from the reports of those speeches in *The Times* **


---
## Issues
1. Whether the reporter is the **author of** part of a book within the meaning of the act?
2. Whether he is **entitled to the copyright in It**? 

---
## HELD
-  
	- Apex Court ->
		1. despite it being a **word to word transcirption**, the fact that there was **effort put in into transcribing the speech and making it available to the audiences** -> **involves labour** -> therefore ==**orinality**==
			- > thsu ==**fruits of labour**== -> means to **determine if a work is original**


> [!Case] Holding in Detail
1.  

2.  
	- 