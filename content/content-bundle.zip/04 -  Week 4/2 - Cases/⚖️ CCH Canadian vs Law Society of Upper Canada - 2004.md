---
Number: 4
Week: 4
MainTopic::
Topics:
Status:: #partiallycomplete
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---

# **Case** ⚖️ : ***CCH Candadian vs Law Society of Upper Canada - 2004***

```ad-Case
title: **Case Details**

- **Name of Case**: ***CCH Candadian vs Law Society of Upper Canada - 2004***
- Citation::
- Year:: 
- Bench Size::
- Subject: #IPR

```

employed[[Doctrine of Skill and Judgement]] 
![[Doctrine of Skill and Judgement]]

---
-  
	- Appellant Law society -> operates and amaintains a research library of legal materials
	- 1993: **respondent Publishers (R)** -> began **copy right infringement** against the Law society; sought a declaration of subsistence and ownership of copyright in specific works and a declaration that the Law SOciety had infringed copyright when the great library reporduced a copy of each of the books of the publisher
		- !  they sough a **permanent injunction** that **prohbits the society** from **reproducing the works** as well as **any other works they published**
	- $ Law society denied liability
		- claimed that **copyright is not infringed** when a single copy of a reported deiciions, case summary, statute, ora limited selection of text from a treatise is made by the Great Library staff or one of its patrons on a self-service copier for the purpose of research
		- 
- CCH sued Law society for copyright infringement

---
## Issues?
1. are the publishers mateirals original works protected by copyright 

#incomplete 

---
## Held
1.  **THE LAW SOCIETY DID NOT INFRINGE ON ANY RIGHTS**
	- The Law society **did not infringe any copyright** when **single copies of decisions, statutes, regulations etc** were made by the library or by its patrons using photocopiers
2. !  **WHAT IS THE DOCTRINE OF SKILL AND JUDGEMENT?** #important 
	- Skill Labour and Judgement
	1. We have to **discard the ==labour element== of [[sweat of the brow doctrine]]**
		- rather than <mark style="background: #00FF3E8C;">Skill</mark>, <mark style="background: #FF0000A3;">labour</mark>, and <mark style="background: #00FF3E8C;">judgement</mark>, the **court went with <mark style="background: #00FF3E8C;">skill</mark> and <mark style="background: #00FF3E8C;">judgement</mark>**
	2. however, the solution is **not relying on [[modicum of creativity]]**,  rather it is to 
			1. erase labour
			2. and focus on **==skill==** and ==**judgement**== #important [^1] [^2]
3.  
	- Creativity is **not the ultimate threshold for orignality**; <mark style="background: #FF5582A6;">CREATIVITY IS **NOT REQUIRED TO MAKE A WORK ORIGINAL**</mark>
	- rather, what is important is <mark style="background: #00FF3E8C;">skill</mark>  and <mark style="background: #00FF3E8C;">originality</mark> 

---
## Ruling in bit more depth
1.  
	- Copryuright **does not protect ideas** it <mark style="background: #00FF3E8C;">**protects their expression**</mark> 
	- Learned judge **rejected** the [[modicum of creativity]] test laid down in [[⚖️ Feist vs Rural Telecom Communication]] as it was **too hight; but also fround the [[sweat of the brow doctrine]] to be **too low** #important 
	- ==**Middle ground**== -> original work should be
		1. ~ product of an **exercise** of **==skill and judgement==** #important 
			1. Skill: is the **use of one's knowledge** developed **aptitutde** or **practiced ability** in producing the work
			2. Judgement:: use of one's **capacity for discernment or ability to form an opinion or evaluating** by comparing different possible options in producing the work
		2. ! THe exercise of skill or judgement ==**must not be so trivial that it could be characterised as a <u>purely mechanical exericse</u>**==


1.  
	- Provideing access to a machine that could be used to infringe copyright **does not suggest sufficient "authorisation" to violate copyright** 
		- It is rather **presumed** that a patron with access to the machines would **use them lawfully**
			- ! however, **this presumption can be rebutted by evidence** that shows a **certain relationship or degree of control existing between the authoriser and the person who committed the infringement**
				- *in this case; no such evidence has been presented* 
				- ~ In this case, **<u>there was no master slave relationship</u>** and therefore, **there could not have been exericse of such control over the patrons**

1. 
	- ==**Creativity**== is <mark style="background: #FF0000A3;">not required in order to render a work original</mark>

2.  
	- **[[Fair dealing]]** is an **integral part of the copyright act**  and not simply a defence
	- When claiming fair dealing, D must show 
		1. that the daling was **for the purpose fo either research or private study**, and 
		2. that it was **fair** 
	- ~ Research -> must be given a **large and liberal interpretaion** so as to ensure that the rights of the users are no unduly costrained
	- Learned judge resorted to the following six factors to ==**determine fairness:**==
		1. The purpose of the dealing
		2.  The character of the dealing
		3.  The amount of the dealing
		4.  Alternatives to the dealing
		5.  The nature of the work
		6.  The effect of the dealing on the work
		
		>That upon applying these factors, the **law society had put in restrictions for copying the materials** ; that the LIbrary was thus **acting fairly** 



[^1]: This was the middle ground; 
[^2]: anything that is **purely a mechanical** has now been removed #important 