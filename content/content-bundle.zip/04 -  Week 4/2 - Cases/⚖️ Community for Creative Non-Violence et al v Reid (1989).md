---
Number: 8
Week: 4
MainTopic::
Topics:
Status:: #complete 
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---

# **Case** ⚖️ : ***Community for Creative Non-Vilence et al v Reid (1989)***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Community for Creative Non-Vilence et al v Reid (1989)***
- Citation::
- Year:: 
- Bench Size::
- Subject: #IPR

```

---
## Facts
- Sculpture commission; completed; installed; CCNV applied for copyright over the sculpture
- Artist objected

---
## Isseus
1. Who is the ==**owner**== of this work
2. Can this be considered work made for hire
---
## Held'
### District court
- Association is exclusive owner **becasue the artist was the emplyee**
- There is **some element of ownership that is ==transferred to the association in this case==**
- That **the sculpture could not have been commissioned** w/o CCNV having commissioned the wor

### Appeal
1.  
	- Sculptor was an **independent contractor**
	- No independent contract existed b/w the two; therefore **==there existed no contract of employement==**; it was <mark style="background: #FF0000A3;">**not an employter-employee relationship**</mark> 
2.  
	- It is **work made for hire**
	- Even if the person is **independent contractor**, the work was **comissioned by CCNV**; 

---
# My summary
> [!Case] Community for Creative Non-Violence et al v Reid (1989) Summary


## Facts
-  
	- Petioners P hired respondent artist R to **create a sculpture fo homeless individuals**
	- P entered into an agreement with R to produce a statue
	- R accepted most of CCNV's suggestions and directions as to the sculpture's configuration and appearance
	- Work was completed; R was paid the final installment; 

<br>

-  
	- The parties had however not discussed copyright in the scultrupre
	- they thus **filed ==competing copyright registration certificates==** 

<br>


Contented by Plaintiffs that this si a **work made for hire** as defined under US copyright law ![[⚖️ Community for Creative Non-Violence et al v Reid (1989).png]]

<br>

### About the Act
- **==General Rule==**  => the author is the **party who actually creates the work**
	- **<mark style="background: #FF0000A3;">Exception</mark>**  -> if the work is [[work made for hire]] , then **the employee or other person for whom the work was prepared is considered to be the author** #important 
- 


---
## held
1.  
	- TO find out whether the work is [[work made for hire]], court has to **apply general common law of agency principles** to ascertain whether the **work was prepared by an ==employee==** or an ==**independent contractor**==
	- Depending on that outcome, section 101(1) or section 101(2) will be applied
	- Act does not define ***"employee"***; however, it must be inferred that Congress meant that term connotes its **common law meaning** => <u>conventional relationship between employer and employee</u>
	- ! The sculpture is **not [[work made for hire]]** as defined under Section 101
		- R was an ==**independent contractor**== rather than an employee
		- though CCNV members directed enough of the work to ensure that the statue met their specifications, **<u>all the other relevant circumstances go against a finding of employment relationship</u>**; these include
			1. R engages in a skilled occupation
			2. He **supplied his own tools**
			3. He workd in Baltimore without daily supervision from Washington
			4. he was ==**retained for a relatively short period of time**==
			5. He ==had **absolute freedom** to **decide when and how long to work in order to meet his deadline**==
			6. He also had **total ==discretion in <u>hiring and paying assistants</u>==** 
			7. CCNV **had noright to assign additional projects to Reid** and they ==paid him in a **manner in which independent contractors are often compensated**==
			8. They **did not engage regularly in the business of creating scultupre**, or in fact any business
			9. CCNV **did not pay payrol or social security taxes**; they ==**did not provide any employment benefits or contribute to unemployment insurance or workers' compendation funds**==
		- >The Court held that a work was a work for hire when either the work was prepared by an employee within the scope of his or her employment or it was included in the list of nine categories of works enumerated in § 101(2). 
		- >The Court rejected petitioners' arguments that the hiring party's right to control or actual control tests should determine whether the work was for hire. The Court stated that because the statute did not define the terms "employer" or "employee," they had to rely on the conventional master-servant relationship understood by the common law. Upon determination of whether a work was prepared by an employee or by an independent contractor, the appropriate subsection of § 101 could be applied. 
			- ! Furthermore, as Ps **themselves concede**, the work in question **<u>does not satisfy terms of section 101(2)</u>**

1.  
	- However, ==**CCNV nevertheless <u>may be a joint author of the scultpure</u>**== and thus, a **co-owner of the copyright** ***<u>if</u>*** on <u>remand</u>, the *district court determines that the parties prepared the work with the <u>intention that their contributions be merged into inseparable or independent parts of a unitary whole</u>* 


> [!Case] Verdict
> 1. CCNV is **not the author of the work <u>by virtue of the [[work made for hire]] provisions of the act</u>**
> 2. However, they ***may be the joint author of the sculpture*** if on remnd, the District court determines that CCNV and Reid prepared the work with the intention that their contributions be merged into inseparable or indterdependent parts of a unitary whole


