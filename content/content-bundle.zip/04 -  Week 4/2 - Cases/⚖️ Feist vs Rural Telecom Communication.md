---
Number: 3
Week: 4
MainTopic::
Topics: 
Status:: #partiallycomplete 
Ratio:: Shift to [[modicum of creativity]]
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---

# **Case** ⚖️ : ***Feist vs Rural Telecome Communication***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Feist vs Rural Telecome Communication***
- Citation::
- Year:: 1991
- Bench Size::
- Subject: #IPR

```

---
## Facts
- RT created **localised yellow pages** and **incorporated all the contacts**
	- in terms of coopyright, **yellow pages is a compilation**
- Yellow pages -> telephone directory created; **Feist wanted to borrow some data from the yellow pages**; RT refused

>Feist **went ahead and copied it** w/o the permission of RT

- Rural sued for copyright infringement

---
## issue
1. whether **anems, addrsses, phone numbers** in the telephone directory be copyrighted

---


## Held
1.  
	- First person to document a fact is that **they have merely discovered the thing**; they have **not created it**
2.  
	- The **==fact(data)== is not protected** in the **compilation**
	- what is protected is the **<u>way in which it is  protected</u>** 
		- this is <u>different from how we use copyright in other works</u>

1.  
	- Even though the plaintiff had engaged in useful efforts, nd **did not copy its directory from others**, the ==end product is a "**<u>garden variety white pages directory</u>**"== that is **devoid of een the slightest trace of creativity** 
2. 
	- Things like alphabetical sequncing -> are **time honored**, **commonplace**, and **practically inevitable**


>- Fight said that it is **Not SLJ**, what matters is **==modicum of creativity==**
>	- it was problematic because **it tried to push a kind of rationality into copyright** -> shift from **swaet of brow** to [[modicum of creativity]]



> [!Case] HOlding 1
> - THe names towns and telephone numbers listed in white pages are **not protected by** the telephone company's **copyright** in its combined white and yellow pages directory
> 	- this is because ==the listings in the white pages were **not original to the company since**==
> 		1. the **listings** rather than owing their origin to the telephone company were **uncopyrightable facts**
> 		2. the telphone company hsa **not selected or aranged these uncopyrightable facts in na original way** that is **sufficient to satisfy the ==minimum standards for copyright protection==** 

> [!Case] Originality requirement; quantum of Originality
> - In order to qualify for copyright protection, a work must be **original to the author** 
> - ==**Original**== means only that **the work was independently created** by the author and tha tit **posseses at least some minimal degree of creativity**
> - ==**Originality**== does not signify novelty; a **work that closely resembles another work may be original**, ***even though it closely resembles other works so long as the <u>similarity is fortuitous and not the result of copying</u>*** 


> [!case] Facts whether copyrightable 🔴
> - Facts ->**whether compiled or not** are ==**not original**== and therefore ==**not copyrightable 🔴**==
> 
>>[!check] Limited protection for Factual works, arrangements, and selections
> >- Facutal compilation **is eligible for copyright if** it 
> >	- Features and **==original selection or arrangement of facts==**
> >	- but the copyright is **limited to the particular selection or arrangement**
> >	
>>>In No case will ropyright extend to teh facts themselves 🔴

> [!Case] Collective and Derivative works when protected
> - They can be subject to copyright
> - however, it will **protect ==only the author's original contributions==** but **<u>*not the facts or the information conveyed*</u>**


---
# My notes
## Facts
-  
	- Respondent R sued petitoner P for **copyright infringment** because the **petitioner hasd used information contained in its white pages** in the **<u>compilation of its own directory</u>**

---
## Held
1. **REQUIREMENT OF ORIGINALITY**
	- To qualify for copyright protection, a work must be ==**original to the author**==
		1. This means that the work was **==independently created by the author==** and that it possesses at least ==**some minimal degree of creativity**==
		2. creativity **<u>does not mean novelty</u>**
		3. A work of an author can be original **even if it closely resembles another work** as long as the **<u>similarity as fortuitous</u>** 🟢 and **<u>not the result of copying 🔴</u>**
2. **MEANING OF ORIGINALITY**
	1. The work was **==independently created==** by the author
	2. that it possess [[modicum of creativity|at least some minimal degree of crativity]]
		- This creativity level is **very low**, thus **<u>even a slight amount would suffice</u>** 
3.  **WHEN SUBJECT MATTER CONTAINING ONLY FACTS CAN ATTRACT COPYRIGHT PROTECTION**
	- A directory that **contains absolutley no protectable written expression** and **only facts** <mark style="background: #00FF3E8C;">will **meet the constitutional minimum for copyright protection**</mark> if it **<u>features an ==original selection or arrangement==</u>**
4.  **WHETHER FACTS ARE COPYRIGHT PROTECTABLE**
	- Facts <mark style="background: #FF0000A3;">**cannot be subject to copyright protection**</mark> regardless of whether or not they are part of a **compilation**
5. **WHEN A FACTUAL COMPILATION CAN BE ELIGIBLE FOR COPYRIGHT PROTECTION?** #important 
	1. When it **features an ==original selection/arrangement==** of facts; however, the copyright is **<u>limited to the particular selection or arrangement</u>**
		- ! What is required is that an author has **made a selection or arrangment** `2` **independently** meaning **without copying that selection/arrangement** from another and has **displayed some minimal degree of creativity** 
	2. Copyright can **in no even extend to the facts themselves**

> [!Case] Verdict
> - ! NO COPYRIGHT PROTECTION
> 	1. THe listings **did not owe their origin to the company** and 
> 	2. listingswere <mark style="background: #FF0000A3;">**uncopyrightable facts**</mark>
> 	3. The company had **no coordinated or arranged these in an <u>original way</u>** so as to **==satisfy the minimum standards for copyright protection==**  which includes
> 		1. **creativity** necessary to **demonstrate originality** (lacking in this case in order to avail copyright protection)
> 		