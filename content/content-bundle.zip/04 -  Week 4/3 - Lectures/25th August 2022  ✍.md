---
Week: 4
LectureNumber:  8
Topics:
Date:  2022-08-25
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  25th August 2022 - Intellectual Property Law L(8)
Type:: #lecture
---


# **Lecture Notes** 📝 :  25th August 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  25-08-2022**
- Week: 4
- Lecture No.:  8
- **Semester**: #7thsemester 
- [Link to Lecture]

```
Status:: #complete
Module:: 






---

> ```toc
> ```


----
## Derivative Work
- Any sorto f**translation** or **abridgment**; something that **derives from an existing work** becomes a ==**derivative work**==
- If a derviative work is to require protection -> it would require **==material change==** and **🔴 not just minor alternation** 
	- therefore, *skill, labour and judgement* expended in the process of copying **would not confer originality upon them** 


<br>

> [!Concept] Note
> - **CAN ABRIDGMENT BE SUBJECT TO COYRIGHT?**
> 	- Yes 🟩
> 	- eg: illustrated version of *Alchemist* by Poelho Coelho 

<br>

----
### Adapations
![[25th August 2022  ✍-2.png]]
> - eg
> 	- *5 Point Someone* and *3 idiots* 
> 	- Moral right : you cannot adapt it such that the author feels disgusted by the work

> [!Concept] Note
>- Going by [[⚖️ RG Anand v Delux Films (1978)]], we will have to **see the context** 


> - eg
> 	- The Kangana ranaut poster thingy
> 	- **WOuld constitute copyright infringement**

> - eg: 
> 	- **Zindagi Na Milegi Dobara** and **Lords of Dogtown** 


----
> [!quote] Quote from Benjamin Franklin
>  *Either write something worth reading or do something worth writing*


---

### Who is an author?

> ![[25th August 2022  ✍.png]]
> 
> 
> - Producer is considered as **author** wrt to **cinemeatograph film and sound reporter**
> 	- ! criticism
> 		1. they might not have creative input
> 		2. they might not be creatively involved to the extent that they are **financially involved in the movie** [^1]

<br>


> ![[25th August 2022  ✍-1.png]]
> - This is the first time that the act introduces the notion of distinction b/w author and owner (?)
> 	- this is **not done in the defintion of author**

<br>


####  DISTINCTION B/W AUTHOR AND PRODUCER
- Owner -> person who has **economic rights**
	- Moral rights **continue to be with teh person who has created it**
- ! However, the **author is conflated with the producrs in the copyright act** 
	- it **takes away any possiblity** for conversation about **why should a producer be deemed to be an author and not just a producer**?
	- $ Countries such as France deem copyright as the **law of th eauthors** 🇫🇷
		- that is why **author's rights hold paramount importance for them**
	- @ US adopted a cold definition of who is an author 🇺🇸
		- THey do not say who the author is; they say **any person who owns the ==certificate of registration==** will be the author
	- $ UK Section 8 says that the author is someone who creates the work 🇬🇧
		- there is thus some possiblity of debate
	- ! Indian defintion is **confusing** 🇮🇳
		- In India, **something as simple as a [[royalties]] becomes a difficult task** 
		- Despite the capitalism system, **the laws do not make it any easier for the author** 
			- eg: *Arr acc to the law was **not the owner of his work**; he was **also not the author***
				- this is an **institutionalised unfairness** against those who **create these works** 

<br>


#### WHO CAN BE AN AUTHOR
1. Natural person
2. company
3. ! Animals cannot be authors
	- ~ case: naruto: monkey accidentally clicked selfie; **court held: *that monkey cannot be considered to be an author* ** 
		- rationale: that **there is no intellectual capacity in the monkey** to create such works
4. AI - Artificial Intelligence


<br>

#### CASES OF JOINT AUTHORSHIP
-  
	- There can be more than one author to a work
	- ! US - Section 101 - inseparable or independent parts of a unitary whole

##### Criterion
###### 1. Contribution
- The contribution must be **something that we can see in the work of joint authorship**

###### 2. Collaboration
- There msut have been **some communication b/w the authors** for **collaborating**
- ~ [[⚖️ Childress vs Taylor]]
	- there was  a dramatic work that was **performed by somebody else**
		- this person was **involved in thr peocess of the cration of the original dramatic work** -> **without taking permission** 
	- >THere must have been **intent to create joint work**
		- held that **subsequent authorship was infringement
- ~ Case of [[Ray vs Classic FM ]]

>Case summaries for the above cases provided below



<br>


#### Author vs Owner
- 
	- Author gets moral rights and while owner gets the money
		- work-made-for -higher has **allowed for existence of middlement** which has in turn **allowed these middlemen to get recognition
	- >This has led to the situation that required the [[Statute of Anne]]

---

### Types of work made for Hire

#### 1. Contract of Service
- Long term; ==**master-slave relationship**==

>#### **Copyright act in US envisages few more relationship**
> 1. Employer employee relationship
> 	- contribution to a collection
> 	- Work done by a person will be that of his employee
> 	- Eg where **people are given commission for work** eg: Varun Grover
> 	- translations might also be considered work made for hire when someone is commissioned to do the work
> 	- supplementary work -> when anyting is created as an **adjunct to  a work** -> *for explainging, illustrating etc*
> 	- instruction texts -> user manual
> 	- tests and answer materials for a test
> 	- 
> 

> ##### Freelancers
> 1. Wedding photography
> 	- The photgrapher owns it

- IN India, section 17 of the copyright Act

[[⚖️ VT THomas vs Malaya Manorama]]
![[⚖️ VT THomas vs Malaya Manorama]]


<br>


#### 2. Contract for service
- Contract **for a particular task** 
- In contractws **for services**, there is some sort of equality b/w the authors and owners since they are 2 different entities; the **author is not in the employment of the owner**

![[⚖️ Community for Creative Non-Violence et al v Reid (1989)]]


<br>

---
### Terms of Copyright
1. The concept of [[Post-mortem auctoris]] - life time of author + x years
2. LDMA = Section22 - 60 PMA
3. At the death of the author - 60 years - section 24
4. Photograph - Section 25 - 60 years
5. Films - section 26 - 60 years [^2]
6. Recoreds - 60 years - section 27
7. Govt work - 60 years - section 28

---
# ⚖️ Case summaries
![[⚖️ Childress vs Taylor]]

<br>


![[Ray vs Classic FM]]


---
# Post Script
## Term of Copyright
[[Section 22 of Copyright Act]]

[^1]: There is difference between owner and producer
[^2]: There is **no post mortem auctoris** as the **<u>movies are owned by production companies, etc</u>**