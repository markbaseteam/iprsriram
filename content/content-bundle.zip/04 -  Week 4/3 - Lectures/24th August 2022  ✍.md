---
Week: 4
LectureNumber:  7
Topics:
Date:  2022-08-24
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  24th August 2022 - Intellectual Property Law L(7)
Type:: #lecture
---


# **Lecture Notes** 📝 :  24th August 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  24-08-2022**
- Week: 4
- Lecture No.:  7
- **Semester**: #7thsemester 
- [Link to Lecture]

```
Status:: #complete
Module:: 

---
> ```toc
> ```


---
-  
	- Blue whale -> takes something called [[plankton]]
	- Ideas do not have a finite nature; like the ocean
		- Just as the ocean facilitates the creation of plankton, in the same way, **ideas are the foundation of exception**
		- Blue whale in this analogy is the viewr

![[⚖️ RG Anand v Delux Films (1978)]]


---
## Doctrine of Merger 📌
![[Doctrine of Merger 📌]]

---
## ORIGINALITY
#important 
### What is originality?
- It is a **==threshold==**
- With originality, we get into the qustion of ==**whether the work deserves copyright protection or not**==

>- Sweat of the brow doctrine: **can backfire** wrt copyright
>- Modicum of creativity[^1]

-  
	- Originality is a **<u>filtering mechanism</u>** meaning that **works that are not original are not copyrightable**
	- If the work is **not original**, then it **does not get a copyright protection period**. 
	- <mark style="background: #00FFFE73;">section 13</mark> 

<br>

- [[⚖️ Walter v Lane (1900)]] 
	- Aristrocrat gave a speech; transcribed the speech; put it into the newspaper
	- another newspaper -> copied this transcription and put it into their newspaper
	-  
		- Apex Court ->
			1. despite it being a **word to word transcirption**, the fact that there was **effort put in into transcribing the speech and making it available to the audiences** -> **involves labour** -> therefore ==**orinality**==
				- > thsu ==**fruits of labour**== -> means to **determine if a work is original**


![[⚖️ Walter v Lane (1900)]]

> [!note] Example
> - Efforts put into **transcribing** things said will also be **original** according to this doctrine
> 
>>However, there can be **no copyright of facts**; there can be **no copyright of the fact that *Modi gave a speech on Independence day* ** 


![[sweat of the brow doctrine]]


---
![[⚖️ Feist vs Rural Telecom Communication]]

- Criticism: We need to 

---
![[⚖️ CCH Canadian vs Law Society of Upper Canada - 2004]]

---
> [!Concept] Concluding remarks
> - Originality is **very different from creativity**
> 	- thus ==**originality is the threshold**==

---
## FIXATION
### Principle
- Copyright has to be ==**fixed in a tangible expression**==
	- has to **be on a tangible medium**

### India
- Fixation is important in India
- We have a **closed list like UK** 🇬🇧


[^1]: What matters is that **my work is different from the work of others\


---
# final equation 📏
> **EXPRESSION + ORIGINALITY = COPYRIGHTED WORK**

