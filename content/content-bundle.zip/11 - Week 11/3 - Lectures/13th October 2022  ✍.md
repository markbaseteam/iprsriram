---
Week: 11
LectureNumber:  21
Topics:
Date:  2022-10-13
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  13th October 2022 - Intellectual Property Law L(21)
Type:: #lecture
---


# **Lecture Notes** 📝 :  13th October 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  13-10-2022**
- Week: 11
- Lecture No.:  21
- **Semester**: #7thsemester 
- [Link to Lecture]

```
Status:: #complete
Module:: [[Trademarks]]

---
```toc
```
---
## Monetizing Trademarks
### Rights of Trademark Owner
![[13th October 2022  ✍.png#banner|700]]

![[13th October 2022  ✍-1.png|700]]

![[Section 28 of Trademarks - Rights of a Trademark Owner]]

---
#### Rights conferred
- Primarily the following rights are conferred
	1. Exclusive use
	2. Assignment 
	3. Licensing
	4. Infringement
	5. Seeking correction of register
	6. Alteration of the registered Trademark
- [[section 30 of Trademarks Act]] -> **nominative fair use or parody excpeiton**

<br>

---
### Assignment and Licensing
![[Section 37 of TM Act]]

> ![[13th October 2022  ✍-2.png]]

<br>


> - <mark style="background: #00FFFE73;">**Assignment needs to be registered with the Registrar – Section 45**</mark>

- LICENCCING SHOULD NOT DESTROY THE TRADMEARK
- IT **MAY NOT CREATE AN EXCLUSIVE RIGHT**


<br>


<br>


<br>

---
## INFRINGEMENT
### Section 29 
![[13th October 2022  ✍-3.png]]
- [[section 29 of Trademarks Act]] -> 1-8 provide ==**different categories of infringement 🔴**==
- **Who can sue?** 
	- Only a **registered proprietor**
- **Cause of action?** 
	- Use of a deceptively similar mark that *may not be identical*
- [[Section 27 of Trademarks Act]]
	- Provides that ther eis <mark style="background: #FF0000A3;">**no infringement against an unregistered TM**</mark>

---
#### Section 29(1) - Deceptive similarity
- Identive ==**marks**== and ==**goods and services**==

<br>


---
#### Sections 23(2) and (3) - Likelihood of Confusion
- Usage of the ==**whole TM**== is to be **considered**

<br>

---
#### Section 29(4) - Dilution
![[Section 29(4) of Trademarks Act]]

##### Raymond Limited v Raymond Pharmaceuticals Private Ltd - 2016
![[Raymond Ltd v Raymond Pharamceuticals]]

---
#### Section 29(5) Use of Registered mark as a corporate name - Section 29(5)
- Two conditions to be satisfied
	1. Use of the **==Registered TM==** as the trade name 
	2. Trade or business in the **<font color="#ff0000">same goods and services</font>**

---
### Defenses - Sectoins 30 - 35
![[13th October 2022  ✍-5.png|1000]]

#### Common Use
- Eg: ==**THunder**== ==**chocolate**==
- Where the term is **==common to indicate the quality of goods==**
---
#### Parallel Imports
```ad-check
title:
Parallel imports are also referred to as 'grey-market' goods because although the goods may be genuine, they are sold through unauthorized trade channels.


```


- Goods **==produced and sol legally==** and <mark style="background: #FF00868C;">**subsequently exported**</mark>  #important 
- Each state -> tnetitled to **prohibit or to allow parallel imports** within its **own legal faramework**

> [!danger] Issues of debate
> 1. Whether **parallel importaiotn** constitutes **infringement under [[section 29 of Trademarks Act]]** 
> 2. whether india **recognises the principle of ==internaitonal exhaustion of rights==** under [[section 30 of Trademarks Act]]


<br>


---
#### Exhaustion - Section 30(3) and (4)
- ! Doctrine of Exhaustion means that **an owner of a particular good** **<font color="#ff0000">ceases to have control over further sale of his goods once he has made a valid transaction of sale.</font>** 

- Sale of IP protected items by third parties is generally termed infringing. 
	- The **<font color="#c00000">resale or further exploitation of such products, however, do not fall under the scope of IP protection</font>**
---
##### TATA Sons - Parody Exception
![[TATA Sons v. Greenpeace]]