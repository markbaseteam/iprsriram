---
Week: 11
LectureNumber:  20
Topics:
Date:  2022-10-12
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  12th October 2022 - Intellectual Property Law L(20)
Type:: #lecture
---


# **Lecture Notes** 📝 :  12th October 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  12-10-2022**
- Week: 11
- Lecture No.:  20
- **Semester**: #7thsemester 
- [Link to Lecture]

```
Status:: #partiallycomplete
Module::

---
# 🔁 Recap
- Often times, [[Dilution by Tarnishment|tarnishment]] 's first step is **"[[Dilution by Blurring|blurring]]"**

![[Difference between Tarnishment and Blurring]]



<br>




---
# 📝 NOTES

![[Difference vs Confusion]]

---
## Dilution by Disparagement and Comparative Advertising
![[Dilution by Disparagement and Comparative Advertising]]

----
### Cases
- [[⚖️ Pepsi vs Hindustan Coca Cola]]
- [[⚖️ HUL vs Amul]]

---
## Parody Excetion
- Case: [[⚖️ Mattel vs MCA Records]]

---
## Registration Procedure for Trademarks
- Patents and trademark office is the same
- There is a **Registration Certificate**; it is very important
	- Courts **rarely get into the merits of it**
	- It is **valid across India**
	- Though an application under the [[Madrid Protocol (1989)]] -> one can also **obtain registration in other countries as per preference enlisted**
	- Registration is important to **boost goodwaill**
---
### Steps towards Registration
> [!check] Benefits
> - Benefits of Registration
> 	1. Prima facie evidence of ownership of TM
> 	2. Stronger enforceability of TM to owners
> 	3. Easier to commercialise
> 	4. Registratio valid in whole of territory of India
> 	5. Boost towards Goodwill

> [!Concept] Overview
> ![[12th October 2022  ✍.png]]

---
#### 1. Assessment
1. Identification
2. Public Search 
	- Patent office in India, and
	- WIPRO
3. [[NICE Classification]]
4. Cost (Schedule 1)
---
#### Application - Sections 18-23
- APplication -> may be **supported by ==proof of "usage"==** 
	- Particular goods preferebly may be included in **more classes of goods and services**
- The Trademarks Act, 1999 allows a single application to be made for registration of Trademark for goods or services falling in more than one class of goods or services.
---
#### Examination of Application - Section 18
- Done by registrar
- Causes search to be made **amongst the registered TMs** and **pending applications** to ascertain ==whether there is **any mark identical with or confusingly similar or which may show an association with the mark sought to be regisered**==
- <mark style="background: #00FF3E8C;">**first in time, first in right**</mark>
```ad-warning
title: What the registrar can do
1. He may <mark style="background: #00FF3E8C;">**accept**</mark> <mark style="background: #FF0000A3;">**reject**</mark> or ==**parially accept with amendments**==
	- In cases of <mark style="background: #FF0000A3;">**registration**</mark> or ==**partial acceptance**==, the **<mark style="background: #FF4E00A6;">reasoning must be provided</mark>**

```

---
#### Opposition - Section 21
- After the [[#Examination of Application - Section 18]] and ==**acceptance**== , the application is then <mark style="background: #ADCCFFA6;">**advertised on the wesbsite of the Registry**</mark>
	- **Why**:: In order to **<u>==invite any reservation or opposition that other proprietors may have regarding he application==</u>** 
- Read with the **<mark style="background: #00FFFE73;">rules</mark>**, any person can **<mark style="background: #00FFFE73;">within 4 months of the advertisement</mark>** file an <mark style="background: #FF0000A3;">**opposition agaisnt such application**</mark> upon **giving such ntoice in the prescribed format** 
	- Registrar will then **inform the applicant** about such **oppoisition**
	- @ Within **2 months**, applicant will file <font color="#ff0000">**coutner statement**</font> to the opposition with evidence
- Registrar ***may conduct hearing where the parties can defend positions***
---
#### Grant of Registration - Section 23
- When the application is 
	1. **accepted by the Registrar** and 
	2. it has **not been opposed** or if **went in favour of the applicant**
- R will issue certificate
- ! if there is a default on the part of the applicant to fulfill the procedure of application and registration is not completed within twelve months, such application shall be considered abandoned.
- @ Duration of TM -> **10 years**  
- No continuous useage for a period of **==5 years==** can be <mark style="background: #FF0000A3;">**ground for cancellation**</mark>

---
### International Registration - Madrid Protocol
- Useful mechanisms- but still results in the proprietor holding a portfolio of national marks – each enforced separately.
- There **<mark style="background: #FF0000A3;">cannot be an international filing without a national filing/registration.</mark>**
- An a==**pplication filed online through the Indian porta**==l – can file an application to the Bureau - designating all or some of the members of the Madrid Union where you wish your mark to be protected. The ==**application is transmitted to WIPO for examination, registration and publication.**== 
- No separate Registration certificate is issued for an international registration.
- India as a designated country – Section 36E; India as an origin country under Section 36D.



----

# 📄 MISC. POINTS 

- [[Section 27 of Trademarks Act]] allows for [[Passing off (Tort)]] albeit **indirectly**
- [[#1 Assessment]]
	- Section3 - Registrar
	- Section 5 Registry 
	- Registter of trademarks




---
# 💡 CONCEPTS





----
# 🗃️ FLASHCARDS
