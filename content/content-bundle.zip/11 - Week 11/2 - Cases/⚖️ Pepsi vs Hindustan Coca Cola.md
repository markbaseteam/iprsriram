---
Number: 
Week: 11
MainTopic::
Topics:
Status:: #incomplete 
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---

# **Case** ⚖️ : ***Pepsi vs Hindustan Coca Cola***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Pepsi vs Hindustan Coca Cola***
- Citation::
- Year:: 
- Bench Size::
- Subject: #IPR

```

---
## Facts
- Pespis used a phradse in it sads; Coca used this phrase in a disparageing manner
	- "Dil Maange no more"
---
## Held
1. **==intent==** and ==**manner of storyline**== are importnat
2.  
	- THe ad carried insinutaton of competing product
	- The sotyrline -> insinuatied that the product is bad
	- The ad **turned upside down the sotyline used by Pepsi**
3.  
	- All of this -> ==**not healthy competition**==
	- In this case, the veriweres could **easily indentify tha tht eproducts referenced <u>belonged to the defendants</u>**
	- 