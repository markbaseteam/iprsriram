---
Number: 
Week: 11
MainTopic::
Topics:
Status:: #incomplete 
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---

# **Case** ⚖️ : ***HUL vs Amul***

```ad-Case
title: **Case Details**

- **Name of Case**: ***HUL vs Amul***
- Citation::
- Year:: 
- Bench Size::
- Subject: #IPR

```

---
## Held
1. Judge **restrained amull** form **communicating to the public any part fo the advert**
2. Bench said that *as long as tyou **make mofidications that involve removal of protions that disparage the insinuating products**, and **dont use "frozen dessert"**, then the ad can be published*