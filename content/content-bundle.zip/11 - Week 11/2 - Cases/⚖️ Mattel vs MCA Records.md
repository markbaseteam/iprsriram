---
Number: 
Week: 11
MainTopic::
Topics:
Status:: #incomplete 
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---

# **Case** ⚖️ : ***Mattel vs MCA Records***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Mattel vs MCA Records***
- Citation::
- Year:: 
- Bench Size::
- Subject: #IPR

```

---
## Held
1. Not [[Dilution Theory|Dilution]] because it si a ==**parody**==
2. The usage of marsk in **<mark style="background: #00FF3E8C;">Exercise ffo different form of free speech**</mark> would <u>not be considered as dilution</u>
