---
Number: 
Week: 12
MainTopic::
Topics:
Status:: #incomplete 
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module:: 
---

# **Case** ⚖️ : ***Erven Warnik Besloten Vennootschap v J Townend and Sons (Advocaat Case) Factors***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Erven Warnik Besloten Vennootschap v J Townend and Sons (Advocaat Case) Factors***
- Citation::
- Year:: 
- Bench Size::
- Subject: #IPR

```

---
- The plaintiffs were manufacturers of an alcoholic drink named as above – with a mixture of eggs and spirits.
- The defendants came out with a similar drink - marketed with a similar name – the plaintiffs applied for an injunction to restrain the defendants.
- ~ The Court **held that the defendants was passing off their goods as those of the plaintiffs**. In applying the test for passing off, the Court developed what is known as the "extended" tort of passing off which included any situation where goodwill is likely to be injured by a misrepresentation.

---
> [!important]  Five factors laid down by Lord Diplock for claim of extended passing off
> 1. Misrepresentation
> 2. by a trader in the course of trade
> 3. to **prospective customers** of his or **ultimate customers** of **goods or services supplied** by him
> 4. which is ==**calculated to injure the business or goodwill of another trader**==
> 5. Which causes **actual damage to the business/goodwill of the trader** who brings the action