---
Number: 
Week: 12
MainTopic::
Topics:
Status:: #incomplete 
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module:: 
---

# **Case** ⚖️ : ***Hindustan Radiators Co. vs Hindustan Radiators Ltd***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Hindustan Radiators Co. vs Hindus Radiators Ltd***
- Citation::
- Year:: 
- Bench Size::
- Subject: #IPR

```

---
## Held 8 Factors for passing of in India
> [!danger] Factors for passing off
> 1. Plaintiff has been using its trading style and trademark for a long period and continuously whereas the Defendant has entered into the said field only recently;
> 1. There has not been much delay in the filing of the suit for injunction by the Plaintiff;
> 1. The goods of the Plaintiff have acquired distinctiveness and are associated in the mind of the general public as goods of the Plaintiff;
> 1. The nature of activity of the Plaintiff and the Defendant is same or similar;
> 1. The goods of the parties to which the trademark of the Plaintiff is associated are same or similar;
> 1. The user of the said trademark or trade name by the Defendant is likely to deceive and cause confusion in the public mind and injury to the business reputation of the Plaintiff;
> 1. The sphere of activity and the market of consumption of goods of the parties are the same; and
> 1. The customers of the Plaintiff, inter alia, include uneducated, illiterate and wary customers who are capable of being deceived or confused or misled.
