---
Number: 
Week: 12
MainTopic::
Topics:
Status:: #incomplete 
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module:: [[Trademarks]]
banner: "![[⚖️ Louis Vuitton vs Haute Diggity Gog (2007).png]]"
banner_y: 0.26885
metatable: true
---
<mark style="background: #00FF3E8C;">Obvious parody - no likelihood of consuion</mark>
# **Case** ⚖️ : ***Louis Vuitton vs Haute Diggity Gog (2007)***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Louis Vuitton vs Haute Diggity Gog (2007)***
- Citation::
- Year:: 
- Bench Size::
- Subject: #IPR

```

---
## Facts
- Rs made **bags** that **poked fun at Louis Vuitton** 
- Haute Diggity Dog manufactured, among other things, plush toys on which dogs can chew, which parodied famous trademarks on luxury products. The particular Haute Diggity Dog chew toys in question here are small imitations of handbags that are labelled "Chewy Vuiton" and that mimic LVM's LOUIS VUITTON handbags.

---
## Issue:
1. Is thi **likely to ==cause confusion==** ?

---
## Held
1.  
	- There is **no likelihood of confusion** in this case
2.  
	- Chewy Vuittion is an ==**obvious parody**==; thus, the **Onus here is on the plaintiffs to prove confusion**
3.  
	- For tarnishment, the **first criterion** that must be satisfied is [[Dilution by Blurring]] ; after that, it must be shown that Chewy Vuitton **harms the reputation of Louis Vuitton**
	- THere is **no blurring in this case**; 

> [!Case] Verdict
> - No infringement in this case
> 