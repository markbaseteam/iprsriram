---
Number: 
Week: 12
MainTopic::
Topics:
Status:: #incomplete 
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module:: 
---

# **Case** ⚖️ : ***Reckitt & Colman Products Lrd v Borden Inc (Jif Lemon case)***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Reckitt & Colman Products Lrd v Borden Inc (Jif Lemon case)***
- Citation::
- Year:: 
- Bench Size::
- Subject: #IPR

```

---
## Facts
![[⚖️ Reckitt & Colman Products Lrd v Borden Inc (Jif Lemon case).png|inlR|400]]
- The plaintiff was a manufacturer of lemon juice and, since 1956, had been selling such juice under the name “Jif” in plastic containers resembling real lemons. 
- The defendant’s product, manufactured in 1985-86 marketed three different kinds of lemon juice in containers precariously similar to those of the plaintiffs’, the only difference being a differently coloured cover and a different brand name, “ReaLemon”.
- The plaintiffs’ brought an action for passing off and were successful, with both the Court of Appeal and the House of Lords upholding the decision.
---
## Held
### Lord Oliver's trinity principle
1. First, the plaintiff must establish ==**goodwill**== attached to his goods/services.
2. Second, he must demonstrate a **==misrepresentation==** by the defendant to the public (whether or not intentional) leading or likely to lead the public to believe that goods or services offered by him are those of the plaintiff.
3. Thirdly, he must demonstrate that he suffers or is likely to suffer **==damage==** due to the defendant’s misrepresentation.

![[⚖️ Reckitt & Colman Products Lrd v Borden Inc (Jif Lemon case)-1.png]]