---
Week: 12
LectureNumber:  23
Topics:
Date:  2022-10-20
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  20th October 2022 - Intellectual Property Law L(23)
Type:: #lecture
---


# **Lecture Notes** 📝 :  20th October 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  20-10-2022**
- Week: 12
- Lecture No.:  23
- **Semester**: #7thsemester 
- [Link to Lecture]

```
Status:: #incomplete 
Module::

---
