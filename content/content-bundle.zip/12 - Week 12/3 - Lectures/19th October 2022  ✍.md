---
Week: 12
LectureNumber:  22
Topics:
- Reliefs
- Offences
- Passing off and its ingredients
- Misrepresentation 
- Damages
Date:  2022-10-19
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  19th October 2022 - Intellectual Property Law L(22)
Type:: #lecture
---


# **Lecture Notes** 📝 :  19th October 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  19-10-2022**
- Week: 12
- Lecture No.:  22
- **Semester**: #7thsemester 
- [Link to Lecture]

```
Status:: #complete
Module:: [[Trademarks]]

---
```toc
```

----

![[⚖️ Louis Vuitton vs Haute Diggity Gog (2007)]]

<br>


---
## Reliefs
### Injunctions

1. May be **==interlocutory==** or ==**permanent**== as under [[Section 135(1) of Trademarks Act]]
2. May be injunction for ==**discovery of documents**== under [[section 135(2) of the Trademarks Act]]
3. It may be **==delivery up of infringing labels, and marks for destruction or erasure==** as under [[Section 135(1) of Trademarks Act]]

#### Damages 
- Provided under [[Section 135(1) of Trademarks Act]]

---
#### Account for Profits 
- under [[Section 135(1) of Trademarks Act]]

----
### Quia Timet Action
- Equitable relief sought under dire circumstances with a view to prevent any infringement form taking place – else the owner will be left with no relief.

---
### Anton Pillar Orders
- the court has inherent jurisdiction on an application by the plaintiff made ex parte and in camera to require the defendant to permit the plaintiff to enter his premises and take inspection of relevant documents and articles and take copies thereof or remove them for safe custody.
- The necessity for such an order arises when there is grave danger of relevant documents and infringing articles being removed or destroyed, so that the ends of justice will be defeated.
---
### Joh Doe orders
- John Doe orders are the orders issued by the court to search and seize against unnamed/ unknown defendants; which virtually translates into untrammeled powers in the hands of the plaintiffs, aided by court-appointed local commissioners, to raid any premises where infringement activities may be carried out.
---
### Groundless Threats - Defence
- SOmeimes, the plaintiff gets **agressive in apprach**; 
	- where D has **belief** that they have **basis to use TM**, they **can use this defence**
---
## Offences
1.  Counterfeiting 

> [!danger] Measures that can be implemented
> 1. [[Section 103 of Trademarks Act]] and [[Section 104 of Trademarks Act]]
> 	- Imprisonment of 6m to 3ys and/or **50k to 2,00,000**
> 1. Search and seizure by the police - [[Section 115 of Trademarks Act]]
> 

---
## Unfair Competition
1. [[Article 10 bis of Paris Convention]]
	- Article 10bis **protected more broadly than passing off** 
- France
	1. Unfair competition
	2. Parasitic Behaviour
	3. Parasitic Competition
- US
	1. Elements of misappropriation 
	2. Lanham Act
- China 
	1. Anti unfair competition law 1993
	2. Anti monopoly law 2007
---
## Passing off
![[Passing off (Tort)]]


![[⚖️ Erven Warnik Besloten Vennootschap v J Townend and Sons (Advocaat Case) Factors]]


---
![[J Bollinger v Costa Brava Wine (1959)]]

---
![[Anheiser Busch Inc v Budejovicky Budvar (1984)]]


---
![[Daimler Benz v Hybo Hindustan (1994)]]