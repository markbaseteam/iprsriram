---
Week: 7
LectureNumber:  14
Topics:
Date:  2022-09-15
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  15th September 2022 - Intellectual Property Law L(14)
Type:: #lecture
---


# **Lecture Notes** 📝 :  15th September 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  15-09-2022**
- Week: 7
- Lecture No.:  14
- **Semester**: #7thsemester 
- [Link to Lecture]

```
Status:: #partiallycomplete
Module:: 

---
![[⚖️ DU Photocopy Case]]

---
![[⚖️ Author's Guild vs Google Books]]


---
## REMEDIES
### Civil remedies
- [[ Section 55 of Copyright Act]] -> damages and injuction
	- ! temporary injunctions under IP
		- Not the usual temporary injuncion
		- we have the **anton pillar or john doe orders** -> you **do not know who the party is** however, you have a **singficant claim/reason to demonstrate beofer the court tha t==what the defendant is doing is harming you==** ; in this case, you will have to <mark style="background: #FF4E00A6;">demonstrate the damage</mark> 
	- @ 
- Preventive and compensatory remedies
- Norwich Parmacal Orders
- Mareva Injuction
- anton Pillar Orders/John Dowe Orders


> - Suits under the CPC

### Criminal remedies
- 
	- Delivery up of infringing copy -> [[Section 53 of the Copyright Act]] - Commissioner of customs
	- Imprisonment between 6 months to 3 years
	- Fine Rang eof 50k to 2L
-  
- 