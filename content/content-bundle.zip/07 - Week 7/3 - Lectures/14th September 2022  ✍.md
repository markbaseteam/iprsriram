---
cssclass: matrix
Week: 7
LectureNumber:  13
Topics:
- Fair use and Fair Dealing
Date:  2022-09-14
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  14th September 2022 - Intellectual Property Law L(13)
Type:: #lecture
---


# **Lecture Notes** 📝 :  14th September 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  14-09-2022**
- Week: 7
- Lecture No.:  13
- **Semester**: #7thsemester 
- [Link to Lecture]

```
Status:: #partiallycomplete
Module:: 

---

> [TOC]


----
# 🔠 KEY WORDS
1. Transformative use
2. [[Four Factor Test]]

---
# 📝 NOTES
## Fair Use and Fair Dealing
> - FAIR USE -> THIS IS A **DEFENCE**
> - IT COMES AS A **==CURE==** AND NOT A PREVENTION

- Communication to public; 
	- potential financial injury is also controversial topic
- Finances -> is one of the criteria but **not th eonly criteria**

- Fair is acts which **would have been [[8th September 2022  ✍#Infringement|infringement]]**  ideally, but ==**because of the circumstances in which you are doing the act**==, the author <mark style="background: #00FF3E8C;">**cannot sue you**</mark>

<br>

>[!important] Fair use vs Fair dealing
> 1. ! Fair use
> 	- It is the **broader understanding** of what constitutes **exceptional use** under copyright
> 	- Case by Case basis
> 2. ! Fair dealing
> 	- **Relies a lot on the <mark style="background: #00FFFE73;">Statute</mark>**
> 		- essentially, the **statute will mention** what will be considered as **==fair use==**



- ? Horace Ball's definotion
	- It is a privelege in others to **use the copyright owner's work** in a  **reasonable manner** without his concept **notwithstanding the monopoly granted** to the **copyright owner


<br>


> [!concept] Concept comes from the US
> - ~ Falson v Marsh?
> 	- First case -> use of work without the author's permission
> 	- It went to other jurisdictions -> **became fair dealing in UK 🇬🇧**


- In India, we **generally follow fair dealing**; however, we have also allowed for ==**fair use (4 factor test)**==

<br>

----
### Fair Use

![[fAIR USE FLOWCHART.excalidraw]]

#### Transformative use
- It requires ==**transformatie use**== #important 
	- the subsequent usage must be ==**completely differnt from what the <u>original work was supposed to be</u></u>**==
	- ! this depends on a **case by cases** understanding
	- THere is **nothing sacrosanct** that has been defined about **Fair Use** 
	- eg: *pretentious movie reviews: somebody takes  amovie, dcertain clips, makes a statement on what th emovie represents; exerdcise s their free speech on what their opinion about the movie* 

> [!example] 
> - Critiques constitute critique
> - Reaction bodies -> they minimise the video; and ensure that the audience are not able to listen to it so that they can react to what is happening; 

<br>


#### FOUR FACTOR TEST
> [!Concept] Test
> 1. ! Purpose of the Use
> 	- what is th eperson trying to achieve with the work; what is the **reason for the work**
> 1. ! What is the nature of the copyrighted work?
> 	- 
> 1. ! What is the <u>amount used</u>? 🥛
> 	- This is controversial
> 1. ! Effect of use?
> 	- whether it cause **financial consideration**
> 	- what is the **ultimate impact of the work** -> *does the work lose signficance? completely* 

<br>


<br>


<br>


<br>


### Fair Dealing
<mark style="background: #00FFFE73;">Section 52</mark>

[[Four Factor Test]]


1. ~ Case: Civic Chandran vs Amunniammaa

![[⚖️ Campbell v Acuff-Rose Music (1994)]]

- ~ DU photocopy case
	- Relies on the four factor test
	- There was photocopy shop
	- they were selling out bookloets that were **sold as nots by students**
	- Oxford/cambridge universtiy were displeased by this practice
	- Court said tha t
		1. there was **education purpose** that is associated with this judgement
		2. Court rule din favour of the **photocopier**


<br>

![[3 Factor Test]]


- ~ Lenz vs Universal (2016) #important 
	- Lady; her son was dancing to a song; she put it on youtube
	- Bcs there was a music used in the bg, YT copyright striked and asked her to take it down; the video was then taken down
	- ! Lenz:
		1. said that her child was dancing to a song; this is fair use
		2. that universal misrepresented by saying that the 20sec video constituted an act of infringeement
	- ? Fair use vs Fair dealing
		- Fair use is used as a **cure** and not as a **presumption** 
		- it depends on the **court to interpret** what is fair use and what is not
	- @ Legislation -> DMCA 
		- says that **any person who is an intermediary** aka *YouTube*, -> they have to **<u>create proper mechanisms for any kind of takedown</u>**; mechanism for any person to give a notice and for YT to see the notice and then take down
	- ~ Held
		1. Whether it requires copyright holders to consider fair use beofre sending a notice?
			- Court came down heavily on DMCA and the Copyright Holder
			- That they have to think twice before filling the "notice form" Unless there is a particular ground to fill that form 
			- THus, administrator would be liable if it knowingly misrepreseted in the takedown notification that it has formed a good faith belief tha tth evideo did not constitute fair use and there was evidence that the administrator failed to consider fair use at all,


---
# ✍️ SUMMARY



---
# Homework
- Go to Amazon/Youtube -> see the tab called Intellectual proeprty 
