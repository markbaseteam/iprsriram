---
Number: 
Week: 7
MainTopic::
Topics:

Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---
- [x] Complete [[⚖️ Author's Guild vs Google Books]] ⏫ 📅 2022-10-06 ✅ 2022-10-08

==**🇺🇸 US Case**==
# **Case** ⚖️ : ***Author's Guild vs Google Books***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Author's Guild vs Google Books***
- Citation::
- Year:: 2015
- Bench Size::
- Subject: #IPR

```

Status:: #complete

> [!abstract] Summary from LexisNexis
> - The Court held that Defendant's unauthorized digitizing of copyright-protected works, creation of a search functionality, and display of snippets from those works were non-infringing fair uses under [17 U.S.C.S. § 107](https://advance.lexis.com/document/?pdmfid=1000516&crid=e5ad2248-e428-45c0-b4e2-a52cbc5e8b4b&pddocfullpath=%2Fshared%2Fdocument%2Fcases%2Furn%3AcontentItem%3A5H5B-G231-F04K-J02C-00000-00&pddocid=urn%3AcontentItem%3A5H5B-G231-F04K-J02C-00000-00&pdcontentcomponentid=6386&pdshepid=urn%3AcontentItem%3A5H4V-G471-J9X5-V23M-00000-00&pdteaserkey=sr1&pditab=allpods&ecomp=5pkLk&earg=sr1&prid=54d8c2f4-7a6d-4bf4-beb2-575cc6b506c6) because 
> 	1. the purpose of the copying was highly transformative, 
> 	2. the public display of text was limited, and 
> 	3. the revelations did not provide a significant market substitute for the protected aspects of the originals, and defendant's commercial nature and profit motivation did not justify denial of fair use. 
> - Moreover, the Court posited that Defendant's provision of digitized copies to the libraries that supplied the books, on the understanding that the libraries would use the copies in a manner consistent with the copyright law, also did not constitute infringement, nor was defendant a contributory infringer.


---
## Facts
- 
	- Google Books -> tried to **digitise a lot of the books** that were **only available offline** so that people would know about it
		- It would **allow the public ot search the texts of the digitally coied books** and **see displays of snippets of text**

> ![[⚖️ Author's Guild vs Google Books.png]]


- 
	- Author's guild -> found an issue with this -> 
		- GB is free -> it is providing preview which means that **there are certain portions of the work that are ==out in th open==** => meaning they are being **Proliferated for free** 
-  
	- Google defended on the ground that its actions constitute **fair use** and is **not an infringement**
---
## Held
### Law of Fiar use


#incomplete 

---
## HOLDING
> [!abstract] Summary
> 1.  
> 	- Ultimate goal fo copyright is to **expand public knowlege and understnading** whcih copyright seeks to achieve by **giving potential creators control over copying of their works** , thus **giving them finanacial incentive to creat informative and intellectually enrichign works for public consumption**
> 1.  
> 	- Googel making a **digital copy** to ==**provide a search function**== 🔍 <mark style="background: #00FF3E8C;">**is transormative use**</mark> 
> 		- this is because this **augments public knowledge** by **<u>making the information *about* the plaintiff's book available to the public</u>** ***without providing the public with a <u>substantial substite for matter that is protected by the Plaintiff's copyright interests in the material works</u>***
> 2.  
> 	- The **display of snippets** also constitutes **<mark style="background: #00FF3E8C;">transformative use</mark>**
> 

### 1. The law of fair use
1.  
	- Ultimate goal fo copyright is to **expand public knowlege and understnading** whcih copyright seeks to achieve by **giving potential creators control over copying of their works** , thus **giving them finanacial incentive to creat informative and intellectually enrichign works for public consumption**
		- However, in certain circumstances, **gviing authors asolute control over all copying from their workds would ==tend in some circusmtacnes to limit rather than expand public knowledge==** 🔴
---
### 2. Factor 1: Transformative Purpose
-  **WHAT IS TRANSFORMATIVE USE**
	- This factor was explained in [[⚖️ Campbell v Acuff-Rose Music (1994)]] the inquiry as to **whether the new work merely superseded the previous creation**, or it <mark style="background: #00FF3E8C;">**added something new** with a **further purpose**</mark>
-  **TRANSFORMATIVE USE TENDS TO FAVOUR FAIR USE AS IT BRINGS SOMETHING NEW AND DIFFERENT FROM ORIGINAL**
	- Transformative uses -> tend to favour a [[Fair dealing|Fair Use]] finding because a **<u>transfromative use is one that communicates somthing new and different from the original</u>** or **<u>expands its utility</u>**, thereby **<mark style="background: #00FF3E8C;">serving copyright's objective of promoting public knowledge</mark>**
- ~ **GOOGLE'S CASE**
	1. Google'es **=="search and snippet views"==** functions <mark style="background: #00FF3E8C;">**satisfy the fair use factor wrt Plaintiff's rights in their books**</mark>
- **SEARCH FUNCTION WAS TRANSFORMATIVE USE**
	- because it involved a **highy trasnformative purpose**; in that **==creation of a full text searchable database==** 
		- this is <mark style="background: #FF4E00A6;">**different in purpose, character, expression, meaning and messsage**</mark> from the book/page it is drawn
- **SNIPPET VIEW WAS TRANSFORMATIVE**
	- Merely knowing that a term of interest is not enough (this is what the search function does) as it **does not tell the searcher whether she needs to obtain the book**; this is becaues it **does not refvela the manner or context** in whcih the term is used; it does not reveal if the use of the term is in **such manner and context that it falls within the scope of the searcher's interest**
	- <mark style="background: #00FF3E8C;">The snippet on the other hand provides greater context; it **held the buyer evaluate whether the book falls within their scope of interest** </mark>
- **GOOGLE'S COMMERCIAL MOTIVATION DOES NOT VITIATE TRANSFORMATIVE USE**
	- In [[⚖️ Campbell v Acuff-Rose Music (1994)]], it was observed that the *Congress had **not intended** that **such a broad presumption against commercial fair uses** *
		- It was oberved that <mark style="background: #D2B3FFA6;">*more transformative the **secondary work**, the **less** will be the **significance of other factors** such as* ***commercialism***</mark>
	- ! Note: Whiel commerical motiviation **can undoubtedly weigh aginst a finding of fair use** in **some circumstances** (esp where a **transformative use is lacking**); however, this is not the only factor;
---
### 3. Factor 2: Nature of Copyright Work
-  
	- This factor has **rarely played a significant role** in the determination of a [[Fair dealing|Fair Use]] dispute
-  
	- The law generally recognizes a **greater need** to **disseminate factual works than works of fiction or fantasy** 
- $ **In this case**
	- While the books of Plaintiffs is ==**factual**==, the court <mark style="background: #D2B3FFA6;">**hardly considers this to be a boost to GOogle's fair use claim**</mark>

---
### 4. Factor 3: Amount and Substantiality of the portion used in relation to the copyrgihted work as a whole
-  
	- The finding of fair use is **more likely** when ==**small amounts**== or ==**less important passages are copies**==, rather than when the copying is extensive orcontains **important parts of the original**
	- However, this IS <mark style="background: #00FF3E8C;">**NOT a categorical rule**</mark>
		- In some cases, **<u>complete unchanged copying can be justified as [[Fair dealing|Fair Use]]</u>**
-  
	- In [[⚖️ Campbell v Acuff-Rose Music (1994)]], it was decided that th e**extent of permissible copying** ==**varies with th epurpose and character of the use**==
- $ Applying to facts of the case
	1. **SEARCH**
		- While google **makes an unauthorise digintal copy of the entire book**, 
			1. it **does not reveal that copy to th epublic**
			2. The copy is made to **enable the search functions** to **reveal limited importnat info abotut the book**
			- $ THus with respect to the search function, it **satisfies the 3rd factor test**
	2. **SNIPPET**
		- In matters such as this, what matters is **not so much the "amount and substantiality of the protion used"** but the **amount and substantiality of ==what is thereby made accessible to a public for which it may serve as a competing substitute==** 
		- ~ In this case google has **made the feature** such that <u>**it does not serve as an effective competing substitute for plaintiff's books**</u>
			- Google also does not provide this feature for **dictionaries** and **cookbooks** wherein even revealing a small prition would **satisfy the need of the searcher**
----
### 5.Factor 4: Effect of the (copying) use upon th epotential market for or value of the copyrighted work
1.  **WHAT DOES THIS MEAND?**
	- This test focuses on whether the **copy** brings to the **marketplace** a **<mark style="background: #FF4E00A6;">competing substitute for the original or its derviative</mark>** so as to **<u>deprive  the copyright holder</u>** of significant **revenues** because the potential purchasers may **opt to acquire a copy** 
2.  
	- [[⚖️ Campbell v Acuff-Rose Music (1994)]] : stressed the **close linkage** between the **first and fourth factors** ; ***<u>the more the copyring is done to achieve a purpose that differs from teh purpose of the original, the less likeley it is that th ecopy will serve as a satisfactory substitute for the original</u>***
		- ! However, this only goes so far -> even if the purpose is for a **valuably transformative purpose**, the quesiton arises as to whether ***<u>notwithstanding its transformative purpose, does it make for a competing subsitute</u>***
			- ~ In this case, **NO**
				- esp so in view of the fac tht aprice of a book is relatively in relation to the cost of manpower need to secure an arbitrary assortment of randomly scattered snippets
			- While it is undoubtedly true that there will be some loss in sales as some poele will be able to find what they want using th esnippet function, **some loss <mark style="background: #FF0000A3;">does not suffice to makethe copy an effectively competing substitute</mark>** #important 


---
### 6. Plaintiff's exposure to risks of hacking of Google's files


### 7. Google's Distribution of Digital Copies to Participant Libraries

---
# Notes 
![[fAIR USE FLOWCHART.excalidraw]]

- There is 
	1. complete differentiation of medium
	2. the use is also different -> the spirit is that **it shows the book to anaudience that might not have been privy to the book** and therefore **bringing it into their knowlege** e
	3. Potential financial injury? **nothing**; **<u>the preview is not the tell all of the book</u>**