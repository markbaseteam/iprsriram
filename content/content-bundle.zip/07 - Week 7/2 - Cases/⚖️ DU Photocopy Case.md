---
Number: 
Week: 7
MainTopic::
Topics:
Status:: #complete
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---
- [x] Complete [[⚖️ DU Photocopy Case]] ⏫ 📅 2022-10-06 ✅ 2022-10-07
# **Case** ⚖️ : ***The Chancellor, Masters & Scholars of the University of Oxford vs Rameshari Photocopy services & Others***

```ad-Case
title: **Case Details**

- **Name of Case**: ***DU Photocopy Case***
- Citation::
- Year:: 
- Bench Size::
- Subject: #IPR

```

---
# Case Brief:
## Facts
- Publishers vs Consumers of academic content
- WEnt to single judge of Delhi HC
	- Went **in favour of the photocopy service**
	- Under section 52 - Fiar use
- Then it went to Division Bench  ![[⚖️ DU Photocopy Case.png]]
	- They decided against the presses in favour of the photocopy service
	- They interprested section 52 as something where theere is a **principle of fair use that can be read into it**
	- It rejected the [[Four Factor Test]] 
		- in this case they chose **not to apply the test**
		- that in this case, the **statue has already provided for an education purpose** so there is **no reason to resort to the four factor test** 
	- The press -> contended that the sutdents would then have no incentive to buy these books; that this will affect tha merket of the person who are publishing them
	- Court responded that as long as there is an education purpose attached to the thing they are doing, it automatically becomes fair use
	- 

---
## Issues?

---
## Held


---
# Misc Notes
- Purpose of copyright is to **disseminate information** **<u>while acknowledging who brought out this information</u>**
	- Educational institutions -> seek to disseminate information

---
# Summmary
> [!Case] DU Photocopy Case - Extended summary⚖️ 
> ## Facts
> -  
> 	- Rameshwari PCS and University of Delhi -> use to make **Course packs** by **photocopying the =="course packs bound volumes"==** which ==contained **excerpts from various text books**== which 
> 		- ! This was alleged to have **<u>infringed the ocpyright of the publishers held in those text books</u>**
> 
> ---
> ## Issues
> 1. Does the making of course packs by Rameshwai and DU amount to ==**infringement of  copyright**== or will it be covered under [[Fair dealing]]
> 
> ---
> ## HELD
> 
> 1.  **REPRODUCING AND DISTRIBUTION OF COPIES NOT INFRINGEMENT**
> 	- ==**Reproducing books and distributing copies thereof**== for the <mark style="background: #00FF3E8C;">**purpose** of *education*</mark> will **<u>NOT constitute copyright infringement</u>**
> 2. **COPOYRIGHT LAW RESTS ON A DELICATE BALANCE BETWEEN ==1. THE INTERESTS OF COPYRIGHT OWNERS (authors publishers creators artists)==** **AND THE <mark style="background: #00FF3E8C;">COPYRIGHT USERS</mark>**
> 	- The law is designed to **encourage the creation of works simultaneously**; to <mark style="background: #00FF3E8C;">permit the users to **enjoy the works and promote arts and knowlege</mark> 
> 3. $ **ACT OF <mark style="background: #FF4E00A6;">PHOTOCOPYING, PREPARING COURSE PACKS, AND DISTRIBUTION</mark> FALLS UNDER [[Fair dealing]] UNDER OF [[Section 52(1)(i) of the Copyright Act]]**
> 	- THE ACT OF PHOTOCOPYING IS REPRODUCTION FO THE WORK AND CONSTITUTES INFRINGEMENT UNLESS IT IS LISTED UNDER [[Section 52 of the Copyright Act]]
> 		- In this case, the **acts of photocoying, preparing course packs, and their distrbibution** will fall within the ambit of [[Section 52(1)(i) of the Copyright Act]] which provides as follows 
> 			>![[⚖️ DU Photocopy Case-1.png]]
> 
> 1. ? **IS THE INTERPRETATION FO THE SECTION <u>RESTRICTED TO AN INDIVIDUAL TECAHER AND AN INDIVIDUAL PUPIL</u> OR WHETHER IT WOULD <u>EXTEND TO AN INSTIUTTION AND ITS STUDENTS?</u>**
> 	- Court unequivocally held that **the section <mark style="background: #FF0000A3;">cannot be so resitricted</mark>** 
> 		- This is especially the case considering the **social realities** ; <mark style="background: #D2B3FFA6;">**education** in India has been **for long institutionalised** and thus, the law **<u>cannot be interpreted such that it does not reflect the realities of our social educational system</u>**</mark> #important 
> 1. **CAN THE TERM "COURSE OF INSTRUCTION IN [[Section 52(1)(i) of the Copyright Act]] BE LIMITED TO LECTURES AND TUTORIALS WHERE <u>TEACHER IS DIRECTLY INTERACTING WITH PUPILS AND IN THE PROCESS USING COPYRIGHTED WORK?</u>"**
> 	- The court disagreed
> 	- The **legislature** had **<u>specifically chosen the word <mark style="background: #00FFFE73;">"instruction"</mark> rather than "lecture"</u>**
> 		- thus, the interpretation of the term "instruction" **<u>cannot be limited to that of lecture</u>**
> 	- ! **MEANING OF "IN THE COURSE OF INSTRUCTION"**
> 		1. 
> 			- It includes **any work** while the **reproduction any work** while the process of imparting instruction by the teacher and the **receiving of such instruction by the pupil** 
> 			- ==It includes the **entire academic session for which the pupil is under the tutelege of the teacher**== 
> 		2.  
> 			- It is a process that commences from the *teacher readying thesmselves for imparting instruction*, *setting the syllabus*, *prescribing txt books, reads*, etc
> 		3.  
> 			- ***Even if we were to limitt the meaning of th ephrase to "lecture"***, this would have to include within its abmit
> 				1. the prescriiption of syllabus the prepariton of which both the teacher adn the pupil are requried to do before the elcture
> 				2. the studies which the pupils are to do post lecture  etc
> 		
> 		>Thus, **reproduction fo any copyrighted work by the teacher** for the purpose of **==*imparting instruction to teh pupil*==** as prescribed in teh syllabus during the academic year **<u>would be within the meaning of [[Section 52(1)(i) of the Copyright Act]]</u>**
> 
> 1. **THE COURT APPROACHED THE ISSUE FROM ANOTHER ANGLE**
> 	1. A STUDENT ISSUING A BOOK FROM THE DU LIBRARY AND COPYING TH SAME **BY HAND OR BY PHOTOCOPYING** would be **protected by fair dealing**
> 	- >  Principle <mark style="background: #00FF3E8C;">if onerously done is not an offence, it cannot become an offence when, owing to advancement in technology doing thereof has been simplified.</mark> That is what has happened in the present case.
> 		- Because of technological advancement, the **voluminous books** can be **photocopies at low cost** ; back in the day, students use d to sit and copy by hadn pages after pages suggested fro reading, or *make carbon copies of the same*;
> 			- ~ If the **latter is not infringement**, **then so is not the former**
> 	- >[!important] Principle
> 	>When the effect of the action is the same, the difference in the mode of action cannot make a difference so as to make one an offence.
> 
> 1. **WHETHER DU HAVING LICENSED THE MAKING OF COURSE PACKS TO A CONTRACTOR IS RELEVANT**
> 	- NO
> 	- As long as the **act is protected under [[Section 52(1)(i) of the Copyright Act]]**, then it was <mark style="background: #FF5582A6;">the question of "who did the photocopying" is**irrelevant**</mark>
> 2.  **DIFFERENCE BETWEEN ISSUANCE OF COPEIES OF THE PPK TO THE PUBLIC AND MAKING PHOTOCOIES OF THE WORK**
> 	1. Inthe former, it is <mark style="background: #00FF3E8C;">**permissible**</mark>
> 	2. The latter -> Issuing copies of the work under [[section 14 of the copyright act|Section 14(a)(i)]] is the **<u>exclusive right of the order</u>**; it ***cannot be interpreted to mean"making copies of the work"*** 
> 		- Such act would <mark style="background: #FF0000A3;">**constitute infringement**</mark> under [[section 14 of the copyright act|Section 14(a)(i)]]  and [[section 51(a)(i) of the Copyright Act]]
> 		- Thus rameshwai PC and DU will <mark style="background: #FF0000A3;">**not be entieled to make photocopies of <u>substantial part of the said book for distribution to the students</u>**</mark>; if it does the same, then it would be **committing infringement of the copyright therein** 
> ---
> > [!Case] FINAL VERDICT
> > - The following acts **do not amount to copyright infringement**
> > 	1. ==Copying portions of books== by **teachers, students, or educational institutions**
> > 	2. ==**Making of course packs**== of **<u>such photocopied protions</u>**  for a course 
> > 	3. ==**Selling**== the said course packs at a **reasonable price** i.e. <mark style="background: #00FF3E8C;">75 paisa per page, or any **reasonable price**</mark>
> > 	4. ==**Permitting photocopying** in an education institution== either in the library or through a photocopy centre, ==**and charging for the same**==
> 

