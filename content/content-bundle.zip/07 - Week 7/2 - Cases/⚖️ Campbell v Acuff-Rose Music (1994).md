---
Number: 
Week: 7
MainTopic::
Topics:
- Fair Use
Tags: 
- reading 
- case 
- incomplete 
- IPR
Type:: #case
Module: 
---
- [x] Complete [[⚖️ Campbell v Acuff-Rose Music (1994)]] ⏫ 📅 2022-10-06 ✅ 2022-10-07
# **Case** ⚖️ : ***Campell v Acuff-Rose Music (1994)***

```ad-Case
title: **Case Details**

- **Name of Case**: ***Campell v Acuff-Rose Music (1994)***
- Citation::
- Year:: 
- Bench Size::
- Subject: #IPR

```

> Just because you make money out of it does not mean that you will be considered to not have engaged in fair use

Status:: #partiallycomplete 

---
## Facts
-  
	- Rap music group sued by R for having sampled some of their music from an orignial rock ballad
	- Peittioner -> cliamed that it was a [parody]; that they wre entitled to fair use protection
-  
	- There is a sound recording hear vis-a-vis recording
	- ELement of sampling went into the second recording
	- Petitioners tried to claim the parady defence

==**COURT OF FIRST INSTANCE**==
-  
	- First instanc e-> dound that 
		- therer was a ==**commercial purpose**==; they were selling the song
			- this means that **<mark style="background: #FF0000A3;">we cannot claim a parody defence</mark>**

---
## Provision
![[⚖️ Campbell v Acuff-Rose Music (1994).png]]

---
## Held
==**appealed**==
- SUBSEQUENT COURT -> said that htere was an error in this understanding
	1. incoorecct to conclcude tha tj<mark style="background: #D2B3FFA6;">ust because there was **commerical** purpose attached to the second work, we cannot say tha t tey were **pardoying it**</mark> #important 
	2. <mark style="background: #FFF3A3A6;">the **commerdcial element** is just **one of the many elements** when trying to figure out if there has or has not been fair use</mark>
	- Court in this case relied only on **One element of the [[Four Factor Test]]** 
- Thus, this case is fair use

---
## HOLDING IN DETAIL
1.  
	- A work  if it has **<u>no critical beraing on th esubtance or stule of the original composition</u>** => dimishion of th e==**claim to fairness**==
2.  
	- Parodies are **not presumptively fair**
3.  
	- Threshold when [[Fair dealing|Fair Use]] is raised in parody is **whether a ==parodic character==** may be **reasonably perceived**
4. ! **REGARDING COMMERCIAL NATURE OF THE WORK**
	1. The **<u>commercial/non-profit education purpose of a work</u>** is **<u>only one element of the first factor inquiry into its purpose and character</u>**
	2. The court found that the lower court was in **error** in <u>concluding that *the commercial nature of petitioners' parody had **rendered it presumptively unfair** *</u>
	3. That <mark style="background: #FF0000A3;">**commercial character**</mark> i only <mark style="background: #00FFFE73;">one of the many factors</mark> that should be <mark style="background: #FF5582A6;">weight in a [[Fair dealing|Fair Use]] inquiry</mark>