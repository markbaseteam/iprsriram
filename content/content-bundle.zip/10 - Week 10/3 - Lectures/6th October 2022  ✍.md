---
Week: 10
LectureNumber:  19
Topics:
Date:  2022-10-06
Tags: 
- lecture 
- IPR 
- 7thsemester
- incomplete
alias: ✍️  6th October 2022 - Intellectual Property Law L(19)
Type:: #lecture
---


# **Lecture Notes** 📝 :  6th October 2022

```ad-info
title: Lecture Details
collapse: none
- **Subject**: ==**Intellectual Property Law**== #IPR
- **Date:  06-10-2022**
- Week: 10
- Lecture No.:  19
- **Semester**: #7thsemester 
- [Link to Lecture]

```
Status:: #complete
Module:: 
- [x] Complete Today's IPR Lecture 🔼 📅 2022-10-06 ✅ 2022-10-06



---
# RECAP 🔁
- Doctrine of Confusion
- Releveant Public Test (wrt to **well known trademarks**) vs Avg Consumer Test (wrt **general trademarks**)
- [[Honest Concurrent User Doctrine]]
	- Where there's **differnet classes of use** so there is **no confusion**
	- There is **no bad faith as well** 
	- ~ How to prove?
		1. that you **did not iknow**
		2. that that TM is **your name** eg McDonalds
		3. Did not have the knowledge (this defence does not work with brands such as apple)  


---
# 📝 NOTES
- Case of [[Kores India Ltd vs Khodayj Eshwarsa and Son]]
>## ⚖️ **Cases for Easier Understanding**
>---
> ![[Kores India Ltd vs Khodayj Eshwarsa and Son]]
> <br>
> 
> ---
>  ![[Hindustan Pencils Pvt Ltd vs MS Universal Trading Company]]

---
## Dilution 
> [!Concept] 
> - A trademark is  required to be **strong enough to trigger a memory**
> 	- However, where it is used in <mark style="background: #FF0000A3;">**other contexts**</mark>, the resultant effect is the [[Dilution of Trademarks]]
> 		- eg: Xerox 

- 
	- Dilution is essentially the **use of trademark** where it is **not supposed to be used**
	- [[Schechter]] put forth a strong case to **protect tradmarks** across industries
-  
	- $ Eg: Mercedes case vs an Indian company
		- Where the Indian company used Mercedes Log for an Underwear ⁉️
-  
	- @ **DILUTION AND PASSING OFF** 
		1. Dilution is the substance
		2. [[Passing off (Tort)]] is the **one of the ways to deal with dilution**
---
>### **`fas:QuoteLeft` Schecter's definition of Dilution**
>That dilution is the **gradual whittling way** or **dispersion** of the **idenity and hold upon the ==public mind== of the trademark** by it's <mark style="background: #FF5582A6;">use upon **non-competing goods**</mark>

> ### ** `ris:Question` Basis of Trademark Protection according to Schecter**
> - Value of MOdern TM lies on its ==**selling power**== ; its **hodl in the public**
> 	- this gets impaired when <mark style="background: #FF0000A3;">used for **unrelated goods**</mark>
> - The degree of protection depends on the **efforts**[^1], **ingenuity**, and the **distinctiveness** 

---
- **IS IT POSSIBLE TO RESTORE A DILUTED TRADEMARK?**
	- Yes, by <mark style="background: #00FF3E8C;">**agressive action**</mark>

---
##### RELEVANT PROVISIONS
- [[Section 29(4) of Trademarks Act]] 
	- Deals with [[Dilution by Blurring]]
	- Deals with [[Dilution by Tarnishment]]
- [[Section 29(8) of Trademarks Act]]
	- Deals with [[Dilution by Disparagement and Comparative Advertising]]
----
![[Dilution by Blurring]]


<br>


![[Dilution by Tarnishment]]

<br>

![[Dilution by Disparagement and Comparative Advertising]]

----

# 📄 MISC. POINTS 





---
# ⚖️ Cases
![[⚖️ Pepsi vs Hindustan Coca Cola]]

---
![[⚖️ HUL vs Amul]]

---
# 💡 CONCEPTS
1. [[Dilution of Trademarks]]
	1. [[Dilution by Blurring]]
	2. [[Dilution by Tarnishment]]
	3. [[Dilution by Disparagement and Comparative Advertising]]



---
# 🗃️ FLASHCARDS

[[Flashcards from 6th October 2022  ✍ - IPR]]



[^1]: Meaning the **author's efforts to protect the trademark** #important 